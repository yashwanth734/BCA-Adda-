# Security

BCA Adda is a student platform. This document describes its current security architecture as implemented in code, how to report vulnerabilities, and what deployment steps are required for that implementation to actually take effect. It does not claim the platform is unhackable, impossible to breach, or fully secure — no realistic system can honestly claim that. It describes what exists, what was fixed, and what is explicitly not yet done or not verifiable from this codebase alone.

This document was last substantially revised following an independent security audit and a subsequent remediation pass (see "Audit history" at the end).

## Architecture overview

```
Browser (HTTPS expected in production)
  ↓
CDN / WAF (Cloudflare or equivalent — not part of this codebase)
  ↓
TanStack Start SSR frontend (src/server.ts sets HTTP security headers on every response)
  ↓
Supabase (Auth + Postgres + Realtime)
    ├── Row-Level Security on every table
    ├── SECURITY DEFINER RPCs for sensitive writes, all with SET search_path = public
    └── TLS termination and connection encryption managed by Supabase
```

The frontend only ever receives `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. The service-role key never appears in application code. Sensitive operations (game moves, room creation, matchmaking, role changes, account deletion, rate limiting) run inside `SECURITY DEFINER` PostgreSQL functions that verify `auth.uid()` themselves — the client cannot bypass this by crafting a different request.

## Authentication

- Supabase Auth (JWT-based, managed by Supabase)
- Google OAuth (optional, native Supabase provider)
- Email + password
- **Password minimum: 8 characters, with a letters+digits requirement, enforced via `supabase/config.toml`'s `[auth]` section** for local/CLI-managed Supabase environments. **This must also be confirmed or set in the Supabase Dashboard (Authentication → Policies) for your hosted/production project** — `config.toml` reliably governs `supabase start` local development; whether it also governs your linked hosted project depends on your deployment workflow, and that cannot be verified from this codebase alone. Treat the dashboard setting as the authoritative one for production and check it directly.
- Password reset via time-limited, single-use email links (`/reset-password`). Token expiry and single-use enforcement are handled entirely by Supabase Auth's managed infrastructure — this codebase calls `resetPasswordForEmail`/`updateUser` but does not implement token logic itself, and that infrastructure's behavior is not independently verifiable from here.
- Optional TOTP two-factor authentication (`/settings/security`), using Supabase's built-in `auth.mfa` API.
- Passwords are hashed by Supabase Auth; this codebase never sees, logs, or stores a plaintext password at any point, including during account deletion re-authentication (the password is sent directly to `supabase.auth.signInWithPassword` and never touches application storage).

## Authorization and roles

Two roles exist: `student` (default, every account) and `teacher` (elevated — moderation, security-event visibility, role management).

- **Every new signup gets exactly `student`.** `handle_new_user_role()` (a trigger on `auth.users`) hardcodes this and does not read `raw_user_meta_data` or any other client-supplied signup field. This was previously not the case in an early version of this function — a since-superseded migration once read a client-controlled `role` field — and that earlier version is preserved in migration history for the record, but it has not been the live behavior since a later `CREATE OR REPLACE FUNCTION` replaced it. If you are auditing this codebase yourself, verify the *live* function body (`SELECT prosrc FROM pg_proc WHERE proname = 'handle_new_user_role'` against your actual database), not just the first migration that mentions the function name — migration history is not the same as current behavior.
- **Role elevation** happens only through `grant_role(target_user, role)` / `revoke_role(target_user, role)`, both `SECURITY DEFINER` RPCs that: require the caller to already hold `teacher` **with an MFA-verified (aal2) session** (see below), validate the target user exists, constrain the role to the `app_role` enum (`student`/`teacher` — there is no `admin`/`moderator` role in this schema), block a teacher from revoking their own teacher role, and log every grant/revoke to `security_events`.
- There is currently no UI for calling `grant_role`/`revoke_role` — they exist as database functions only. The first teacher account on a new deployment must be granted directly via the Supabase Dashboard's SQL editor or a one-off script using the service role.
- **Teacher accounts require two-factor authentication, enforced at the database, not just the login page.** Every RLS policy and function gated on the `teacher` role (moderation, attendance, security-event visibility, role management, the game audit log, account-deletion log, study-group and note moderation) additionally requires the session's JWT to carry `aal: "aal2"` — meaning this specific session has completed an MFA challenge, not merely "this account has the teacher role somewhere in its history." The helper is `public.has_verified_teacher_role()`. An account with the teacher role but no MFA enrolled (or an unverified session) is denied by every one of these policies exactly as if it weren't a teacher at all — a compromised teacher password alone cannot reach any of this data.
  - Client-side, `src/components/TeacherMfaGate.tsx` gives a teacher who hasn't satisfied this a clear, guided screen (enroll, or enter a code for an already-enrolled factor) instead of a wall of empty/denied results scattered across pages. It currently wraps `/moderation` and `/attendance` — the two clearest teacher-only entry points. It does **not** wrap the whole app (deliberately — that would also block a teacher's ordinary, non-teacher use of chat/games/etc., which the RLS changes never intended to restrict), and it does not cover every single teacher-gated action in the app (e.g. deleting someone else's study group or note as a teacher) — those still fall through to a normal Supabase error toast if attempted without MFA, which is correct and safe, just less polished than the guided screen.
  - **Operational note:** any teacher account that hasn't enrolled MFA loses access to all of the above the moment this is deployed. There is no soft-rollout — have existing teachers enroll at `/settings/security` first, or expect this to be disruptive on day one by design.
- Teachers have broad, platform-wide visibility into moderation surfaces (chat reports, room chat, shared notes, study groups) and into every student's `security_events`. This is a deliberate but real privacy tradeoff — there is no per-class/per-section scoping in this schema, so "teacher" currently means "sees everything," not "sees their own students." Reconsider this if the school's trust model requires narrower scoping.

## Row-Level Security (RLS)

RLS is enabled on every application table (verified programmatically — zero tables found without it). Ownership is enforced via `auth.uid()` equality or `EXISTS` subqueries checking real relationships (thread participants, message senders, etc.), not client-supplied flags. Destructive/sensitive actions (deleting another user's content, changing roles, viewing others' security events) require `has_role(auth.uid(), 'teacher')`, checked inside the policy itself — a modified or spoofed frontend request cannot bypass this.

## Security event logging

`public.security_events` records `login_success`, `password_change`, `mfa_enabled`, `mfa_disabled`, `logout`, `role_granted`, and `role_revoked`, restricted by an allowlist `CHECK` constraint.

**Clients cannot write to this table directly** — there is no `INSERT` grant to `authenticated`. Every event type except `logout` is generated by a database trigger reacting to a real, unforgeable state change:
- `password_change` / `login_success`: a trigger on `auth.users` reacting to `encrypted_password` or `last_sign_in_at` changing
- `mfa_enabled` / `mfa_disabled`: a trigger on `auth.mfa_factors` reacting to a factor becoming verified or being removed
- `role_granted` / `role_revoked`: written directly by `grant_role`/`revoke_role`

`logout` has no corresponding auth-schema state change to react to, so it goes through a narrow, parameterless, rate-limited RPC (`log_logout_event()`) instead of an open table insert — it can only log a logout for the caller's own `auth.uid()`, and fails silently rather than blocking sign-out if the log write itself fails.

**`login_failure` is now logged**, via a narrow, anonymous-callable RPC (`log_login_failure(email)`) rather than a direct table write. It resolves the email to a user ID internally (the caller never supplies one, closing the original "write fake events against a known UUID" risk), never reveals via its return value or errors whether the email exists (fire-and-forget from the client, result always ignored — prevents using it to enumerate valid accounts), and rate-limits by the *target* account rather than the caller, since an anonymous caller has no `auth.uid()` to rate-limit against. The client only calls it when Supabase's auth server actually responded with a rejection (checked via the error having an HTTP status code) — not on a plain network failure, which the app's connection-recovery layer handles separately so a dropped wifi connection doesn't get misrecorded as a failed login attempt.
A more architecturally "native" alternative exists — Supabase Auth Hooks include a "Password Verification Attempt" hook that fires from Supabase's own trusted auth flow rather than a client-callable RPC — but its exact request/response contract isn't something that could be verified without a live Supabase project from the environment this was built in, and a mistake in a function wired into the login path itself risks breaking sign-in entirely. The RPC approach above was chosen because every part of it is self-contained and reasoned through directly, rather than depending on an external contract that couldn't be checked.

**Verification caveat:** the triggers on `auth.users` and `auth.mfa_factors` react to Supabase-managed internal schema and have not been exercised against a live Supabase project from the environment this was built in. The column names used (`encrypted_password`, `last_sign_in_at`, `status` on `mfa_factors`) match Supabase's documented schema and this codebase's own pre-existing trigger on `auth.users` (`handle_new_user_role`) as precedent that such triggers are permitted here — but confirm they actually fire correctly after a real sign-in, password change, and MFA enrollment before relying on them.

## Account deletion

`delete_own_account()` takes no parameters — it operates strictly on `auth.uid()`, so there is no user-ID argument for anything to substitute another user's ID into. It requires the caller to re-authenticate with their current password (via `supabase.auth.signInWithPassword`, checked client-side before the RPC is called) and then deletes the `auth.users` row, which cascades through every foreign key in this schema (all use `ON DELETE CASCADE`).

The fact that an account was deleted is recorded in `public.account_deletion_log` — a table with **no foreign key to `auth.users`**, storing only the deleted user's UUID and a timestamp. This is deliberate: an earlier version of this logged into `security_events`, which references `auth.users` with `ON DELETE CASCADE` — meaning the deletion event was destroyed by the very deletion it was supposed to record. The decoupled table fixes that while keeping what's retained minimal (a UUID that's meaningless for re-identification once the account is gone, and a reason/timestamp — no username, no email, no profile data).

**Not verifiable from this codebase:** whether a JWT issued before deletion continues to authenticate requests for the remainder of its natural validity window. Supabase's access tokens are stateless; deleting the underlying user row does not retroactively invalidate an already-issued, unexpired JWT the way revoking a session does. In practice, most database operations will fail afterward regardless (their target rows are gone via cascade), but this is not the same guarantee as "the token stops working immediately."

## Rate limiting

Implemented via `public.rate_limits` and `public.enforce_rate_limit()`, with limits chosen per operation rather than applied uniformly:

| Action | Limit |
|---|---|
| Chat / DM / room-chat messages | 1 per 700ms |
| Subject notes | 1 per 2s |
| Game-room creation (any game) | 1 per 3s |
| Study group creation | 1 per 10s (public/global content) |
| Friend requests | 1 per 5s |
| Message reactions | 1 per 300ms |
| Matchmaking queue joins | 1 per 2s |
| Assignments | 1 per 1s |
| Logout events | 1 per 2s |

Login/signup rate limiting is handled by Supabase Auth itself, not this application's code.

## Content Security Policy and HTTP security headers

Set as real HTTP response headers in `src/server.ts`, applied to every response (success and error paths alike) — not merely a `<meta>` tag, though the meta tag also remains in `__root.tsx` as a defense-in-depth fallback:

- `Content-Security-Policy` — built from what this app actually loads (self, Google Fonts, Supabase REST/Realtime). Retains `'unsafe-inline'` on `script-src`/`style-src` because this is an SSR app whose hydration and Tailwind inline styles depend on it; removing that would require a nonce-based CSP wired through the SSR render pipeline, which is a larger change than this pass and unverified without a live build.
- `X-Frame-Options: DENY` and `frame-ancestors 'none'` (clickjacking protection — only achievable via a real header, never via `<meta>`)
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Permissions-Policy` disabling camera/microphone/geolocation/payment/USB — APIs this app doesn't use
- `Strict-Transport-Security` — only sent when the request is actually over HTTPS (checked via `x-forwarded-proto`/URL protocol), specifically to avoid telling browsers to force HTTPS on a deployment that doesn't support it yet. Conservative 180-day `max-age`, no `includeSubDomains`/`preload` (both are hard to safely undo) — raise these once HTTPS is confirmed solid in your actual deployment.

## Cross-Site Scripting (XSS)

User-generated content (chat, DMs, room chat, notes, profile fields) renders as plain text via React's default JSX escaping — no `dangerouslySetInnerHTML` on any of it. Two uses of `dangerouslySetInnerHTML` exist in the codebase: one renders the Supabase-generated MFA enrollment QR code SVG (a trusted, server-generated string, not user input); the other is in an unused `chart.tsx` UI component with no call site anywhere in the app (dead code, flagged here rather than silently left undocumented).

**User-supplied URLs rendered as links** (`profiles.avatar_url`, `subject_notes.url`) are restricted to `https://` only, enforced in two independent layers: client-side (`sanitizeHttpsUrl()` in `src/lib/urlSafety.ts`, shared by both call sites) and a database `CHECK` constraint on both columns, so a direct API call bypassing the client entirely still can't store `javascript:`, `data:`, `vbscript:`, `file:`, or `about:` URIs. This was not always the case — `subject_notes.url` originally had no scheme restriction at all while `profiles.avatar_url` did, an inconsistency that has been closed.

## CSRF

Supabase's client authenticates via a bearer token (JWT) sent in an `Authorization` header, read from the client's own storage — not an ambient browser-attached cookie automatically included cross-site. This architecture doesn't need traditional CSRF tokens the way cookie-session auth does. The tradeoff: because the session lives in client-accessible storage rather than an `HttpOnly` cookie, a successful XSS is more directly dangerous (it can read the token), which is part of why the URL-scheme restrictions above matter.

## Secrets

- `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are the only values that reach the browser; the anon key is meant to be public and is safe to expose (it's restricted entirely by RLS).
- The service-role key must never appear in frontend code or be committed. `.env` is in `.gitignore`; `.env.example` is the template with placeholder values only.
- No hardcoded API keys, database passwords, or tokens were found anywhere in `src/` or `supabase/` as of the last review.

## Dependency security

**Not verified as of this document's last revision.** The environment this codebase was built and audited in has no network access to run `npm audit` or check a CVE database. Run `npm audit` yourself before deploying, and treat this as an open item, not a clean bill of health.

## File uploads

Implemented via three public-read Supabase Storage buckets (`avatars`, `note-attachments`, `project-images`), each with:
- Server-side `file_size_limit` and `allowed_mime_types` on the bucket itself (2MB/images for avatars, 10MB/images+PDF for note attachments, 5MB/images for project screenshots) — not just a client-side check
- RLS policies on `storage.objects` restricting writes to a path prefixed by the uploader's own `auth.uid()` (`storage.foldername(name)[1] = auth.uid()::text`), so a user can only write into their own folder, never overwrite or delete someone else's file
- Randomized filenames (`crypto.randomUUID()`, not the original filename) to avoid path collisions and prevent guessing another user's upload path
- Client-side validation (`src/lib/uploadFile.ts`) for fast feedback only — the bucket config and RLS above are the actual enforcement

**Not implemented:** magic-byte/file-signature validation (only the browser-reported MIME type is checked, which a malicious client could spoof — the bucket's own `allowed_mime_types` is a second, server-side check against the same client-reported type, not an independent content inspection) and malware scanning. Given the restriction to images and PDFs specifically (not arbitrary file types, no executables, no HTML/SVG), the realistic exploitation surface for a spoofed MIME type is low but not zero — a deliberately malformed file could still be uploaded and would be served back to other users if opened. **Not verified against a live project**: whether the `INSERT INTO storage.buckets` statements in the migration succeed depends on your project's exact Storage schema permissions for the migration role — if it fails, create the three buckets via the Dashboard's Storage UI instead (same names/settings documented in the migration file) and the RLS policies will still apply correctly.

## AI features

Implemented as a Supabase Edge Function (`supabase/functions/ai-assistant/index.ts`) plus a client chat UI (`/assistant`) — but **this does not work out of the box**. It requires:
1. Deploying the function: `supabase functions deploy ai-assistant`
2. Setting an API key secret: `supabase secrets set AI_API_KEY=sk-...` (any OpenAI-compatible provider)
3. Optionally `AI_API_URL` / `AI_MODEL` secrets if not using OpenAI directly

The architecture is real and deliberate: the API key lives only in the Edge Function's environment, never reaches the browser; every call verifies the caller's Supabase JWT server-side (no anonymous access — each call costs real money against the configured key); it reuses the app's existing `enforce_rate_limit()` mechanism rather than inventing separate throttling; input length and conversation history length are both capped.

**Not verified in any way** — no network access and no API key were available to test this against a live provider or a live Supabase project. The request/response parsing is written against OpenAI's chat-completions shape specifically; if you use a different provider, check that its response shape matches (`choices[0].message.content`) before trusting it in production.


## Deployment requirements

1. **HTTPS only** in production — configure HSTS enforcement at your CDN if you want it stricter than this app's conservative default.
2. **WAF/DDoS protection** — Cloudflare or equivalent, not provided by this codebase.
3. **`pg_cron`** — enable in Supabase Dashboard → Database → Extensions for automated cleanup and reminder jobs (rate-limit trim, notification cleanup, room cleanup, security-event trim). Several migrations attempt to schedule cron jobs and fail gracefully with a `RAISE NOTICE` if `pg_cron` isn't available — check your Postgres logs for these notices if scheduled cleanup doesn't seem to be running.
4. **Supabase password policy** — confirm the Dashboard's Authentication → Policies password requirements match or exceed the 8-character minimum set in `config.toml` for your actual hosted project.
5. **Supabase MFA** — enable in Authentication → Settings → Multi-Factor Authentication for the 2FA feature to function; it silently no-ops otherwise.
6. **Redirect URLs** — add `{your-origin}/reset-password` under Authentication → URL Configuration.
7. **Google OAuth** — enable under Authentication → Providers if Google sign-in is desired.
8. **First teacher account** — have that person sign up normally first (they'll get `student` like everyone else), then in the Supabase SQL editor run `SELECT public.bootstrap_first_teacher('their@email.com');`. This function only works while zero teachers exist and is not callable by `authenticated`/`anon` at any privilege level — it's a one-time, service-role-only setup step, not a self-service grant path. Every teacher after the first is added via `grant_role()`, called by an existing teacher from within the app. **Have that first person enroll MFA at `/settings/security` immediately after being granted the role** — until they do, they'll hit the `TeacherMfaGate` on `/moderation`/`/attendance` and every other teacher-gated policy will deny them too, same as any other unverified teacher session.
9. **Storage buckets** — confirm the three buckets (`avatars`, `note-attachments`, `project-images`) were actually created by their migration; if the `INSERT INTO storage.buckets` statements didn't have permission to run, create them manually via the Dashboard's Storage UI using the same names/settings documented in `20260824090000_storage_buckets.sql`.
10. **AI Assistant** — entirely optional. If you want it working: `supabase functions deploy ai-assistant`, then `supabase secrets set AI_API_KEY=sk-...` with your own LLM provider key. Without this, `/assistant` will show a clear "not configured yet" message rather than failing silently.

## Backup and recovery

Not addressed by this codebase — Supabase's own project-level backup settings (Dashboard → Database → Backups) are the relevant control, and are a hosting/plan decision outside application code. Not verified or configured here.

## Known limitations (explicit, not hidden)

- Meta-tag CSP fallback in `__root.tsx` still can't set `frame-ancestors`, but the real header version in `server.ts` now does — the meta tag is now genuinely redundant defense-in-depth rather than the primary mechanism.
- `'unsafe-inline'` remains on CSP script/style directives (see CSP section above).
- No session/device enumeration UI — only "sign out here" and "sign out everywhere," not a list of active sessions.
- Teacher role has platform-wide visibility with no per-class scoping.
- Dependency vulnerability status is unverified (no network access at review time).
- Two historical, orphaned duplicate migrations exist in migration history (a second `notifications` table definition and a `game_room_messages` table) — the notifications duplicate was neutralized to prevent a fresh-deploy failure; `game_room_messages` was left in place (unused but not insecure) rather than dropped, since this codebase cannot verify whether it holds real data in an already-deployed environment. See the migration files themselves for full explanation.
- This document, and the codebase it describes, has not been tested against a live, running Supabase instance from the environment it was built in. Structural/static verification (RLS coverage, grant/policy inspection, migration balance) was performed; runtime behavior (does a trigger actually fire, does a rate limit actually reject the second request) was not.

## Vulnerability reporting

If you find a security vulnerability in BCA Adda:

- Do not open a public GitHub issue for security vulnerabilities.
- Email the maintainer directly with a description, reproduction steps, and potential impact.
- Allow reasonable time for a fix before public disclosure.

## Audit history

- An initial security review identified several gaps (rate limiting, stale-room cleanup, CSP headers, 2FA, account deletion, etc.), which were implemented in an earlier pass.
- A subsequent independent audit re-verified that work and found: one finding (a signup-metadata role-escalation path) that was already fixed by an earlier migration the initial audit failed to trace forward through `CREATE OR REPLACE FUNCTION` history — corrected in this document rather than left as a false positive; a real stored-XSS gap in `subject_notes.url`; an account-deletion audit record that destroyed itself via cascading delete; missing rate limits on six tables; and a security-events table that allowed client-forgeable entries.
- This document reflects the state after remediating all of the above. It does not claim the remediation is complete or that no further issues exist — see "Known limitations" above.
