import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

// Manual Vite + TanStack Start config. Plugin order matters:
// tsConfigPaths first so the "@" alias resolves, then tanstackStart,
// then React, then Tailwind.
export default defineConfig({
  server: {
    port: 8080,
  },
  plugins: [
    tsConfigPaths(),
    tanstackStart({
      server: { entry: "server" },
    }),
    viteReact(),
    tailwindcss(),
  ],
});
