// Supabase Edge Function: AI study assistant for BCA Adda.
//
// THIS DOES NOT WORK OUT OF THE BOX. It requires:
//   1. Deploying this function: `supabase functions deploy ai-assistant`
//   2. Setting a secret with your LLM provider's API key:
//        supabase secrets set AI_API_KEY=sk-...
//      (get a key from OpenAI, Anthropic, or any OpenAI-compatible
//      provider — this function is written against the OpenAI chat
//      completions request/response shape, which most providers,
//      including several free/cheap ones, implement compatibly)
//   3. If your provider isn't OpenAI itself, also set:
//        supabase secrets set AI_API_URL=https://your-provider/v1/chat/completions
//        supabase secrets set AI_MODEL=your-model-name
//      (sensible defaults are used if these aren't set)
//
// None of this has been tested against a live provider or a live
// Supabase project from the environment this was written in — there is
// no network access here to verify it, and no API key to test with.
// The architecture (never expose the key to the browser, verify the
// caller's JWT, rate-limit, cap input/output size) is sound and
// deliberate; the exact request/response parsing should be checked
// against whichever provider you actually use before trusting it.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const AI_API_KEY = Deno.env.get("AI_API_KEY");
const AI_API_URL = Deno.env.get("AI_API_URL") ?? "https://api.openai.com/v1/chat/completions";
const AI_MODEL = Deno.env.get("AI_MODEL") ?? "gpt-4o-mini";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

const MAX_MESSAGE_LENGTH = 2000;
const MAX_HISTORY_MESSAGES = 20;
const SYSTEM_PROMPT =
  "You are a helpful study assistant for BCA (Bachelor of Computer Applications) students. " +
  "Help with programming concepts, coursework questions, and general study advice. " +
  "Keep answers concise and practical. If asked something outside academics/programming, " +
  "gently redirect to how you can help with studies.";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (!AI_API_KEY) {
    return new Response(
      JSON.stringify({ error: "AI assistant is not configured yet — the operator needs to set the AI_API_KEY secret." }),
      { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  try {
    // Verify the caller is a real, authenticated user — this function
    // must never be usable anonymously, since every call costs real
    // money against the configured API key.
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Not authenticated" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Not authenticated" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    // Rate limit via the same shared mechanism every other write path in
    // this app uses — reuses public.enforce_rate_limit() rather than
    // inventing separate throttling logic just for this function.
    const { error: rateLimitError } = await supabase.rpc("enforce_rate_limit", {
      _action: "ai_assistant_message",
      _min_interval: "3 seconds",
    });
    if (rateLimitError) {
      return new Response(JSON.stringify({ error: "You're sending messages too fast — slow down a little." }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const history: { role: "user" | "assistant"; content: string }[] = Array.isArray(body?.messages)
      ? body.messages.slice(-MAX_HISTORY_MESSAGES)
      : [];

    if (history.length === 0) {
      return new Response(JSON.stringify({ error: "No message provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    for (const m of history) {
      if (typeof m.content !== "string" || m.content.length > MAX_MESSAGE_LENGTH) {
        return new Response(JSON.stringify({ error: `Messages must be under ${MAX_MESSAGE_LENGTH} characters` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const providerRes = await fetch(AI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${AI_API_KEY}`,
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...history],
        max_tokens: 800,
        temperature: 0.5,
      }),
    });

    if (!providerRes.ok) {
      const detail = await providerRes.text().catch(() => "");
      console.error("AI provider error:", providerRes.status, detail);
      return new Response(JSON.stringify({ error: "The assistant is having trouble right now — try again shortly." }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await providerRes.json();
    // OpenAI-compatible response shape. If your provider's response
    // shape differs, this line is the one to adjust.
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string") {
      console.error("Unexpected AI provider response shape:", JSON.stringify(data).slice(0, 500));
      return new Response(JSON.stringify({ error: "Got an unexpected response from the assistant." }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ reply }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("ai-assistant function error:", err);
    return new Response(JSON.stringify({ error: "Something went wrong" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
