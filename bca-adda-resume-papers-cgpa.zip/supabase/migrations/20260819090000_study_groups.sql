-- Feature: study group scheduling. Public/open like channels — anyone
-- can see and RSVP, matching the school-wide open-room model already
-- used for chat. Optionally tied to an existing channel (topic room).

CREATE TABLE public.study_groups (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  channel_id uuid REFERENCES public.channels(id) ON DELETE SET NULL,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
  description text CHECK (description IS NULL OR char_length(description) <= 1000),
  location text CHECK (location IS NULL OR char_length(location) <= 300), -- room, or a call link
  scheduled_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX study_groups_scheduled_idx ON public.study_groups (scheduled_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.study_groups TO authenticated;
GRANT ALL ON public.study_groups TO service_role;
ALTER TABLE public.study_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "study groups viewable by authenticated"
ON public.study_groups FOR SELECT TO authenticated USING (true);

CREATE POLICY "users create study groups"
ON public.study_groups FOR INSERT TO authenticated
WITH CHECK (auth.uid() = created_by);

CREATE POLICY "organizer or teacher can update"
ON public.study_groups FOR UPDATE TO authenticated
USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'teacher'))
WITH CHECK (auth.uid() = created_by OR public.has_role(auth.uid(), 'teacher'));

CREATE POLICY "organizer or teacher can delete"
ON public.study_groups FOR DELETE TO authenticated
USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'teacher'));

ALTER TABLE public.study_groups REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.study_groups;

CREATE TABLE public.study_group_rsvps (
  group_id uuid NOT NULL REFERENCES public.study_groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reminded boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (group_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.study_group_rsvps TO authenticated;
GRANT ALL ON public.study_group_rsvps TO service_role;
ALTER TABLE public.study_group_rsvps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "rsvps viewable by authenticated"
ON public.study_group_rsvps FOR SELECT TO authenticated USING (true);

CREATE POLICY "users rsvp for themselves"
ON public.study_group_rsvps FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users cancel their own rsvp"
ON public.study_group_rsvps FOR DELETE TO authenticated
USING (auth.uid() = user_id);

ALTER TABLE public.study_group_rsvps REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.study_group_rsvps;

-- allow the new notification type
ALTER TABLE public.notifications DROP CONSTRAINT notifications_type_check;
ALTER TABLE public.notifications ADD CONSTRAINT notifications_type_check
  CHECK (type IN ('dm', 'mention', 'friend_request', 'friend_accepted', 'assignment_due', 'study_group'));

-- reminds everyone who RSVP'd, once, about an hour before start
CREATE OR REPLACE FUNCTION public.remind_upcoming_study_groups()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_group record;
  v_member uuid;
BEGIN
  FOR v_group IN
    SELECT * FROM public.study_groups
    WHERE scheduled_at BETWEEN now() AND now() + interval '1 hour'
  LOOP
    FOR v_member IN
      SELECT user_id FROM public.study_group_rsvps
      WHERE group_id = v_group.id AND reminded = false
    LOOP
      INSERT INTO public.notifications (user_id, type, title, body, link)
      VALUES (
        v_member,
        'study_group',
        '"' || v_group.title || '" starts soon',
        to_char(v_group.scheduled_at, 'HH12:MI AM') || COALESCE(' — ' || v_group.location, ''),
        '/study-groups'
      );
    END LOOP;
    UPDATE public.study_group_rsvps SET reminded = true WHERE group_id = v_group.id AND reminded = false;
  END LOOP;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.remind_upcoming_study_groups() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.remind_upcoming_study_groups() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'remind-upcoming-study-groups',
    '*/15 * * * *',
    $cron$SELECT public.remind_upcoming_study_groups();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.remind_upcoming_study_groups() manually if pg_cron is unavailable.', SQLERRM;
END;
$$;
