-- Feature 6: Checkers. Standard American checkers rules on an 8x8 board
-- (32 playable dark squares, stored as a flat 64-cell array for simplicity
-- like othello_games — only cells where (row+col) is odd are ever used).
-- Pieces: 0 empty, 1 host man, 2 guest man, 3 host king, 4 guest king.
-- Host starts on rows 0-2 and advances toward row 7; guest starts on
-- rows 5-7 and advances toward row 0.
--
-- This is the most algorithmically involved game in the app: captures are
-- mandatory when available, and a piece that captures must keep capturing
-- with the SAME piece if another capture is immediately available (no
-- turn hand-off mid-chain). `must_continue_from` tracks that mid-chain
-- state between moves of the same turn.

CREATE TABLE public.checkers_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  board smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[64]),
  turn smallint NOT NULL DEFAULT 1,
  must_continue_from smallint, -- cell index a mid-chain jump must continue from, else null
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.checkers_games TO authenticated;
GRANT ALL ON public.checkers_games TO service_role;
ALTER TABLE public.checkers_games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "players view their checkers game"
ON public.checkers_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER checkers_games_touch
BEFORE UPDATE ON public.checkers_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.checkers_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.checkers_games;

CREATE TRIGGER checkers_games_rate_limit
BEFORE INSERT ON public.checkers_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER checkers_games_record_result
AFTER UPDATE ON public.checkers_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();

-- Pure helper: for piece at (r,c) belonging to `_me`, list every capture
-- landing cell available right now (0-based cell indices). A "capture"
-- jumps one diagonal opponent piece and lands on the empty cell beyond it.
-- Kings (3,4) can capture in all 4 diagonal directions; men only forward.
CREATE OR REPLACE FUNCTION public.checkers_captures_from(_board smallint[], _r int, _c int, _me smallint)
RETURNS int[]
LANGUAGE plpgsql
AS $$
DECLARE
  piece smallint := _board[_r*8+_c+1];
  is_king boolean := piece IN (3,4);
  opp1 smallint; opp2 smallint;
  dirs int[][];
  d int; dr int; dc int; mr int; mc int; lr int; lc int;
  out int[] := ARRAY[]::int[];
BEGIN
  IF _me = 1 THEN opp1 := 2; opp2 := 4; ELSE opp1 := 1; opp2 := 3; END IF;

  IF is_king THEN
    dirs := ARRAY[[-1,-1],[-1,1],[1,-1],[1,1]];
  ELSIF _me = 1 THEN
    dirs := ARRAY[[1,-1],[1,1]]; -- host men move toward row 7
  ELSE
    dirs := ARRAY[[-1,-1],[-1,1]]; -- guest men move toward row 0
  END IF;

  FOR d IN 1..array_length(dirs,1) LOOP
    dr := dirs[d][1]; dc := dirs[d][2];
    mr := _r+dr; mc := _c+dc;       -- the (potential) captured piece
    lr := _r+2*dr; lc := _c+2*dc;   -- the landing square
    IF mr BETWEEN 0 AND 7 AND mc BETWEEN 0 AND 7 AND lr BETWEEN 0 AND 7 AND lc BETWEEN 0 AND 7 THEN
      IF (_board[mr*8+mc+1] = opp1 OR _board[mr*8+mc+1] = opp2) AND _board[lr*8+lc+1] = 0 THEN
        out := out || (lr*8+lc);
      END IF;
    END IF;
  END LOOP;

  RETURN out;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.checkers_captures_from(smallint[], int, int, smallint) FROM PUBLIC, anon;

-- Pure helper: does `_me` have ANY capture available anywhere on the board?
-- Used to enforce the mandatory-capture rule.
CREATE OR REPLACE FUNCTION public.checkers_any_capture(_board smallint[], _me smallint)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  r int; c int;
  mine smallint[];
BEGIN
  IF _me = 1 THEN mine := ARRAY[1,3]; ELSE mine := ARRAY[2,4]; END IF;
  FOR r IN 0..7 LOOP
    FOR c IN 0..7 LOOP
      IF _board[r*8+c+1] = ANY(mine) THEN
        IF array_length(public.checkers_captures_from(_board, r, c, _me), 1) > 0 THEN
          RETURN true;
        END IF;
      END IF;
    END LOOP;
  END LOOP;
  RETURN false;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.checkers_any_capture(smallint[], smallint) FROM PUBLIC, anon;

-- Does `_me` have any legal move at all (capture or simple slide)? Used to
-- detect a loss-by-no-moves.
CREATE OR REPLACE FUNCTION public.checkers_any_move(_board smallint[], _me smallint)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  r int; c int; piece smallint; is_king boolean;
  dirs int[][]; d int; dr int; dc int; nr int; nc int;
  mine smallint[];
BEGIN
  IF public.checkers_any_capture(_board, _me) THEN RETURN true; END IF;
  IF _me = 1 THEN mine := ARRAY[1,3]; ELSE mine := ARRAY[2,4]; END IF;
  FOR r IN 0..7 LOOP
    FOR c IN 0..7 LOOP
      piece := _board[r*8+c+1];
      IF piece = ANY(mine) THEN
        is_king := piece IN (3,4);
        IF is_king THEN dirs := ARRAY[[-1,-1],[-1,1],[1,-1],[1,1]];
        ELSIF _me = 1 THEN dirs := ARRAY[[1,-1],[1,1]];
        ELSE dirs := ARRAY[[-1,-1],[-1,1]]; END IF;
        FOR d IN 1..array_length(dirs,1) LOOP
          nr := r+dirs[d][1]; nc := c+dirs[d][2];
          IF nr BETWEEN 0 AND 7 AND nc BETWEEN 0 AND 7 AND _board[nr*8+nc+1] = 0 THEN
            RETURN true;
          END IF;
        END LOOP;
      END IF;
    END LOOP;
  END LOOP;
  RETURN false;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.checkers_any_move(smallint[], smallint) FROM PUBLIC, anon;

CREATE OR REPLACE FUNCTION public.checkers_create_game()
RETURNS public.checkers_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.checkers_games;
  v_board smallint[] := array_fill(0::smallint, ARRAY[64]);
  r int; c int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  -- standard setup: 12 men each, on dark squares only, 3 rows deep
  FOR r IN 0..2 LOOP
    FOR c IN 0..7 LOOP
      IF (r+c) % 2 = 1 THEN v_board[r*8+c+1] := 1; END IF;
    END LOOP;
  END LOOP;
  FOR r IN 5..7 LOOP
    FOR c IN 0..7 LOOP
      IF (r+c) % 2 = 1 THEN v_board[r*8+c+1] := 2; END IF;
    END LOOP;
  END LOOP;

  INSERT INTO public.checkers_games (code, host_id, board, status, last_message)
  VALUES (v_code, auth.uid(), v_board, 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.checkers_join_game(_code text)
RETURNS public.checkers_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.checkers_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.checkers_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.checkers_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Host moves first.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

-- Moves a piece from `_from` to `_to` (0-based cell indices). Handles both
-- simple slides and captures; enforces mandatory capture; enforces the
-- multi-jump chain (if the piece that just captured has another capture
-- available, the turn does not pass and the next call must move that same
-- piece again); promotes to king on reaching the far row.
CREATE OR REPLACE FUNCTION public.checkers_move(_game_id uuid, _from smallint, _to smallint)
RETURNS public.checkers_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.checkers_games;
  v_is_host boolean;
  v_me smallint; v_opp smallint;
  v_board smallint[];
  v_from_r int; v_from_c int; v_to_r int; v_to_c int;
  v_piece smallint;
  v_is_capture boolean := false;
  v_mid_r int; v_mid_c int; v_mid_idx int;
  v_must_capture boolean;
  v_status text := 'playing';
  v_winner uuid;
  v_msg text;
  v_next_turn smallint;
  v_continue smallint;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _from < 0 OR _from > 63 OR _to < 0 OR _to > 63 THEN RAISE EXCEPTION 'Invalid cell'; END IF;

  SELECT * INTO v_game FROM public.checkers_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true; v_me := 1; v_opp := 2;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false; v_me := 2; v_opp := 1;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF v_game.turn <> v_me THEN RAISE EXCEPTION 'Not your turn'; END IF;

  IF v_game.must_continue_from IS NOT NULL AND v_game.must_continue_from <> _from THEN
    RAISE EXCEPTION 'You must keep capturing with the same piece';
  END IF;

  v_board := v_game.board;
  v_piece := v_board[_from+1];
  IF v_piece <> v_me AND v_piece <> v_me + 2 THEN RAISE EXCEPTION 'That is not your piece'; END IF;
  IF v_board[_to+1] <> 0 THEN RAISE EXCEPTION 'Destination is occupied'; END IF;

  v_from_r := _from / 8; v_from_c := _from % 8;
  v_to_r := _to / 8; v_to_c := _to % 8;

  -- must this move be a capture? (mandatory-capture rule, checked against
  -- the whole board unless already mid-chain, in which case only this
  -- piece's own captures matter)
  IF v_game.must_continue_from IS NOT NULL THEN
    v_must_capture := true;
  ELSE
    v_must_capture := public.checkers_any_capture(v_board, v_me);
  END IF;

  IF abs(v_to_r - v_from_r) = 2 AND abs(v_to_c - v_from_c) = 2 THEN
    v_mid_r := (v_from_r + v_to_r) / 2; v_mid_c := (v_from_c + v_to_c) / 2;
    v_mid_idx := v_mid_r*8+v_mid_c;
    IF v_board[v_mid_idx+1] <> v_opp AND v_board[v_mid_idx+1] <> v_opp + 2 THEN
      RAISE EXCEPTION 'No piece to capture there';
    END IF;
    v_is_capture := true;
  ELSIF abs(v_to_r - v_from_r) = 1 AND abs(v_to_c - v_from_c) = 1 THEN
    IF v_must_capture THEN RAISE EXCEPTION 'A capture is available — you must take it'; END IF;
  ELSE
    RAISE EXCEPTION 'Illegal move shape';
  END IF;

  -- direction check for men (kings can go any diagonal direction)
  IF v_piece = 1 AND v_to_r <= v_from_r THEN RAISE EXCEPTION 'Men can only move forward'; END IF;
  IF v_piece = 2 AND v_to_r >= v_from_r THEN RAISE EXCEPTION 'Men can only move forward'; END IF;

  v_board[_from+1] := 0;
  v_board[_to+1] := v_piece;
  IF v_is_capture THEN v_board[v_mid_idx+1] := 0; END IF;

  -- promotion
  IF v_piece = 1 AND v_to_r = 7 THEN v_board[_to+1] := 3; END IF;
  IF v_piece = 2 AND v_to_r = 0 THEN v_board[_to+1] := 4; END IF;

  v_continue := NULL;
  IF v_is_capture AND array_length(public.checkers_captures_from(v_board, v_to_r, v_to_c, v_me), 1) > 0 THEN
    v_continue := _to; -- must keep jumping with this same piece
  END IF;

  IF v_continue IS NOT NULL THEN
    v_next_turn := v_me;
    v_msg := 'Keep capturing with the same piece!';
  ELSE
    v_next_turn := v_opp;
    v_msg := (CASE WHEN v_next_turn = v_me THEN 'Your' ELSE 'Opponent''s' END) || ' turn.';
  END IF;

  -- check if the player about to move next has any legal move at all
  IF v_continue IS NULL THEN
    IF NOT public.checkers_any_move(v_board, v_opp) THEN
      v_status := 'finished';
      v_winner := auth.uid();
      v_msg := (CASE WHEN v_is_host THEN 'Host' ELSE 'Guest' END) || ' wins — the other side has no moves left!';
    END IF;
  END IF;

  UPDATE public.checkers_games
    SET board = v_board,
        turn = CASE WHEN v_status = 'playing' THEN v_next_turn ELSE turn END,
        must_continue_from = v_continue,
        status = v_status,
        winner_id = v_winner,
        last_message = v_msg,
        updated_at = now()
    WHERE id = _game_id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.checkers_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.checkers_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.checkers_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.checkers_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.checkers_move(uuid, smallint, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.checkers_leave_game(uuid) TO authenticated;

-- include checkers in the stale-room cleanup job
CREATE OR REPLACE FUNCTION public.cleanup_stale_game_rooms()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.war_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.bg_rooms WHERE status = 'lobby' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.connect_four_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.tic_tac_toe_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.rps_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.battleship_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.othello_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.dots_boxes_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.checkers_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
END;
$$;
