-- Security fix: the rate_limits table grows forever because entries are
-- only ever upserted (never deleted). Trim entries not seen in 30+ days
-- so inactive users don't pile up indefinitely.

CREATE OR REPLACE FUNCTION public.cleanup_stale_rate_limits()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.rate_limits WHERE last_at < now() - interval '30 days';
END;
$$;
REVOKE EXECUTE ON FUNCTION public.cleanup_stale_rate_limits() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_stale_rate_limits() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'cleanup-stale-rate-limits',
    '0 5 1 * *',  -- 5 AM on the 1st of each month
    $cron$SELECT public.cleanup_stale_rate_limits();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.cleanup_stale_rate_limits() manually if pg_cron is unavailable.', SQLERRM;
END;
$$;
