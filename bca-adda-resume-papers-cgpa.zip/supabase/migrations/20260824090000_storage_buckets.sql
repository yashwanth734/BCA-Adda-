-- File uploads: two Storage buckets. Both public-read (avatars and
-- shared note attachments are meant to be visible to everyone, matching
-- the existing "open school" model for profiles/notes) but write-scoped
-- so a user can only write into a path prefixed by their own user id —
-- storage.foldername(name)[1] must equal auth.uid(), same ownership
-- pattern used everywhere else in this schema, just applied to file
-- paths instead of table rows.

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('avatars', 'avatars', true, 2097152, ARRAY['image/jpeg','image/png','image/webp','image/gif'])
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('note-attachments', 'note-attachments', true, 10485760, ARRAY['image/jpeg','image/png','image/webp','image/gif','application/pdf'])
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('project-images', 'project-images', true, 5242880, ARRAY['image/jpeg','image/png','image/webp','image/gif'])
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "avatars are publicly readable"
ON storage.objects FOR SELECT TO authenticated, anon
USING (bucket_id = 'avatars');

CREATE POLICY "users upload their own avatar"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "users replace their own avatar"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "users delete their own avatar"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "note attachments are publicly readable"
ON storage.objects FOR SELECT TO authenticated, anon
USING (bucket_id = 'note-attachments');

CREATE POLICY "users upload their own note attachments"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'note-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "users delete their own note attachments"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'note-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "project images are publicly readable"
ON storage.objects FOR SELECT TO authenticated, anon
USING (bucket_id = 'project-images');

CREATE POLICY "users upload their own project images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'project-images' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "users delete their own project images"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'project-images' AND (storage.foldername(name))[1] = auth.uid()::text);

-- NOTE: bucket-level file_size_limit/allowed_mime_types and the RLS
-- policies above are the real, server-side enforcement. Client-side
-- validation (src/lib/uploadFile.ts) exists only for fast user feedback
-- before a doomed upload attempt — same defense-in-depth relationship
-- as sanitizeHttpsUrl and the DB-level URL scheme CHECK constraints.
--
-- NOT VERIFIED against a live Supabase project: whether `storage.buckets`
-- accepts a plain INSERT this way depends on your project's exact
-- Storage schema permissions for the migration role. If this fails when
-- applied, create the three buckets via the Supabase Dashboard's Storage
-- UI instead (Storage → New bucket, matching the names/settings above)
-- and the RLS policies in this file will still apply to them correctly.
