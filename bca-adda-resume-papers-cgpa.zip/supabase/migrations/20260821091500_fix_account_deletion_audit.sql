-- Remediation of HIGH-04: delete_own_account() previously inserted an
-- 'account_deleted' row into security_events, then immediately deleted
-- the auth.users row. Because security_events.user_id has
-- ON DELETE CASCADE, that insert was destroyed by the very deletion it
-- was supposed to record — there was never a permanent trace that an
-- account had been deleted.
--
-- Fix: a separate table that does NOT reference auth.users as a foreign
-- key at all, so it structurally cannot be cascade-deleted. It stores
-- only the user's UUID (meaningless on its own once the account is
-- gone — not a re-identification risk) and a timestamp. No username, no
-- email, no profile data — deletion is supposed to erase personal
-- information, so the audit trail for it shouldn't quietly preserve any.

CREATE TABLE public.account_deletion_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  deleted_user_id uuid NOT NULL, -- deliberately NOT a foreign key — see above
  deletion_reason text NOT NULL DEFAULT 'self_service' CHECK (deletion_reason IN ('self_service', 'admin_action')),
  deleted_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX account_deletion_log_user_idx ON public.account_deletion_log (deleted_user_id);

GRANT SELECT ON public.account_deletion_log TO authenticated;
GRANT ALL ON public.account_deletion_log TO service_role;
ALTER TABLE public.account_deletion_log ENABLE ROW LEVEL SECURITY;

-- teachers only — this is an operational/incident-response record, not
-- something a student needs to see, and it's about accounts that no
-- longer exist to have an "owner" who could view their own row anyway.
CREATE POLICY "teachers can review account deletion log"
ON public.account_deletion_log FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'teacher'));
-- no INSERT policy for authenticated at all — only reachable through
-- delete_own_account() below (SECURITY DEFINER), so a normal user
-- cannot forge a fake deletion record for themselves or anyone else.

CREATE OR REPLACE FUNCTION public.delete_own_account()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;

  -- record the deletion in the decoupled log BEFORE the cascade, so it
  -- survives the cascade (no FK relationship to break)
  INSERT INTO public.account_deletion_log (deleted_user_id, deletion_reason)
  VALUES (v_uid, 'self_service');

  DELETE FROM auth.users WHERE id = v_uid;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.delete_own_account() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_own_account() TO authenticated;
