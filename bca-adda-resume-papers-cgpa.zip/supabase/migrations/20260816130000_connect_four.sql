-- Connect Four: a second real-time head-to-head multiplayer game, built on
-- the same room-code pattern as war_games. Board state has no hidden
-- information (both players can see the whole grid), so this needs no
-- private table the way War does — one public row is enough.

CREATE TABLE public.connect_four_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  -- 42 cells, row-major, 7 columns x 6 rows. 0 = empty, 1 = host, 2 = guest.
  board smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[42]),
  turn smallint NOT NULL DEFAULT 1, -- 1 = host's turn, 2 = guest's turn
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.connect_four_games TO authenticated;
GRANT ALL ON public.connect_four_games TO service_role;

ALTER TABLE public.connect_four_games ENABLE ROW LEVEL SECURITY;

-- Read-only for players; every write happens through the RPCs below so the
-- server is always the one validating whose turn it is and where pieces land.
CREATE POLICY "players view their connect four game"
ON public.connect_four_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER connect_four_games_touch
BEFORE UPDATE ON public.connect_four_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.connect_four_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.connect_four_games;

CREATE OR REPLACE FUNCTION public.connect_four_create_game()
RETURNS public.connect_four_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.connect_four_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  INSERT INTO public.connect_four_games (code, host_id, status, last_message)
  VALUES (v_code, auth.uid(), 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.connect_four_join_game(_code text)
RETURNS public.connect_four_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.connect_four_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.connect_four_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.connect_four_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Host drops first.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

-- Drops a piece into the lowest open cell of the given column (0-6).
-- Checks win conditions (4 in a row: horizontal, vertical, both diagonals)
-- and a full-board draw, all server-side so no client can fake a result.
CREATE OR REPLACE FUNCTION public.connect_four_drop(_game_id uuid, _col smallint)
RETURNS public.connect_four_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.connect_four_games;
  v_is_host boolean;
  v_me smallint;
  v_row smallint;
  v_idx smallint;
  v_board smallint[];
  v_winner uuid;
  v_status text := 'playing';
  v_msg text;
  v_full boolean;

  -- direction vectors for the four ways to make a line of 4
  dr smallint[] := ARRAY[0, 1, 1, 1]::smallint[];
  dc smallint[] := ARRAY[1, 0, 1, -1]::smallint[];
  d smallint;
  r0 smallint; c0 smallint; count smallint; rr smallint; cc smallint; step smallint;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _col < 0 OR _col > 6 THEN RAISE EXCEPTION 'Invalid column'; END IF;

  SELECT * INTO v_game FROM public.connect_four_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true; v_me := 1;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false; v_me := 2;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF v_game.turn <> v_me THEN RAISE EXCEPTION 'Not your turn'; END IF;

  v_board := v_game.board;

  -- find lowest empty row in this column (row 5 = bottom, row 0 = top)
  v_row := -1;
  FOR r0 IN REVERSE 5..0 LOOP
    v_idx := r0 * 7 + _col + 1; -- 1-based array index
    IF v_board[v_idx] = 0 THEN v_row := r0; EXIT; END IF;
  END LOOP;
  IF v_row = -1 THEN RAISE EXCEPTION 'Column is full'; END IF;

  v_idx := v_row * 7 + _col + 1;
  v_board[v_idx] := v_me;

  -- check all 4 directions from the just-placed piece for a line of 4
  FOR d IN 1..4 LOOP
    count := 1;
    rr := v_row + dr[d]; cc := _col + dc[d];
    WHILE rr BETWEEN 0 AND 5 AND cc BETWEEN 0 AND 6
      AND v_board[rr * 7 + cc + 1] = v_me LOOP
      count := count + 1;
      rr := rr + dr[d]; cc := cc + dc[d];
    END LOOP;
    rr := v_row - dr[d]; cc := _col - dc[d];
    WHILE rr BETWEEN 0 AND 5 AND cc BETWEEN 0 AND 6
      AND v_board[rr * 7 + cc + 1] = v_me LOOP
      count := count + 1;
      rr := rr - dr[d]; cc := cc - dc[d];
    END LOOP;
    IF count >= 4 THEN
      v_status := 'finished';
      v_winner := auth.uid();
      v_msg := (CASE WHEN v_is_host THEN 'Host' ELSE 'Guest' END) || ' connects four and wins!';
      EXIT;
    END IF;
  END LOOP;

  IF v_status = 'playing' THEN
    v_full := NOT (0 = ANY(v_board));
    IF v_full THEN
      v_status := 'finished';
      v_msg := 'Board is full — it''s a draw!';
    ELSE
      v_msg := (CASE WHEN v_is_host THEN 'Guest' ELSE 'Host' END) || '''s turn.';
    END IF;
  END IF;

  UPDATE public.connect_four_games
    SET board = v_board,
        turn = CASE WHEN v_status = 'playing' THEN (CASE WHEN v_me = 1 THEN 2 ELSE 1 END) ELSE turn END,
        status = v_status,
        winner_id = v_winner,
        last_message = v_msg,
        updated_at = now()
    WHERE id = _game_id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.connect_four_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.connect_four_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.connect_four_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.connect_four_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.connect_four_drop(uuid, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.connect_four_leave_game(uuid) TO authenticated;
