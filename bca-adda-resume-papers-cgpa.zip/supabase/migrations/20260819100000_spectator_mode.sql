-- Spectator mode: anyone authenticated can read a playing/finished game
-- given its code, not just the two players. The existing RLS policies
-- restrict SELECT to host_id = auth.uid() OR guest_id = auth.uid(), which
-- blocks spectators. We add a second SELECT policy for each table that
-- allows read-only access once the game is playing or finished —
-- "waiting" rooms stay private until an opponent joins, since the room
-- code isn't shared publicly yet.

-- connect_four_games
CREATE POLICY "spectators view playing/finished connect four"
ON public.connect_four_games FOR SELECT TO authenticated
USING (status IN ('playing','finished'));

-- tic_tac_toe_games
CREATE POLICY "spectators view playing/finished tic tac toe"
ON public.tic_tac_toe_games FOR SELECT TO authenticated
USING (status IN ('playing','finished'));

-- battleship_games (shot arrays are already public info once fired)
CREATE POLICY "spectators view playing/finished battleship"
ON public.battleship_games FOR SELECT TO authenticated
USING (status IN ('playing','finished'));

-- othello_games
CREATE POLICY "spectators view playing/finished othello"
ON public.othello_games FOR SELECT TO authenticated
USING (status IN ('playing','finished'));

-- dots_boxes_games
CREATE POLICY "spectators view playing/finished dots and boxes"
ON public.dots_boxes_games FOR SELECT TO authenticated
USING (status IN ('playing','finished'));

-- checkers_games
CREATE POLICY "spectators view playing/finished checkers"
ON public.checkers_games FOR SELECT TO authenticated
USING (status IN ('playing','finished'));

-- rps_games: intentionally excluded — picks are hidden info until revealed;
-- spectating a finished RPS game via the players-only policy already works
-- once the match ends, but watching live would expose last_host_choice /
-- last_guest_choice before the round resolves. Skip it.

-- NOTE: battleship_games_private (ship positions) deliberately has NO
-- spectator policy — hidden info must stay hidden even to spectators.
