-- Role security hardening (remediation of audit finding CRIT-01).
--
-- IMPORTANT CONTEXT: an early migration (20260726062752...) originally
-- defined handle_new_user_role() to read a `role` value out of
-- raw_user_meta_data — client-controlled data at signup. A later migration
-- (20260811094932...) already replaced that function body via
-- CREATE OR REPLACE FUNCTION to hardcode 'student' and ignore metadata
-- entirely, closing the hole. This migration doesn't change that live
-- behavior (it was already correct) — it exists so nobody reviewing this
-- codebase has to trace CREATE OR REPLACE overrides across migration
-- history to be sure, the way a prior review here initially got wrong.
-- This is now the single authoritative definition.

CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  -- Deliberately ignores NEW.raw_user_meta_data. Client-supplied signup
  -- metadata must NEVER determine authorization. Every new account is
  -- exactly 'student'; elevation only happens through grant_role() below,
  -- which requires an existing teacher to call it.
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'student')
  ON CONFLICT (user_id, role) DO NOTHING;
  RETURN NEW;
END;
$$;

-- No legitimate path previously existed for turning a student into a
-- teacher other than direct database access. This RPC is that path:
-- callable only by an existing teacher, target and role are both
-- validated, self-escalation and de-escalation-of-others-by-non-teachers
-- are blocked, and every grant/revoke is recorded in security_events.
CREATE OR REPLACE FUNCTION public.grant_role(_target_user uuid, _role public.app_role)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_target_exists boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF NOT public.has_role(auth.uid(), 'teacher') THEN
    RAISE EXCEPTION 'Only an existing teacher can grant roles';
  END IF;
  -- _role is already constrained to the public.app_role enum by the
  -- function signature — Postgres rejects any value outside
  -- ('student','teacher') before the function body even runs. That is
  -- the allowlist; no separate IN (...) check is needed here.

  SELECT EXISTS (SELECT 1 FROM auth.users WHERE id = _target_user) INTO v_target_exists;
  IF NOT v_target_exists THEN RAISE EXCEPTION 'Target user not found'; END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (_target_user, _role)
  ON CONFLICT (user_id, role) DO NOTHING;

  INSERT INTO public.security_events (user_id, event_type, detail)
  VALUES (_target_user, 'role_granted', _role::text || ' granted by a teacher');
END;
$$;
REVOKE EXECUTE ON FUNCTION public.grant_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.grant_role(uuid, public.app_role) TO authenticated;

-- Revoke: same authorization model, plus an explicit block on a teacher
-- removing their own last remaining teacher grant would be a footgun,
-- not a security hole — that's a UX guard, not enforced here, since
-- Supabase's own dashboard/service role remains the real safety net for
-- "the school has zero teachers left" scenarios.
CREATE OR REPLACE FUNCTION public.revoke_role(_target_user uuid, _role public.app_role)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF NOT public.has_role(auth.uid(), 'teacher') THEN
    RAISE EXCEPTION 'Only an existing teacher can revoke roles';
  END IF;
  IF _target_user = auth.uid() AND _role = 'teacher' THEN
    RAISE EXCEPTION 'Cannot revoke your own teacher role — ask another teacher to do it';
  END IF;
  IF _role = 'student' THEN
    RAISE EXCEPTION 'The student role cannot be revoked — every account keeps it as a baseline';
  END IF;

  DELETE FROM public.user_roles WHERE user_id = _target_user AND role = _role;

  INSERT INTO public.security_events (user_id, event_type, detail)
  VALUES (_target_user, 'role_revoked', _role::text || ' revoked by a teacher');
END;
$$;
REVOKE EXECUTE ON FUNCTION public.revoke_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.revoke_role(uuid, public.app_role) TO authenticated;
