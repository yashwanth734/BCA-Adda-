-- Login-failure detection, done safely.
--
-- This was previously left unimplemented (see SECURITY.md history) for
-- two reasons: (1) a failed login has no auth.uid() session, so it can't
-- satisfy security_events' normal "auth.uid() = user_id" RLS, and (2) a
-- naive fix — letting anyone insert with a client-supplied user_id —
-- would let an attacker write fake "someone tried to log into your
-- account" spam against any known UUID.
--
-- Supabase does offer a proper server-side mechanism for this (Auth
-- Hooks — specifically a "Password Verification Attempt" hook that fires
-- from Supabase's own trusted auth flow, not from client-submitted
-- data). That would be the more architecturally correct approach, but
-- its exact JSONB request/response contract isn't something that can be
-- verified without a live Supabase project, and a mistake in a function
-- wired into the login path itself risks breaking sign-in for everyone.
-- That's too much risk to take blind, so this migration takes a
-- different, fully self-contained and verifiable approach instead:
--
--   - A SECURITY DEFINER RPC, callable by anon (no session exists yet
--     when a login fails) AND authenticated (covers the account-deletion
--     re-auth flow, which also calls signInWithPassword and can fail).
--   - Takes an email, resolves it to a user id INTERNALLY — the caller
--     never supplies a user id directly, closing the original
--     "write fake events against a known UUID" hole.
--   - Never reveals via return value or error message whether the email
--     exists — the function is called fire-and-forget from the client
--     and its result is always ignored, so it cannot be used to enumerate
--     valid accounts by checking for a different response.
--   - Rate-limited by the TARGET account, not the caller — an anonymous
--     caller has no auth.uid() to rate-limit against, so limiting by
--     whoever's email was passed in is what actually stops someone from
--     flooding a specific victim's audit log with fake failure noise.

CREATE OR REPLACE FUNCTION public.log_login_failure(_email text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_last timestamptz;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE lower(email) = lower(trim(_email));
  IF v_user_id IS NULL THEN
    RETURN; -- silently no-op — never confirm or deny that an email exists
  END IF;

  SELECT last_at INTO v_last FROM public.rate_limits
    WHERE user_id = v_user_id AND action = 'login_failure_log' FOR UPDATE;
  IF v_last IS NOT NULL AND now() - v_last < interval '3 seconds' THEN
    RETURN; -- silently drop rather than error, so timing can't be used to probe
  END IF;

  INSERT INTO public.rate_limits (user_id, action, last_at)
    VALUES (v_user_id, 'login_failure_log', now())
    ON CONFLICT (user_id, action) DO UPDATE SET last_at = now();

  INSERT INTO public.security_events (user_id, event_type)
  VALUES (v_user_id, 'login_failure');
EXCEPTION WHEN OTHERS THEN
  -- never let a logging failure surface to the caller in any way —
  -- this function's contract is "best-effort, silent, no information
  -- disclosure," full stop.
  NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.log_login_failure(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.log_login_failure(text) TO anon, authenticated;

-- allow the event type this function now actually produces
ALTER TABLE public.security_events DROP CONSTRAINT security_events_type_check;
ALTER TABLE public.security_events
  ADD CONSTRAINT security_events_type_check
  CHECK (event_type IN ('login_success','login_failure','password_change','mfa_enabled','mfa_disabled','logout','role_granted','role_revoked'))
  NOT VALID;
