-- "Teacher login should be strong" — enforced where it actually matters:
-- the database, not just a login-page nag. Every RLS policy and function
-- that currently checks has_role(auth.uid(), 'teacher') is upgraded to
-- also require the session's Authenticator Assurance Level to be aal2 —
-- meaning this specific session has completed an MFA challenge, not just
-- "this account has the teacher role somewhere in its history."
--
-- Supabase issues aal2 in the session JWT only after a verified MFA
-- factor's challenge is completed. An account that has never enrolled
-- MFA can only ever be aal1, forever — the role check alone already
-- excludes students from all of this, so this only tightens what an
-- account WITH the teacher role can do without also having verified a
-- second factor this session. This is Supabase's own documented pattern
-- for MFA-gating sensitive data via RLS, not a custom invention.
--
-- OPERATIONAL IMPACT, READ BEFORE APPLYING: any existing teacher account
-- that has not enrolled MFA will immediately lose access to every
-- teacher-gated feature (moderation, security events, role management,
-- attendance grading, etc.) the moment this migration is applied — not
-- as a bug, that is the whole point of "strong." Have every current
-- teacher enroll MFA at /settings/security BEFORE deploying this, or
-- warn them it's coming. There is no soft-rollout switch here by design
-- — a "soft" MFA requirement that data can still be reached without is
-- not actually a requirement.

CREATE OR REPLACE FUNCTION public.has_verified_teacher_role()
RETURNS boolean
LANGUAGE sql STABLE SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'teacher')
    AND coalesce(auth.jwt() ->> 'aal', '') = 'aal2';
$$;
REVOKE EXECUTE ON FUNCTION public.has_verified_teacher_role() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_verified_teacher_role() TO authenticated;

-- ---------------------------------------------------------------------
-- messages: chat moderation
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "Teachers can moderate messages" ON public.messages;
CREATE POLICY "Teachers can moderate messages" ON public.messages
  FOR UPDATE TO authenticated
  USING (public.has_verified_teacher_role())
  WITH CHECK (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- reports: the moderation queue itself
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "Teachers can view all reports" ON public.reports;
CREATE POLICY "Teachers can view all reports" ON public.reports
  FOR SELECT TO authenticated USING (public.has_verified_teacher_role());

DROP POLICY IF EXISTS "Teachers can update reports" ON public.reports;
CREATE POLICY "Teachers can update reports" ON public.reports
  FOR UPDATE TO authenticated
  USING (public.has_verified_teacher_role())
  WITH CHECK (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- subjects: attendance-subject ownership
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "teachers insert subjects" ON public.subjects;
CREATE POLICY "teachers insert subjects" ON public.subjects
  FOR INSERT TO authenticated WITH CHECK (public.has_verified_teacher_role() AND auth.uid() = user_id);

DROP POLICY IF EXISTS "teachers update own subjects" ON public.subjects;
CREATE POLICY "teachers update own subjects" ON public.subjects
  FOR UPDATE TO authenticated
  USING (public.has_verified_teacher_role() AND auth.uid() = user_id)
  WITH CHECK (public.has_verified_teacher_role() AND auth.uid() = user_id);

DROP POLICY IF EXISTS "teachers delete own subjects" ON public.subjects;
CREATE POLICY "teachers delete own subjects" ON public.subjects
  FOR DELETE TO authenticated USING (public.has_verified_teacher_role() AND auth.uid() = user_id);

-- ---------------------------------------------------------------------
-- attendance_records: student attendance data
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "students read own attendance" ON public.attendance_records;
CREATE POLICY "students read own attendance" ON public.attendance_records
  FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_verified_teacher_role());

DROP POLICY IF EXISTS "teachers insert own-subject attendance" ON public.attendance_records;
CREATE POLICY "teachers insert own-subject attendance"
ON public.attendance_records FOR INSERT TO authenticated
WITH CHECK (
  public.has_verified_teacher_role()
  AND auth.uid() = marked_by
  AND EXISTS (SELECT 1 FROM public.subjects s WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid())
);

DROP POLICY IF EXISTS "teachers update own-subject attendance" ON public.attendance_records;
CREATE POLICY "teachers update own-subject attendance"
ON public.attendance_records FOR UPDATE TO authenticated
USING (
  public.has_verified_teacher_role()
  AND EXISTS (SELECT 1 FROM public.subjects s WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid())
)
WITH CHECK (
  public.has_verified_teacher_role()
  AND EXISTS (SELECT 1 FROM public.subjects s WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid())
);

DROP POLICY IF EXISTS "teachers delete own-subject attendance" ON public.attendance_records;
CREATE POLICY "teachers delete own-subject attendance"
ON public.attendance_records FOR DELETE TO authenticated
USING (
  public.has_verified_teacher_role()
  AND EXISTS (SELECT 1 FROM public.subjects s WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid())
);

-- ---------------------------------------------------------------------
-- user_roles: seeing who holds what role
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "Teachers can read all roles" ON public.user_roles;
CREATE POLICY "Teachers can read all roles"
ON public.user_roles FOR SELECT TO authenticated USING (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- game_audit_log: move-by-move dispute resolution log
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "teachers can review the game audit log" ON public.game_audit_log;
CREATE POLICY "teachers can review the game audit log"
ON public.game_audit_log FOR SELECT TO authenticated USING (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- subject_notes: shared notes moderation
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "owner or teacher can delete a note" ON public.subject_notes;
CREATE POLICY "owner or teacher can delete a note"
ON public.subject_notes FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- study_groups: moderation of scheduled study sessions
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "organizer or teacher can update" ON public.study_groups;
CREATE POLICY "organizer or teacher can update"
ON public.study_groups FOR UPDATE TO authenticated
USING (auth.uid() = created_by OR public.has_verified_teacher_role())
WITH CHECK (auth.uid() = created_by OR public.has_verified_teacher_role());

DROP POLICY IF EXISTS "organizer or teacher can delete" ON public.study_groups;
CREATE POLICY "organizer or teacher can delete"
ON public.study_groups FOR DELETE TO authenticated
USING (auth.uid() = created_by OR public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- room_chat_messages: in-game-room chat moderation (the live table —
-- game_room_messages is the orphaned duplicate documented elsewhere and
-- deliberately left untouched here too)
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "teachers soft-delete room chat messages" ON public.room_chat_messages;
CREATE POLICY "teachers soft-delete room chat messages"
ON public.room_chat_messages FOR UPDATE TO authenticated
USING (public.has_verified_teacher_role())
WITH CHECK (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- security_events: every student's login/password/MFA/role history
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "teachers see all security events" ON public.security_events;
CREATE POLICY "teachers see all security events"
ON public.security_events FOR SELECT TO authenticated USING (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- account_deletion_log
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "teachers can review account deletion log" ON public.account_deletion_log;
CREATE POLICY "teachers can review account deletion log"
ON public.account_deletion_log FOR SELECT TO authenticated USING (public.has_verified_teacher_role());

-- ---------------------------------------------------------------------
-- grant_role / revoke_role: the single most sensitive operation in the
-- app — an aal1 teacher session (or a hijacked session that never
-- completed MFA) should not be able to mint more teachers.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.grant_role(_target_user uuid, _role public.app_role)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_target_exists boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF NOT public.has_verified_teacher_role() THEN
    RAISE EXCEPTION 'Only an MFA-verified teacher session can grant roles. Complete your 2FA challenge and try again.';
  END IF;

  SELECT EXISTS (SELECT 1 FROM auth.users WHERE id = _target_user) INTO v_target_exists;
  IF NOT v_target_exists THEN RAISE EXCEPTION 'Target user not found'; END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (_target_user, _role)
  ON CONFLICT (user_id, role) DO NOTHING;

  INSERT INTO public.security_events (user_id, event_type, detail)
  VALUES (_target_user, 'role_granted', _role::text || ' granted by a teacher');
END;
$$;

CREATE OR REPLACE FUNCTION public.revoke_role(_target_user uuid, _role public.app_role)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF NOT public.has_verified_teacher_role() THEN
    RAISE EXCEPTION 'Only an MFA-verified teacher session can revoke roles. Complete your 2FA challenge and try again.';
  END IF;
  IF _target_user = auth.uid() AND _role = 'teacher' THEN
    RAISE EXCEPTION 'Cannot revoke your own teacher role — ask another teacher to do it';
  END IF;
  IF _role = 'student' THEN
    RAISE EXCEPTION 'The student role cannot be revoked — every account keeps it as a baseline';
  END IF;

  DELETE FROM public.user_roles WHERE user_id = _target_user AND role = _role;

  INSERT INTO public.security_events (user_id, event_type, detail)
  VALUES (_target_user, 'role_revoked', _role::text || ' revoked by a teacher');
END;
$$;
