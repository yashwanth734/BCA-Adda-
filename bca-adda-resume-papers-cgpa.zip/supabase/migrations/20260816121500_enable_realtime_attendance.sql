-- attendance and subjects tables were not added to realtime, so the
-- attendance page never updated live, only on refresh. adding them here.

ALTER TABLE public.attendance_records REPLICA IDENTITY FULL;
ALTER TABLE public.subjects REPLICA IDENTITY FULL;

ALTER PUBLICATION supabase_realtime ADD TABLE public.attendance_records;
ALTER PUBLICATION supabase_realtime ADD TABLE public.subjects;
