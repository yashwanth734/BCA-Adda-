-- Feature 2 & 3: global leaderboard + achievement badges.
-- Stats are kept up to date by AFTER UPDATE triggers on every multiplayer
-- game table whose schema this app fully controls (host_id/guest_id/
-- status/winner_id shape): connect_four, tic_tac_toe, rps, battleship,
-- othello, dots_and_boxes. War and Trade City (bg_rooms) aren't included —
-- their schemas predate this session and weren't written by these
-- migrations, so redefining triggers on them without seeing their exact
-- column layout would be a guess rather than a known-safe change.

CREATE TABLE public.game_stats (
  user_id uuid PRIMARY KEY,
  wins int NOT NULL DEFAULT 0,
  losses int NOT NULL DEFAULT 0,
  draws int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.game_stats TO authenticated;
GRANT ALL ON public.game_stats TO service_role;
ALTER TABLE public.game_stats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leaderboard viewable by authenticated"
ON public.game_stats FOR SELECT TO authenticated USING (true);
-- no INSERT/UPDATE policy for authenticated — only the trigger (via the
-- SECURITY DEFINER function below) is allowed to change these numbers.

CREATE TABLE public.achievements (
  id text PRIMARY KEY,
  title text NOT NULL,
  description text NOT NULL,
  emoji text NOT NULL,
  win_threshold int NOT NULL
);

GRANT SELECT ON public.achievements TO authenticated;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "achievements catalog viewable by authenticated"
ON public.achievements FOR SELECT TO authenticated USING (true);

INSERT INTO public.achievements (id, title, description, emoji, win_threshold) VALUES
  ('first_win', 'First Win', 'Win your first multiplayer game', '🏅', 1),
  ('getting_good', 'Getting Good', 'Win 5 multiplayer games', '⭐', 5),
  ('arcade_regular', 'Arcade Regular', 'Win 10 multiplayer games', '🔥', 10),
  ('champion', 'Champion', 'Win 25 multiplayer games', '👑', 25);

CREATE TABLE public.user_achievements (
  user_id uuid NOT NULL,
  achievement_id text NOT NULL REFERENCES public.achievements(id),
  earned_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, achievement_id)
);

GRANT SELECT ON public.user_achievements TO authenticated;
GRANT ALL ON public.user_achievements TO service_role;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "earned badges viewable by authenticated"
ON public.user_achievements FOR SELECT TO authenticated USING (true);
-- again, only the trigger path writes here.

-- Records one game result for one player, updates their stats, and
-- unlocks any newly-qualified achievement. Not meant to be called by
-- clients directly.
CREATE OR REPLACE FUNCTION public.bump_game_stats(_user_id uuid, _result text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_wins int;
BEGIN
  INSERT INTO public.game_stats (user_id, wins, losses, draws)
    VALUES (
      _user_id,
      CASE WHEN _result = 'win' THEN 1 ELSE 0 END,
      CASE WHEN _result = 'loss' THEN 1 ELSE 0 END,
      CASE WHEN _result = 'draw' THEN 1 ELSE 0 END
    )
    ON CONFLICT (user_id) DO UPDATE SET
      wins = public.game_stats.wins + (CASE WHEN _result = 'win' THEN 1 ELSE 0 END),
      losses = public.game_stats.losses + (CASE WHEN _result = 'loss' THEN 1 ELSE 0 END),
      draws = public.game_stats.draws + (CASE WHEN _result = 'draw' THEN 1 ELSE 0 END),
      updated_at = now()
    RETURNING wins INTO v_wins;

  IF _result = 'win' THEN
    INSERT INTO public.user_achievements (user_id, achievement_id)
      SELECT _user_id, a.id FROM public.achievements a
      WHERE a.win_threshold <= v_wins
      ON CONFLICT (user_id, achievement_id) DO NOTHING;
  END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.bump_game_stats(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.bump_game_stats(uuid, text) TO service_role;

-- Shared trigger for the 6 known-shape game tables. Fires once, the
-- instant a game's status flips to 'finished', and credits both players.
CREATE OR REPLACE FUNCTION public.record_game_result_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'finished' AND OLD.status IS DISTINCT FROM 'finished' AND NEW.guest_id IS NOT NULL THEN
    IF NEW.winner_id IS NULL THEN
      PERFORM public.bump_game_stats(NEW.host_id, 'draw');
      PERFORM public.bump_game_stats(NEW.guest_id, 'draw');
    ELSIF NEW.winner_id = NEW.host_id THEN
      PERFORM public.bump_game_stats(NEW.host_id, 'win');
      PERFORM public.bump_game_stats(NEW.guest_id, 'loss');
    ELSE
      PERFORM public.bump_game_stats(NEW.guest_id, 'win');
      PERFORM public.bump_game_stats(NEW.host_id, 'loss');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER connect_four_games_record_result
AFTER UPDATE ON public.connect_four_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();

CREATE TRIGGER tic_tac_toe_games_record_result
AFTER UPDATE ON public.tic_tac_toe_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();

CREATE TRIGGER rps_games_record_result
AFTER UPDATE ON public.rps_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();

CREATE TRIGGER battleship_games_record_result
AFTER UPDATE ON public.battleship_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();

CREATE TRIGGER othello_games_record_result
AFTER UPDATE ON public.othello_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();

CREATE TRIGGER dots_boxes_games_record_result
AFTER UPDATE ON public.dots_boxes_games
FOR EACH ROW EXECUTE FUNCTION public.record_game_result_trg();
