-- Security hardening, round 1:
--   1. Rate limiting on chat messages (stop message-flood spam)
--   2. Rate limiting on game room creation (stop room-spam across every
--      game table, without touching any existing create_game function body)
--   3. Scheduled cleanup of rooms nobody ever joined

-- ---------------------------------------------------------------------
-- 1. Shared rate-limit bookkeeping
-- ---------------------------------------------------------------------

CREATE TABLE public.rate_limits (
  user_id uuid NOT NULL,
  action text NOT NULL,
  last_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, action)
);

GRANT ALL ON public.rate_limits TO service_role;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
-- no policies for authenticated — only reachable through the SECURITY
-- DEFINER function below, same pattern as the *_games_private tables.

-- Call this at the top of any mutating path to throttle it per user.
-- Raises if the same user did the same `_action` more recently than
-- `_min_interval` ago; otherwise records "now" and lets the caller proceed.
CREATE OR REPLACE FUNCTION public.enforce_rate_limit(_action text, _min_interval interval)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_last timestamptz;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;

  SELECT last_at INTO v_last FROM public.rate_limits
    WHERE user_id = auth.uid() AND action = _action FOR UPDATE;

  IF v_last IS NOT NULL AND now() - v_last < _min_interval THEN
    RAISE EXCEPTION 'You are doing that too fast — slow down a little.';
  END IF;

  INSERT INTO public.rate_limits (user_id, action, last_at)
    VALUES (auth.uid(), _action, now())
    ON CONFLICT (user_id, action) DO UPDATE SET last_at = now();
END;
$$;
REVOKE EXECUTE ON FUNCTION public.enforce_rate_limit(text, interval) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.enforce_rate_limit(text, interval) TO authenticated;

-- ---------------------------------------------------------------------
-- 2. Chat message flood protection — max ~1.4 messages/sec per user
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.messages_rate_limit_trg()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM public.enforce_rate_limit('chat_message', interval '700 milliseconds');
  RETURN NEW;
END;
$$;

CREATE TRIGGER messages_rate_limit
BEFORE INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.messages_rate_limit_trg();

-- ---------------------------------------------------------------------
-- 3. Game-room creation flood protection — shared across every game
--    table, so spamming "new room" on any game counts against the same
--    3-second cooldown. Attached as a trigger so none of the existing
--    *_create_game function bodies need to change.
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.room_creation_rate_limit_trg()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM public.enforce_rate_limit('create_game_room', interval '3 seconds');
  RETURN NEW;
END;
$$;

CREATE TRIGGER war_games_rate_limit
BEFORE INSERT ON public.war_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER bg_rooms_rate_limit
BEFORE INSERT ON public.bg_rooms
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER connect_four_games_rate_limit
BEFORE INSERT ON public.connect_four_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER tic_tac_toe_games_rate_limit
BEFORE INSERT ON public.tic_tac_toe_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER rps_games_rate_limit
BEFORE INSERT ON public.rps_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER battleship_games_rate_limit
BEFORE INSERT ON public.battleship_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER othello_games_rate_limit
BEFORE INSERT ON public.othello_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

CREATE TRIGGER dots_boxes_games_rate_limit
BEFORE INSERT ON public.dots_boxes_games
FOR EACH ROW EXECUTE FUNCTION public.room_creation_rate_limit_trg();

-- ---------------------------------------------------------------------
-- 4. Cleanup rooms nobody ever joined (status still "waiting"/"lobby"
--    after 45 minutes). Only touches never-joined rooms — an in-progress
--    or finished game is never deleted by this.
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.cleanup_stale_game_rooms()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.war_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.bg_rooms WHERE status = 'lobby' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.connect_four_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.tic_tac_toe_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.rps_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.battleship_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.othello_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.dots_boxes_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
END;
$$;
REVOKE EXECUTE ON FUNCTION public.cleanup_stale_game_rooms() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_stale_game_rooms() TO service_role;

-- Schedule it to run every 15 minutes via pg_cron, if the extension is
-- available on this project. Wrapped so the rest of this migration still
-- applies even if pg_cron isn't enabled or the migration role lacks
-- permission to schedule jobs — enable it manually in Supabase's
-- Database → Extensions page and re-run just the block below if needed.
DO $$
BEGIN
  CREATE EXTENSION IF NOT EXISTS pg_cron;
  PERFORM cron.schedule(
    'cleanup-stale-game-rooms',
    '*/15 * * * *',
    $cron$SELECT public.cleanup_stale_game_rooms();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (% ) — enable pg_cron in Supabase and rerun manually if you want automatic cleanup.', SQLERRM;
END;
$$;
