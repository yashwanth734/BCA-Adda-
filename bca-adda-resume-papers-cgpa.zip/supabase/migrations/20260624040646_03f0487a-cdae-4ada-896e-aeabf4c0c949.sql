
CREATE TABLE public.war_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  host_deck integer[] NOT NULL DEFAULT '{}',
  guest_deck integer[] NOT NULL DEFAULT '{}',
  host_card integer,
  guest_card integer,
  pot integer[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'waiting',
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.war_games TO authenticated;
GRANT ALL ON public.war_games TO service_role;

ALTER TABLE public.war_games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Players or open games viewable"
ON public.war_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid() OR guest_id IS NULL);

CREATE POLICY "Anyone authed can create as host"
ON public.war_games FOR INSERT TO authenticated
WITH CHECK (host_id = auth.uid());

CREATE POLICY "Players can update their game"
ON public.war_games FOR UPDATE TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid() OR (guest_id IS NULL AND status = 'waiting'))
WITH CHECK (host_id = auth.uid() OR guest_id = auth.uid());

CREATE POLICY "Host can delete"
ON public.war_games FOR DELETE TO authenticated
USING (host_id = auth.uid());

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER war_games_touch
BEFORE UPDATE ON public.war_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.war_games;
