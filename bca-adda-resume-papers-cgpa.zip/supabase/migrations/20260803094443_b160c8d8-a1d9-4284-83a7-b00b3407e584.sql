CREATE TABLE public.bg_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL DEFAULT 'Trade City',
  host_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  max_players integer NOT NULL DEFAULT 4,
  is_private boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'lobby',
  state jsonb NOT NULL DEFAULT '{}'::jsonb,
  version integer NOT NULL DEFAULT 0,
  winner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT bg_rooms_status_chk CHECK (status IN ('lobby','playing','finished')),
  CONSTRAINT bg_rooms_max_chk CHECK (max_players IN (2,3,4,6,8))
);

CREATE TABLE public.bg_room_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.bg_rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  seat integer NOT NULL,
  color text NOT NULL DEFAULT 'cyan',
  display_name text,
  is_ready boolean NOT NULL DEFAULT false,
  is_bot boolean NOT NULL DEFAULT false,
  last_seen timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_id, user_id),
  UNIQUE (room_id, seat)
);

GRANT SELECT ON public.bg_rooms TO authenticated;
GRANT ALL ON public.bg_rooms TO service_role;
GRANT SELECT ON public.bg_room_members TO authenticated;
GRANT ALL ON public.bg_room_members TO service_role;

ALTER TABLE public.bg_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bg_room_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.bg_is_member(_room_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.bg_room_members m WHERE m.room_id = _room_id AND m.user_id = _user_id)
$$;

CREATE POLICY "Players can view open public rooms or their own rooms"
ON public.bg_rooms FOR SELECT TO authenticated
USING ((is_private = false AND status = 'lobby') OR host_id = auth.uid() OR public.bg_is_member(id, auth.uid()));

CREATE POLICY "Players can view members of rooms they can see"
ON public.bg_room_members FOR SELECT TO authenticated
USING (public.bg_is_member(room_id, auth.uid()) OR EXISTS (
  SELECT 1 FROM public.bg_rooms r WHERE r.id = room_id AND (r.is_private = false AND r.status = 'lobby')
));

CREATE INDEX bg_rooms_status_idx ON public.bg_rooms (status, is_private, created_at DESC);
CREATE INDEX bg_room_members_room_idx ON public.bg_room_members (room_id);
CREATE INDEX bg_room_members_user_idx ON public.bg_room_members (user_id);

CREATE TRIGGER bg_rooms_touch BEFORE UPDATE ON public.bg_rooms
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.bg_rooms;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bg_room_members;
ALTER TABLE public.bg_rooms REPLICA IDENTITY FULL;
ALTER TABLE public.bg_room_members REPLICA IDENTITY FULL;