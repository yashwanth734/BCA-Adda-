-- Previously any user with the 'teacher' role could update/delete
-- *any* attendance record, regardless of who owns the underlying
-- subject. Scope these to teachers who own the subject the record
-- belongs to, same as the existing subjects policies already do.

DROP POLICY IF EXISTS "teachers update attendance" ON public.attendance_records;
DROP POLICY IF EXISTS "teachers delete attendance" ON public.attendance_records;

CREATE POLICY "teachers update own-subject attendance"
ON public.attendance_records FOR UPDATE TO authenticated
USING (
  public.has_role(auth.uid(), 'teacher')
  AND EXISTS (
    SELECT 1 FROM public.subjects s
    WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid()
  )
)
WITH CHECK (
  public.has_role(auth.uid(), 'teacher')
  AND EXISTS (
    SELECT 1 FROM public.subjects s
    WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid()
  )
);

CREATE POLICY "teachers delete own-subject attendance"
ON public.attendance_records FOR DELETE TO authenticated
USING (
  public.has_role(auth.uid(), 'teacher')
  AND EXISTS (
    SELECT 1 FROM public.subjects s
    WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid()
  )
);

-- "teachers insert attendance" already required marked_by = auth.uid(),
-- but not that the subject belongs to that teacher. Tighten it the same way.
DROP POLICY IF EXISTS "teachers insert attendance" ON public.attendance_records;
CREATE POLICY "teachers insert own-subject attendance"
ON public.attendance_records FOR INSERT TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'teacher')
  AND auth.uid() = marked_by
  AND EXISTS (
    SELECT 1 FROM public.subjects s
    WHERE s.id = attendance_records.subject_id AND s.user_id = auth.uid()
  )
);
