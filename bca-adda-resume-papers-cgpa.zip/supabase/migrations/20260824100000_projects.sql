-- Feature: student projects/portfolio, public and browsable like
-- subject_notes and study_groups (open school-wide model). Uses the
-- project-images storage bucket from 20260824090000_storage_buckets.sql.

CREATE TABLE public.projects (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
  description text CHECK (description IS NULL OR char_length(description) <= 2000),
  tech_stack text[] NOT NULL DEFAULT '{}',
  github_url text CHECK (github_url IS NULL OR github_url ~ '^https://[^[:space:]]+$'),
  demo_url text CHECK (demo_url IS NULL OR demo_url ~ '^https://[^[:space:]]+$'),
  image_url text CHECK (image_url IS NULL OR image_url ~ '^https://[^[:space:]]+$'),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX projects_user_idx ON public.projects (user_id, created_at DESC);
CREATE INDEX projects_created_idx ON public.projects (created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "projects viewable by authenticated"
ON public.projects FOR SELECT TO authenticated USING (true);

CREATE POLICY "users add their own projects"
ON public.projects FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users update their own projects"
ON public.projects FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- teacher moderation requires an MFA-verified session, consistent with
-- every other teacher-moderation policy added in
-- 20260823090000_require_mfa_for_teacher_actions.sql
CREATE POLICY "owner or verified teacher can delete a project"
ON public.projects FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.has_verified_teacher_role());

CREATE OR REPLACE FUNCTION public.projects_rate_limit_trg()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM public.enforce_rate_limit('create_project', interval '3 seconds');
  RETURN NEW;
END;
$$;

CREATE TRIGGER projects_rate_limit
BEFORE INSERT ON public.projects
FOR EACH ROW EXECUTE FUNCTION public.projects_rate_limit_trg();
