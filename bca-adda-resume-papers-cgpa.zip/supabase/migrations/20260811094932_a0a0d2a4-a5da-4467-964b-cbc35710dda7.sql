-- 1. Signup can no longer self-assign teacher
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'student')
  ON CONFLICT (user_id, role) DO NOTHING;
  RETURN NEW;
END; $function$;

-- 2. Subjects: scope reads
DROP POLICY IF EXISTS "subjects readable by authenticated" ON public.subjects;
CREATE POLICY "subjects readable by owner, teachers or enrolled students"
ON public.subjects FOR SELECT TO authenticated
USING (
  auth.uid() = user_id
  OR public.has_role(auth.uid(), 'teacher')
  OR EXISTS (
    SELECT 1 FROM public.attendance_records a
    WHERE a.subject_id = subjects.id AND a.user_id = auth.uid()
  )
);

-- 3. user_roles: only own roles
DROP POLICY IF EXISTS "Users can read roles" ON public.user_roles;
CREATE POLICY "Users can read their own roles"
ON public.user_roles FOR SELECT TO authenticated
USING (auth.uid() = user_id);