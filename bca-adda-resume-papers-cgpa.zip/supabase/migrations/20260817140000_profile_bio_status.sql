-- Feature: user profiles (bio + status), first of the requested feature batch.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS bio text,
  ADD COLUMN IF NOT EXISTS status text;

ALTER TABLE public.profiles ADD CONSTRAINT profiles_bio_len CHECK (bio IS NULL OR char_length(bio) <= 280);
ALTER TABLE public.profiles ADD CONSTRAINT profiles_status_len CHECK (status IS NULL OR char_length(status) <= 60);
