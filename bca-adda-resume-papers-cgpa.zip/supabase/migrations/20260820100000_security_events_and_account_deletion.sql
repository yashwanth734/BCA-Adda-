-- Security audit log for auth events (logins, password changes, MFA, etc.)
-- and account self-deletion. Required by the security doc (§27, §36).

CREATE TABLE public.security_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  event_type text NOT NULL,  -- login_success, login_failure, password_change, mfa_enabled, mfa_disabled, account_deleted, logout
  ip_text text,              -- stored as text so no geo-library is needed
  user_agent text,
  detail text,               -- safe context (never passwords, never tokens)
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX security_events_user_idx ON public.security_events (user_id, created_at DESC);
CREATE INDEX security_events_type_idx ON public.security_events (event_type, created_at DESC);

GRANT SELECT, INSERT ON public.security_events TO authenticated;
GRANT ALL ON public.security_events TO service_role;
ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users see their own security events"
ON public.security_events FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "users log their own events"
ON public.security_events FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- teachers/admins can see all events for moderation
CREATE POLICY "teachers see all security events"
ON public.security_events FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'teacher'));

-- clean up events older than 90 days
CREATE OR REPLACE FUNCTION public.cleanup_old_security_events()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.security_events WHERE created_at < now() - interval '90 days';
END;
$$;
REVOKE EXECUTE ON FUNCTION public.cleanup_old_security_events() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_old_security_events() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'cleanup-old-security-events',
    '0 6 1 * *',
    $cron$SELECT public.cleanup_old_security_events();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.cleanup_old_security_events() manually.', SQLERRM;
END;
$$;

-- Account self-deletion. Deletes the caller's auth.users row, which
-- cascades to all application data (all foreign keys use ON DELETE CASCADE).
-- Requires re-authentication (the caller must supply their current password
-- to confirm) — that check is done on the client via supabase.auth.signInWithPassword
-- before calling this RPC.
CREATE OR REPLACE FUNCTION public.delete_own_account()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;

  INSERT INTO public.security_events (user_id, event_type, detail)
  VALUES (auth.uid(), 'account_deleted', 'User self-deleted their account');

  DELETE FROM auth.users WHERE id = auth.uid();
END;
$$;
REVOKE EXECUTE ON FUNCTION public.delete_own_account() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_own_account() TO authenticated;
