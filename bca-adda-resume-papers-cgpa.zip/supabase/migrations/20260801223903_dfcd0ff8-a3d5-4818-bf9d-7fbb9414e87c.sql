-- Remove duplicates (keep newest per student/subject/date)
DELETE FROM public.attendance_records a
USING public.attendance_records b
WHERE a.subject_id = b.subject_id
  AND a.user_id = b.user_id
  AND a.date = b.date
  AND (a.created_at < b.created_at OR (a.created_at = b.created_at AND a.id < b.id));

ALTER TABLE public.attendance_records
  DROP CONSTRAINT IF EXISTS attendance_records_subject_id_date_key;

ALTER TABLE public.attendance_records
  ADD CONSTRAINT attendance_records_user_subject_date_key
  UNIQUE (user_id, subject_id, date);