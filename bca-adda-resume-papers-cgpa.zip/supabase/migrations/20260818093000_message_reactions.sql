-- Feature 4: message reactions in chat.
CREATE TABLE public.message_reactions (
  message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  emoji text NOT NULL CHECK (char_length(emoji) <= 8),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id, emoji)
);

GRANT SELECT, INSERT, DELETE ON public.message_reactions TO authenticated;
GRANT ALL ON public.message_reactions TO service_role;
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;

-- messages themselves are viewable by any authenticated user (open
-- school-wide rooms), so reactions on them follow the same visibility.
CREATE POLICY "reactions viewable by authenticated"
ON public.message_reactions FOR SELECT TO authenticated USING (true);

CREATE POLICY "users add their own reactions"
ON public.message_reactions FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users remove their own reactions"
ON public.message_reactions FOR DELETE TO authenticated
USING (auth.uid() = user_id);

ALTER TABLE public.message_reactions REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_reactions;
