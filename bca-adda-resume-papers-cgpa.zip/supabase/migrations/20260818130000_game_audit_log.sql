-- Security item #4: move/state audit trail for dispute resolution
-- ("did they cheat in Othello"). A single generic AFTER UPDATE trigger
-- attached to every multiplayer game table — logs a snapshot of the row
-- after each change, tagged with who was authenticated at the time.
-- No existing move-function needed to change for this.
--
-- Deliberately excludes the *_games_private tables (war/rps/battleship
-- ship & card data) — only the public, already-visible-to-both-players
-- row gets logged, so this can never leak hidden info.

CREATE TABLE public.game_audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  game_type text NOT NULL, -- table name, e.g. 'othello_games'
  game_id uuid NOT NULL,
  actor_id uuid, -- auth.uid() at the moment of the change, if available
  snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX game_audit_log_game_idx ON public.game_audit_log (game_type, game_id, created_at);

GRANT ALL ON public.game_audit_log TO service_role;
ALTER TABLE public.game_audit_log ENABLE ROW LEVEL SECURITY;
-- readable by teachers only, for dispute resolution — not exposed to players
CREATE POLICY "teachers can review the game audit log"
ON public.game_audit_log FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'teacher'));

CREATE OR REPLACE FUNCTION public.game_audit_log_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.game_audit_log (game_type, game_id, actor_id, snapshot)
  VALUES (TG_TABLE_NAME, NEW.id, auth.uid(), to_jsonb(NEW));
  RETURN NEW;
END;
$$;

CREATE TRIGGER connect_four_games_audit AFTER UPDATE ON public.connect_four_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();
CREATE TRIGGER tic_tac_toe_games_audit AFTER UPDATE ON public.tic_tac_toe_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();
CREATE TRIGGER rps_games_audit AFTER UPDATE ON public.rps_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();
CREATE TRIGGER battleship_games_audit AFTER UPDATE ON public.battleship_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();
CREATE TRIGGER othello_games_audit AFTER UPDATE ON public.othello_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();
CREATE TRIGGER dots_boxes_games_audit AFTER UPDATE ON public.dots_boxes_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();
CREATE TRIGGER checkers_games_audit AFTER UPDATE ON public.checkers_games FOR EACH ROW EXECUTE FUNCTION public.game_audit_log_trg();

-- keep the audit log itself from growing forever — trim entries older
-- than 60 days, riding the same cron schedule as the room cleanup.
CREATE OR REPLACE FUNCTION public.cleanup_old_audit_log()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.game_audit_log WHERE created_at < now() - interval '60 days';
END;
$$;
REVOKE EXECUTE ON FUNCTION public.cleanup_old_audit_log() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_old_audit_log() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'cleanup-old-game-audit-log',
    '0 3 * * *',
    $cron$SELECT public.cleanup_old_audit_log();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.cleanup_old_audit_log() manually if pg_cron is unavailable.', SQLERRM;
END;
$$;
