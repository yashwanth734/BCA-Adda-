-- Remove blanket PUBLIC execute on all public-schema functions
REVOKE EXECUTE ON FUNCTION public.bg_is_member(uuid, uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.war_create_game() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.war_join_game(text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.war_leave_game(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.war_my_state(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.war_play_card(uuid) FROM PUBLIC, anon;

-- Trigger-only functions: never callable through the API
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user_role() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

-- Grant back only what signed-in app users legitimately need
GRANT EXECUTE ON FUNCTION public.bg_is_member(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_leave_game(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_my_state(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_play_card(uuid) TO authenticated;

-- service_role keeps full access for server-side code
GRANT EXECUTE ON FUNCTION public.bg_is_member(uuid, uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO service_role;
GRANT EXECUTE ON FUNCTION public.war_create_game() TO service_role;
GRANT EXECUTE ON FUNCTION public.war_join_game(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.war_leave_game(uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.war_my_state(uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.war_play_card(uuid) TO service_role;