-- Remediation of HIGH-01 (stored XSS via javascript:/data: URI).
--
-- The client already sanitizes profiles.avatar_url (added when this was
-- first built) but subject_notes.url had no scheme restriction at all —
-- and neither field was enforced at the database level, so a direct API
-- call bypassing the app's UI could still write an unsafe scheme to
-- either column. Both are fixed here as defense-in-depth: even if every
-- client-side check were removed or bypassed, the database itself now
-- rejects anything but a plain https:// URL (or NULL/empty).
--
-- Threat model note: <img src="javascript:...">  does not execute in
-- modern browsers (this was an old IE-era vector, not applicable here),
-- so avatar_url was not actually exploitable for code execution the way
-- subject_notes.url was via <a href>. It's still hardened for
-- consistency and because avatar_url could end up rendered as a link
-- somewhere in the future.

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_avatar_url_https
  CHECK (avatar_url IS NULL OR avatar_url ~ '^https://[^[:space:]]+$')
  NOT VALID;
-- NOT VALID: doesn't retroactively fail on any existing non-https rows
-- from before this constraint existed, only enforces going forward.
-- Run VALIDATE CONSTRAINT profiles_avatar_url_https once you've
-- confirmed/cleaned any historical values if you want full retroactive
-- enforcement.

ALTER TABLE public.subject_notes
  ADD CONSTRAINT subject_notes_url_https
  CHECK (url IS NULL OR url ~ '^https://[^[:space:]]+$')
  NOT VALID;
