-- Dots and Boxes: standard 4x4 box grid (5x5 dots). Draw one edge per
-- turn; completing a box scores it and grants an extra turn — the one
-- rule that makes this game more than "take turns filling a grid".
-- No hidden info, one public table.
--
-- Edge layout (40 edges total, stored 1-indexed in `edges`):
--   horizontal edges 0..19: index = row*4 + col, row 0..4, col 0..3
--   vertical edges   20..39: index = 20 + row*5 + col, row 0..3, col 0..4
-- Box layout (16 boxes, stored 1-indexed in `boxes`):
--   box index = row*4 + col, row 0..3, col 0..3
--   box(r,c) edges: top = h(r,c), bottom = h(r+1,c), left = v(r,c), right = v(r,c+1)

CREATE TABLE public.dots_boxes_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  edges smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[40]), -- 0 empty, 1 host, 2 guest
  boxes smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[16]), -- 0 unclaimed, 1 host, 2 guest
  host_score smallint NOT NULL DEFAULT 0,
  guest_score smallint NOT NULL DEFAULT 0,
  turn smallint NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.dots_boxes_games TO authenticated;
GRANT ALL ON public.dots_boxes_games TO service_role;

ALTER TABLE public.dots_boxes_games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "players view their dots and boxes game"
ON public.dots_boxes_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER dots_boxes_games_touch
BEFORE UPDATE ON public.dots_boxes_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.dots_boxes_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.dots_boxes_games;

CREATE OR REPLACE FUNCTION public.dots_boxes_create_game()
RETURNS public.dots_boxes_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.dots_boxes_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  INSERT INTO public.dots_boxes_games (code, host_id, status, last_message)
  VALUES (v_code, auth.uid(), 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.dots_boxes_join_game(_code text)
RETURNS public.dots_boxes_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.dots_boxes_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.dots_boxes_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.dots_boxes_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Host draws first.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.dots_boxes_draw(_game_id uuid, _edge smallint)
RETURNS public.dots_boxes_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.dots_boxes_games;
  v_is_host boolean;
  v_me smallint;
  v_edges smallint[];
  v_boxes smallint[];
  v_row int; v_col int;
  v_candidates int[];
  v_box int; v_top int; v_bottom int; v_left int; v_right int;
  v_completed boolean := false;
  v_status text := 'playing';
  v_winner uuid;
  v_msg text;
  v_claimed_count int;
  i int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _edge < 0 OR _edge > 39 THEN RAISE EXCEPTION 'Invalid edge'; END IF;

  SELECT * INTO v_game FROM public.dots_boxes_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true; v_me := 1;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false; v_me := 2;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF v_game.turn <> v_me THEN RAISE EXCEPTION 'Not your turn'; END IF;

  v_edges := v_game.edges;
  v_boxes := v_game.boxes;
  IF v_edges[_edge+1] <> 0 THEN RAISE EXCEPTION 'Edge already drawn'; END IF;
  v_edges[_edge+1] := v_me;

  -- which box(es) does this edge border?
  v_candidates := ARRAY[]::int[];
  IF _edge < 20 THEN
    v_row := _edge / 4; v_col := _edge % 4; -- horizontal edge
    IF v_row <= 3 THEN v_candidates := v_candidates || (v_row*4+v_col); END IF;       -- box below (top edge)
    IF v_row >= 1 THEN v_candidates := v_candidates || ((v_row-1)*4+v_col); END IF;   -- box above (bottom edge)
  ELSE
    v_row := (_edge-20) / 5; v_col := (_edge-20) % 5; -- vertical edge
    IF v_col <= 3 THEN v_candidates := v_candidates || (v_row*4+v_col); END IF;       -- box to the right (left edge)
    IF v_col >= 1 THEN v_candidates := v_candidates || (v_row*4+(v_col-1)); END IF;   -- box to the left (right edge)
  END IF;

  FOREACH v_box IN ARRAY v_candidates LOOP
    IF v_boxes[v_box+1] <> 0 THEN CONTINUE; END IF;
    v_row := v_box / 4; v_col := v_box % 4;
    v_top := v_row*4+v_col;
    v_bottom := (v_row+1)*4+v_col;
    v_left := 20 + v_row*5+v_col;
    v_right := 20 + v_row*5+(v_col+1);
    IF v_edges[v_top+1] <> 0 AND v_edges[v_bottom+1] <> 0 AND v_edges[v_left+1] <> 0 AND v_edges[v_right+1] <> 0 THEN
      v_boxes[v_box+1] := v_me;
      v_completed := true;
    END IF;
  END LOOP;

  v_claimed_count := 0;
  FOR i IN 1..16 LOOP
    IF v_boxes[i] <> 0 THEN v_claimed_count := v_claimed_count + 1; END IF;
  END LOOP;

  -- recompute scores directly from the boxes array, then apply the update
  DECLARE
    v_host_score smallint := 0;
    v_guest_score smallint := 0;
  BEGIN
    FOR i IN 1..16 LOOP
      IF v_boxes[i] = 1 THEN v_host_score := v_host_score + 1;
      ELSIF v_boxes[i] = 2 THEN v_guest_score := v_guest_score + 1; END IF;
    END LOOP;

    IF v_claimed_count = 16 THEN
      v_status := 'finished';
      IF v_host_score > v_guest_score THEN
        v_winner := v_game.host_id;
        v_msg := 'Host wins ' || v_host_score || '-' || v_guest_score || '!';
      ELSIF v_guest_score > v_host_score THEN
        v_winner := v_game.guest_id;
        v_msg := 'Guest wins ' || v_guest_score || '-' || v_host_score || '!';
      ELSE
        v_msg := 'All boxes claimed — it''s a tie ' || v_host_score || '-' || v_guest_score || '!';
      END IF;
    ELSIF v_completed THEN
      v_msg := (CASE WHEN v_is_host THEN 'Host' ELSE 'Guest' END) || ' completes a box and goes again!';
    ELSE
      v_msg := (CASE WHEN v_is_host THEN 'Guest' ELSE 'Host' END) || '''s turn.';
    END IF;

    UPDATE public.dots_boxes_games
      SET edges = v_edges,
          boxes = v_boxes,
          host_score = v_host_score,
          guest_score = v_guest_score,
          turn = CASE WHEN v_status = 'playing' AND NOT v_completed THEN (CASE WHEN v_me = 1 THEN 2 ELSE 1 END) ELSE turn END,
          status = v_status,
          winner_id = v_winner,
          last_message = v_msg,
          updated_at = now()
      WHERE id = _game_id
      RETURNING * INTO v_game;
  END;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.dots_boxes_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.dots_boxes_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.dots_boxes_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.dots_boxes_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dots_boxes_draw(uuid, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.dots_boxes_leave_game(uuid) TO authenticated;
