-- Feature: resume builder. Pulls existing profile (name, semester) and
-- projects data automatically, and stores the few resume-specific fields
-- that don't belong anywhere else in the schema (phone, education
-- summary, skills, work/internship experience) so a student doesn't
-- have to retype their whole resume every time they visit this page.
--
-- Private to the owner only — unlike notes/projects/papers, a draft
-- resume-in-progress isn't something meant to be shared with other
-- students, so this follows the assignments/attendance ownership model
-- instead of the "shared with everyone" model.

CREATE TABLE public.resume_details (
  user_id uuid NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  phone text CHECK (phone IS NULL OR char_length(phone) <= 20),
  education text CHECK (education IS NULL OR char_length(education) <= 500),
  skills text[] NOT NULL DEFAULT '{}',
  experience jsonb NOT NULL DEFAULT '[]', -- array of {title, company, duration, description}
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.resume_details TO authenticated;
GRANT ALL ON public.resume_details TO service_role;
ALTER TABLE public.resume_details ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own resume details select" ON public.resume_details FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own resume details insert" ON public.resume_details FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own resume details update" ON public.resume_details FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER resume_details_touch
BEFORE UPDATE ON public.resume_details
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
