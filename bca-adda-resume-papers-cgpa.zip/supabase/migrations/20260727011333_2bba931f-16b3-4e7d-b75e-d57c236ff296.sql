ALTER TABLE public.attendance_records ADD COLUMN IF NOT EXISTS marked_by uuid;

DROP POLICY IF EXISTS "own subjects select" ON public.subjects;
DROP POLICY IF EXISTS "own subjects insert" ON public.subjects;
DROP POLICY IF EXISTS "own subjects update" ON public.subjects;
DROP POLICY IF EXISTS "own subjects delete" ON public.subjects;

CREATE POLICY "subjects readable by authenticated" ON public.subjects
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "teachers insert subjects" ON public.subjects
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'teacher') AND auth.uid() = user_id);
CREATE POLICY "teachers update own subjects" ON public.subjects
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'teacher') AND auth.uid() = user_id)
  WITH CHECK (public.has_role(auth.uid(), 'teacher') AND auth.uid() = user_id);
CREATE POLICY "teachers delete own subjects" ON public.subjects
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'teacher') AND auth.uid() = user_id);

DROP POLICY IF EXISTS "own att select" ON public.attendance_records;
DROP POLICY IF EXISTS "own att insert" ON public.attendance_records;
DROP POLICY IF EXISTS "own att update" ON public.attendance_records;
DROP POLICY IF EXISTS "own att delete" ON public.attendance_records;

CREATE POLICY "students read own attendance" ON public.attendance_records
  FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'teacher'));
CREATE POLICY "teachers insert attendance" ON public.attendance_records
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'teacher') AND auth.uid() = marked_by);
CREATE POLICY "teachers update attendance" ON public.attendance_records
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'teacher'))
  WITH CHECK (public.has_role(auth.uid(), 'teacher'));
CREATE POLICY "teachers delete attendance" ON public.attendance_records
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'teacher'));

CREATE INDEX IF NOT EXISTS attendance_records_user_date_idx ON public.attendance_records (user_id, date);
CREATE INDEX IF NOT EXISTS attendance_records_subject_idx ON public.attendance_records (subject_id);