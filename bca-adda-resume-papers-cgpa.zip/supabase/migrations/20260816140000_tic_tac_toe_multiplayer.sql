-- Tic Tac Toe: real-time head-to-head, same room-code pattern as
-- connect_four_games. No hidden info, so one public table is enough.

CREATE TABLE public.tic_tac_toe_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  -- 9 cells, row-major 3x3. 0 = empty, 1 = host (X), 2 = guest (O).
  board smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[9]),
  turn smallint NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.tic_tac_toe_games TO authenticated;
GRANT ALL ON public.tic_tac_toe_games TO service_role;

ALTER TABLE public.tic_tac_toe_games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "players view their tic tac toe game"
ON public.tic_tac_toe_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER tic_tac_toe_games_touch
BEFORE UPDATE ON public.tic_tac_toe_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.tic_tac_toe_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.tic_tac_toe_games;

CREATE OR REPLACE FUNCTION public.tic_tac_toe_create_game()
RETURNS public.tic_tac_toe_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.tic_tac_toe_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  INSERT INTO public.tic_tac_toe_games (code, host_id, status, last_message)
  VALUES (v_code, auth.uid(), 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.tic_tac_toe_join_game(_code text)
RETURNS public.tic_tac_toe_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.tic_tac_toe_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.tic_tac_toe_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.tic_tac_toe_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Host (X) goes first.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.tic_tac_toe_play(_game_id uuid, _cell smallint)
RETURNS public.tic_tac_toe_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.tic_tac_toe_games;
  v_is_host boolean;
  v_me smallint;
  v_board smallint[];
  v_winner uuid;
  v_status text := 'playing';
  v_msg text;
  -- all 8 winning lines as 0-based cell indices
  lines smallint[][] := ARRAY[
    ARRAY[0,1,2], ARRAY[3,4,5], ARRAY[6,7,8],
    ARRAY[0,3,6], ARRAY[1,4,7], ARRAY[2,5,8],
    ARRAY[0,4,8], ARRAY[2,4,6]
  ];
  line smallint[];
  full_board boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _cell < 0 OR _cell > 8 THEN RAISE EXCEPTION 'Invalid cell'; END IF;

  SELECT * INTO v_game FROM public.tic_tac_toe_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true; v_me := 1;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false; v_me := 2;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF v_game.turn <> v_me THEN RAISE EXCEPTION 'Not your turn'; END IF;

  v_board := v_game.board;
  IF v_board[_cell + 1] <> 0 THEN RAISE EXCEPTION 'Cell already taken'; END IF;
  v_board[_cell + 1] := v_me;

  FOREACH line SLICE 1 IN ARRAY lines LOOP
    IF v_board[line[1]+1] = v_me AND v_board[line[2]+1] = v_me AND v_board[line[3]+1] = v_me THEN
      v_status := 'finished';
      v_winner := auth.uid();
      v_msg := (CASE WHEN v_is_host THEN 'Host (X)' ELSE 'Guest (O)' END) || ' wins!';
    END IF;
  END LOOP;

  IF v_status = 'playing' THEN
    full_board := NOT (0 = ANY(v_board));
    IF full_board THEN
      v_status := 'finished';
      v_msg := 'Board is full — it''s a draw!';
    ELSE
      v_msg := (CASE WHEN v_is_host THEN 'Guest (O)' ELSE 'Host (X)' END) || '''s turn.';
    END IF;
  END IF;

  UPDATE public.tic_tac_toe_games
    SET board = v_board,
        turn = CASE WHEN v_status = 'playing' THEN (CASE WHEN v_me = 1 THEN 2 ELSE 1 END) ELSE turn END,
        status = v_status,
        winner_id = v_winner,
        last_message = v_msg,
        updated_at = now()
    WHERE id = _game_id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.tic_tac_toe_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.tic_tac_toe_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.tic_tac_toe_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.tic_tac_toe_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.tic_tac_toe_play(uuid, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.tic_tac_toe_leave_game(uuid) TO authenticated;
