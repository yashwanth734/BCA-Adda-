-- Matchmaking: a persistent queue per game type. When a second player
-- joins the same game_type queue, a trigger pairs them and creates the
-- actual game room automatically via the existing *_create_game RPC
-- pattern. Both players get a notification telling them the match is
-- ready. No persistent server process needed — the trigger fires inside
-- the INSERT transaction, so it's atomic and race-condition-safe.
--
-- Supported game types: connect_four, tic_tac_toe, othello,
-- dots_and_boxes, checkers, battleship.
-- RPS excluded — it needs a hidden-pick phase that doesn't fit the
-- simple auto-create pattern.

CREATE TABLE public.matchmaking_queue (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  game_type text NOT NULL CHECK (game_type IN (
    'connect_four','tic_tac_toe','othello','dots_and_boxes','checkers','battleship'
  )),
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, game_type) -- one queue entry per player per game
);

GRANT SELECT, INSERT, DELETE ON public.matchmaking_queue TO authenticated;
GRANT ALL ON public.matchmaking_queue TO service_role;
ALTER TABLE public.matchmaking_queue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users see their own queue entries"
ON public.matchmaking_queue FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "users join the queue"
ON public.matchmaking_queue FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users leave the queue"
ON public.matchmaking_queue FOR DELETE TO authenticated
USING (auth.uid() = user_id);

ALTER TABLE public.matchmaking_queue REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.matchmaking_queue;

-- also allow the new notification type
ALTER TABLE public.notifications DROP CONSTRAINT notifications_type_check;
ALTER TABLE public.notifications ADD CONSTRAINT notifications_type_check
  CHECK (type IN ('dm','mention','friend_request','friend_accepted','assignment_due','study_group','match_found'));

-- Called by the trigger when two players are waiting for the same game.
-- Creates the game room (using the same code-generation pattern as the
-- individual *_create_game RPCs), inserts both players, and notifies them.
-- Runs SECURITY DEFINER so it can write to tables on behalf of the
-- matched users without needing their auth.uid() context.
CREATE OR REPLACE FUNCTION public.attempt_matchmaking(_game_type text, _challenger_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_other uuid;
  v_code text;
  v_game_id uuid;
  v_link text;
  v_challenger_name text;
  v_other_name text;
BEGIN
  -- find the oldest waiting player (not the one who just joined)
  SELECT user_id INTO v_other
  FROM public.matchmaking_queue
  WHERE game_type = _game_type AND user_id <> _challenger_id
  ORDER BY joined_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED;

  IF v_other IS NULL THEN RETURN; END IF; -- nobody else waiting yet

  -- remove both from the queue first to avoid double-matching
  DELETE FROM public.matchmaking_queue
  WHERE user_id IN (_challenger_id, v_other) AND game_type = _game_type;

  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));
  v_link := '/games/' || replace(_game_type, '_', '-');

  -- create the game room with v_other as host, _challenger as guest
  CASE _game_type
    WHEN 'connect_four' THEN
      INSERT INTO public.connect_four_games (code, host_id, guest_id, status, last_message)
      VALUES (v_code, v_other, _challenger_id, 'playing', 'Matchmaking found a game — host goes first.')
      RETURNING id INTO v_game_id;

    WHEN 'tic_tac_toe' THEN
      DECLARE v_board smallint[] := array_fill(0::smallint, ARRAY[9]);
      BEGIN
        INSERT INTO public.tic_tac_toe_games (code, host_id, guest_id, board, status, last_message)
        VALUES (v_code, v_other, _challenger_id, v_board, 'playing', 'Match found — host (X) goes first.')
        RETURNING id INTO v_game_id;
      END;

    WHEN 'othello' THEN
      DECLARE v_board smallint[] := array_fill(0::smallint, ARRAY[64]);
      BEGIN
        v_board[3*8+3+1] := 2; v_board[3*8+4+1] := 1;
        v_board[4*8+3+1] := 1; v_board[4*8+4+1] := 2;
        INSERT INTO public.othello_games (code, host_id, guest_id, board, status, last_message)
        VALUES (v_code, v_other, _challenger_id, v_board, 'playing', 'Match found — host (black) goes first.')
        RETURNING id INTO v_game_id;
      END;

    WHEN 'dots_and_boxes' THEN
      INSERT INTO public.dots_boxes_games (code, host_id, guest_id, status, last_message)
      VALUES (v_code, v_other, _challenger_id, 'playing', 'Match found — host draws first.')
      RETURNING id INTO v_game_id;

    WHEN 'checkers' THEN
      DECLARE v_board smallint[] := array_fill(0::smallint, ARRAY[64]);
               r int; c int;
      BEGIN
        FOR r IN 0..2 LOOP FOR c IN 0..7 LOOP IF (r+c)%2=1 THEN v_board[r*8+c+1]:=1; END IF; END LOOP; END LOOP;
        FOR r IN 5..7 LOOP FOR c IN 0..7 LOOP IF (r+c)%2=1 THEN v_board[r*8+c+1]:=2; END IF; END LOOP; END LOOP;
        INSERT INTO public.checkers_games (code, host_id, guest_id, board, status, last_message)
        VALUES (v_code, v_other, _challenger_id, v_board, 'playing', 'Match found — host moves first.')
        RETURNING id INTO v_game_id;
      END;

    WHEN 'battleship' THEN
      INSERT INTO public.battleship_games (code, host_id, guest_id, status, phase, last_message)
      VALUES (v_code, v_other, _challenger_id, 'playing', 'placing', 'Match found — place your fleet.')
      RETURNING id INTO v_game_id;
      INSERT INTO public.battleship_games_private (game_id) VALUES (v_game_id);
  END CASE;

  SELECT COALESCE(full_name, username) INTO v_other_name FROM public.profiles WHERE id = v_other;
  SELECT COALESCE(full_name, username) INTO v_challenger_name FROM public.profiles WHERE id = _challenger_id;

  INSERT INTO public.notifications (user_id, type, title, body, link)
  VALUES
    (v_other, 'match_found', 'Match found!',
     'vs ' || COALESCE(v_challenger_name, 'a player') || ' — room ' || v_code, v_link),
    (_challenger_id, 'match_found', 'Match found!',
     'vs ' || COALESCE(v_other_name, 'a player') || ' — room ' || v_code, v_link);
END;
$$;
REVOKE EXECUTE ON FUNCTION public.attempt_matchmaking(text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.attempt_matchmaking(text, uuid) TO service_role;

-- Trigger that fires on every INSERT into the queue and tries to pair
-- the new entrant with someone already waiting.
CREATE OR REPLACE FUNCTION public.matchmaking_queue_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  PERFORM public.attempt_matchmaking(NEW.game_type, NEW.user_id);
  RETURN NEW;
END;
$$;

CREATE TRIGGER matchmaking_queue_on_insert
AFTER INSERT ON public.matchmaking_queue
FOR EACH ROW EXECUTE FUNCTION public.matchmaking_queue_trg();

-- Clean up stale queue entries (nobody showed up > 5 mins) to avoid
-- players being matched against someone who already left. Rides the
-- existing 15-minute room cleanup cron.
CREATE OR REPLACE FUNCTION public.cleanup_stale_game_rooms()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.war_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.bg_rooms WHERE status = 'lobby' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.connect_four_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.tic_tac_toe_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.rps_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.battleship_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.othello_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.dots_boxes_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.checkers_games WHERE status = 'waiting' AND created_at < now() - interval '45 minutes';
  DELETE FROM public.matchmaking_queue WHERE joined_at < now() - interval '5 minutes';
END;
$$;
