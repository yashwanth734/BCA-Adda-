
-- 1) Private state table — not exposed via Data API
CREATE TABLE IF NOT EXISTS public.war_games_private (
  game_id uuid PRIMARY KEY REFERENCES public.war_games(id) ON DELETE CASCADE,
  host_deck integer[] NOT NULL DEFAULT '{}',
  guest_deck integer[] NOT NULL DEFAULT '{}',
  host_pending_card integer,
  guest_pending_card integer,
  pot integer[] NOT NULL DEFAULT '{}'
);
GRANT ALL ON public.war_games_private TO service_role;
-- Intentionally no grants to anon/authenticated; access only via SECURITY DEFINER RPCs
ALTER TABLE public.war_games_private ENABLE ROW LEVEL SECURITY;

-- 2) Reshape war_games: drop sensitive columns, add safe public summary columns
ALTER TABLE public.war_games
  DROP COLUMN IF EXISTS host_deck,
  DROP COLUMN IF EXISTS guest_deck,
  DROP COLUMN IF EXISTS host_card,
  DROP COLUMN IF EXISTS guest_card,
  DROP COLUMN IF EXISTS pot;

ALTER TABLE public.war_games
  ADD COLUMN IF NOT EXISTS host_deck_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS guest_deck_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS pot_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS host_played boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS guest_played boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS last_host_card integer,
  ADD COLUMN IF NOT EXISTS last_guest_card integer;

-- 3) Tighten RLS on war_games: remove escalation paths, route mutations via RPCs
DROP POLICY IF EXISTS "Players can update their game" ON public.war_games;
DROP POLICY IF EXISTS "Anyone authed can create as host" ON public.war_games;
DROP POLICY IF EXISTS "Host can delete" ON public.war_games;
DROP POLICY IF EXISTS "Players or open games viewable" ON public.war_games;

CREATE POLICY "Players can view their game"
  ON public.war_games FOR SELECT TO authenticated
  USING (host_id = auth.uid() OR guest_id = auth.uid());

-- 4) RPCs
CREATE OR REPLACE FUNCTION public.war_create_game()
RETURNS public.war_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_deck integer[];
  v_game public.war_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));
  SELECT array_agg(i ORDER BY random()) INTO v_deck FROM generate_series(0, 51) i;

  INSERT INTO public.war_games (code, host_id, host_deck_count, guest_deck_count, status, last_message)
  VALUES (v_code, auth.uid(), 26, 26, 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  INSERT INTO public.war_games_private (game_id, host_deck, guest_deck)
  VALUES (v_game.id, v_deck[1:26], v_deck[27:52]);

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.war_join_game(_code text)
RETURNS public.war_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.war_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.war_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;
  UPDATE public.war_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Draw a card.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;
  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.war_play_card(_game_id uuid)
RETURNS public.war_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.war_games;
  v_priv public.war_games_private;
  v_is_host boolean;
  v_top integer;
  v_h_card integer;
  v_g_card integer;
  v_h_rank integer;
  v_g_rank integer;
  v_pot integer[];
  v_msg text;
  v_status text := 'playing';
  v_winner uuid := NULL;
  v_new_host integer[];
  v_new_guest integer[];
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.war_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;
  IF auth.uid() = v_game.host_id THEN v_is_host := true;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  SELECT * INTO v_priv FROM public.war_games_private WHERE game_id = _game_id FOR UPDATE;

  IF v_is_host THEN
    IF v_priv.host_pending_card IS NOT NULL THEN RAISE EXCEPTION 'Already played'; END IF;
    IF array_length(v_priv.host_deck, 1) IS NULL THEN RAISE EXCEPTION 'Deck empty'; END IF;
    v_top := v_priv.host_deck[1];
    UPDATE public.war_games_private
      SET host_pending_card = v_top, host_deck = v_priv.host_deck[2:]
      WHERE game_id = _game_id;
    UPDATE public.war_games
      SET host_played = true,
          host_deck_count = greatest(host_deck_count - 1, 0),
          updated_at = now()
      WHERE id = _game_id;
  ELSE
    IF v_priv.guest_pending_card IS NOT NULL THEN RAISE EXCEPTION 'Already played'; END IF;
    IF array_length(v_priv.guest_deck, 1) IS NULL THEN RAISE EXCEPTION 'Deck empty'; END IF;
    v_top := v_priv.guest_deck[1];
    UPDATE public.war_games_private
      SET guest_pending_card = v_top, guest_deck = v_priv.guest_deck[2:]
      WHERE game_id = _game_id;
    UPDATE public.war_games
      SET guest_played = true,
          guest_deck_count = greatest(guest_deck_count - 1, 0),
          updated_at = now()
      WHERE id = _game_id;
  END IF;

  SELECT * INTO v_priv FROM public.war_games_private WHERE game_id = _game_id FOR UPDATE;
  SELECT * INTO v_game FROM public.war_games WHERE id = _game_id FOR UPDATE;

  IF v_priv.host_pending_card IS NOT NULL AND v_priv.guest_pending_card IS NOT NULL THEN
    v_h_card := v_priv.host_pending_card;
    v_g_card := v_priv.guest_pending_card;
    v_h_rank := v_h_card % 13;
    v_g_rank := v_g_card % 13;
    v_pot := v_priv.pot || ARRAY[v_h_card, v_g_card];
    v_new_host := v_priv.host_deck;
    v_new_guest := v_priv.guest_deck;
    IF v_h_rank > v_g_rank THEN
      SELECT array_agg(x ORDER BY random()) INTO v_pot FROM unnest(v_pot) x;
      v_msg := 'Host wins ' || array_length(v_pot,1) || ' cards';
      v_new_host := v_new_host || v_pot;
      v_pot := '{}';
    ELSIF v_g_rank > v_h_rank THEN
      SELECT array_agg(x ORDER BY random()) INTO v_pot FROM unnest(v_pot) x;
      v_msg := 'Guest wins ' || array_length(v_pot,1) || ' cards';
      v_new_guest := v_new_guest || v_pot;
      v_pot := '{}';
    ELSE
      v_msg := 'WAR! Pot is ' || array_length(v_pot,1) || '. Draw again.';
    END IF;

    IF v_h_rank <> v_g_rank THEN
      IF array_length(v_new_host, 1) IS NULL THEN
        v_status := 'finished'; v_winner := v_game.guest_id; v_msg := 'Guest wins the game!';
      ELSIF array_length(v_new_guest, 1) IS NULL THEN
        v_status := 'finished'; v_winner := v_game.host_id; v_msg := 'Host wins the game!';
      END IF;
    END IF;

    UPDATE public.war_games_private
      SET host_deck = v_new_host,
          guest_deck = v_new_guest,
          host_pending_card = NULL,
          guest_pending_card = NULL,
          pot = v_pot
      WHERE game_id = _game_id;

    UPDATE public.war_games
      SET host_played = false,
          guest_played = false,
          last_host_card = v_h_card,
          last_guest_card = v_g_card,
          host_deck_count = COALESCE(array_length(v_new_host,1), 0),
          guest_deck_count = COALESCE(array_length(v_new_guest,1), 0),
          pot_count = COALESCE(array_length(v_pot,1), 0),
          last_message = v_msg,
          status = v_status,
          winner_id = v_winner,
          updated_at = now()
      WHERE id = _game_id
      RETURNING * INTO v_game;
  END IF;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.war_my_state(_game_id uuid)
RETURNS TABLE(deck_size integer, pending_card integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public STABLE
AS $$
DECLARE
  v_game public.war_games;
  v_priv public.war_games_private;
BEGIN
  SELECT * INTO v_game FROM public.war_games WHERE id = _game_id;
  IF v_game.id IS NULL THEN RETURN; END IF;
  IF auth.uid() NOT IN (v_game.host_id, COALESCE(v_game.guest_id, '00000000-0000-0000-0000-000000000000'::uuid)) THEN RETURN; END IF;
  SELECT * INTO v_priv FROM public.war_games_private WHERE game_id = _game_id;
  IF auth.uid() = v_game.host_id THEN
    deck_size := COALESCE(array_length(v_priv.host_deck,1), 0);
    pending_card := v_priv.host_pending_card;
  ELSE
    deck_size := COALESCE(array_length(v_priv.guest_deck,1), 0);
    pending_card := v_priv.guest_pending_card;
  END IF;
  RETURN NEXT;
END;
$$;

CREATE OR REPLACE FUNCTION public.war_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.war_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.war_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_play_card(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_my_state(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.war_leave_game(uuid) TO authenticated;
