-- Room-chat moderation: War's room chat was pure Supabase broadcast
-- (in-memory, never stored, therefore never moderatable). This migration
-- adds a persisted table for game-room chat messages, shared across War
-- and any other multiplayer game that wants an in-game chat channel.
-- The existing ReportDialog already works on messages — once game chat
-- messages exist in a table with RLS, teachers can report/moderate them
-- through the same path.

CREATE TABLE public.game_room_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  game_type text NOT NULL, -- e.g. 'war_games', 'connect_four_games'
  game_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 500),
  removed_at timestamptz, -- soft-delete for moderation, mirrors public.messages
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX game_room_messages_game_idx ON public.game_room_messages (game_type, game_id, created_at);

GRANT SELECT, INSERT ON public.game_room_messages TO authenticated;
GRANT ALL ON public.game_room_messages TO service_role;
ALTER TABLE public.game_room_messages ENABLE ROW LEVEL SECURITY;

-- Everyone can read game room chat (same as the board state itself — public once playing)
CREATE POLICY "game room chat viewable by authenticated"
ON public.game_room_messages FOR SELECT TO authenticated USING (true);

-- Only post in a room you're part of — checked server-side by the insert
-- policy: we rely on the fact that a user can only know a game_id if they
-- have access to that game's row. Lightweight check is fine since the
-- full rate-limit + content-length enforcement runs on insert.
CREATE POLICY "authenticated users post game room messages"
ON public.game_room_messages FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Soft-delete: teacher (or system) can remove content without losing audit trail
CREATE POLICY "teachers can soft-delete game room messages"
ON public.game_room_messages FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'teacher'))
WITH CHECK (public.has_role(auth.uid(), 'teacher'));

ALTER TABLE public.game_room_messages REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_room_messages;

-- Rate limit: reuse the same 700ms chat throttle
CREATE TRIGGER game_room_messages_rate_limit
BEFORE INSERT ON public.game_room_messages
FOR EACH ROW EXECUTE FUNCTION public.messages_rate_limit_trg();

-- Mention notifications work the same way as channel chat.
-- We need a separate trigger function since game_room_messages uses
-- game_id (not channel_id) as its location reference.
CREATE OR REPLACE FUNCTION public.notify_game_room_mentions_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_sender_name text;
  v_mentioned record;
BEGIN
  SELECT COALESCE(full_name, username) INTO v_sender_name FROM public.profiles WHERE id = NEW.user_id;

  FOR v_mentioned IN
    SELECT DISTINCT p.id
    FROM regexp_matches(NEW.content, '@([A-Za-z0-9_]+)', 'g') AS m(handle)
    JOIN public.profiles p ON lower(p.username) = lower(m.handle[1])
    WHERE p.id <> NEW.user_id
  LOOP
    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (
      v_mentioned.id,
      'mention',
      COALESCE(v_sender_name, 'Someone') || ' mentioned you',
      left(NEW.content, 120),
      '/games'
    );
  END LOOP;

  RETURN NEW;
END;
$$;

CREATE TRIGGER game_room_messages_mentions
AFTER INSERT ON public.game_room_messages
FOR EACH ROW EXECUTE FUNCTION public.notify_game_room_mentions_trg();
