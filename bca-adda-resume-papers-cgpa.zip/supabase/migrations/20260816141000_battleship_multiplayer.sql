-- Battleship: a tougher real-time head-to-head game. 6x6 grid, 36 cells.
-- Each player secretly places 3 ships (lengths 3, 2, 2 — 7 cells total),
-- then players take turns firing at each other's grid until one side's
-- ships are all sunk. Ship positions are hidden info, same private-table
-- pattern as war_games/rps_games.

CREATE TABLE public.battleship_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  -- 36 cells each. 0 = not fired on, 1 = miss, 2 = hit.
  -- host_shots = shots the HOST has fired, landing on the GUEST's grid.
  host_shots smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[36]),
  guest_shots smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[36]),
  host_ready boolean NOT NULL DEFAULT false,
  guest_ready boolean NOT NULL DEFAULT false,
  turn smallint NOT NULL DEFAULT 1, -- 1 = host fires next, 2 = guest fires next
  phase text NOT NULL DEFAULT 'placing', -- placing | playing | finished
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.battleship_games_private (
  game_id uuid PRIMARY KEY REFERENCES public.battleship_games(id) ON DELETE CASCADE,
  host_ships smallint[], -- 0-based cell indices where the host's ships sit
  guest_ships smallint[]
);

GRANT SELECT ON public.battleship_games TO authenticated;
GRANT ALL ON public.battleship_games TO service_role;
GRANT ALL ON public.battleship_games_private TO service_role;

ALTER TABLE public.battleship_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.battleship_games_private ENABLE ROW LEVEL SECURITY;
-- no authenticated policy on the private table — only SECURITY DEFINER
-- functions can touch ship positions.

CREATE POLICY "players view their battleship game"
ON public.battleship_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER battleship_games_touch
BEFORE UPDATE ON public.battleship_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.battleship_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.battleship_games;

CREATE OR REPLACE FUNCTION public.battleship_create_game()
RETURNS public.battleship_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.battleship_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  INSERT INTO public.battleship_games (code, host_id, status, last_message)
  VALUES (v_code, auth.uid(), 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  INSERT INTO public.battleship_games_private (game_id) VALUES (v_game.id);

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.battleship_join_game(_code text)
RETURNS public.battleship_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.battleship_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.battleship_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.battleship_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Both players: place your 3 ships (lengths 3, 2, 2).',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

-- Places this player's ships. Requires exactly 7 unique cells (3+2+2) inside
-- the 36-cell grid. Doesn't enforce contiguous ship shapes — any 7 cells the
-- player picks count as "their ships" — that's the one simplification here.
CREATE OR REPLACE FUNCTION public.battleship_place_ships(_game_id uuid, _cells smallint[])
RETURNS public.battleship_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.battleship_games;
  v_is_host boolean;
  v_unique_count int;
  c smallint;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;

  SELECT * INTO v_game FROM public.battleship_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.phase <> 'placing' THEN RAISE EXCEPTION 'Ships already placed'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF array_length(_cells, 1) IS DISTINCT FROM 7 THEN
    RAISE EXCEPTION 'Place exactly 7 ship cells (ships of length 3, 2, 2)';
  END IF;

  SELECT count(DISTINCT c) INTO v_unique_count FROM unnest(_cells) AS c;
  IF v_unique_count <> 7 THEN RAISE EXCEPTION 'Ship cells must be unique'; END IF;

  FOREACH c IN ARRAY _cells LOOP
    IF c < 0 OR c > 35 THEN RAISE EXCEPTION 'Cell out of range'; END IF;
  END LOOP;

  IF v_is_host THEN
    UPDATE public.battleship_games_private SET host_ships = _cells WHERE game_id = _game_id;
    UPDATE public.battleship_games SET host_ready = true WHERE id = _game_id;
  ELSE
    UPDATE public.battleship_games_private SET guest_ships = _cells WHERE game_id = _game_id;
    UPDATE public.battleship_games SET guest_ready = true WHERE id = _game_id;
  END IF;

  SELECT * INTO v_game FROM public.battleship_games WHERE id = _game_id;

  IF v_game.host_ready AND v_game.guest_ready THEN
    UPDATE public.battleship_games
      SET phase = 'playing',
          last_message = 'Fleets are set — host fires first.',
          updated_at = now()
      WHERE id = _game_id
      RETURNING * INTO v_game;
  ELSE
    UPDATE public.battleship_games
      SET last_message = 'Waiting for the other player to place their fleet…',
          updated_at = now()
      WHERE id = _game_id
      RETURNING * INTO v_game;
  END IF;

  RETURN v_game;
END;
$$;

-- Fires at a cell on the opponent's grid. Checks the opponent's private ship
-- list to determine hit/miss, records it in the shooter's own *_shots array
-- (public — a hit/miss result isn't secret once fired), and checks whether
-- every one of the opponent's ship cells has now been hit.
CREATE OR REPLACE FUNCTION public.battleship_fire(_game_id uuid, _cell smallint)
RETURNS public.battleship_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.battleship_games;
  v_priv public.battleship_games_private;
  v_is_host boolean;
  v_me smallint;
  v_shots smallint[];
  v_opp_ships smallint[];
  v_opp_shots smallint[];
  v_is_hit boolean;
  v_all_sunk boolean := true;
  v_status text := 'playing';
  v_phase text := 'playing';
  v_winner uuid;
  v_msg text;
  s smallint;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _cell < 0 OR _cell > 35 THEN RAISE EXCEPTION 'Invalid cell'; END IF;

  SELECT * INTO v_game FROM public.battleship_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.phase <> 'playing' THEN RAISE EXCEPTION 'Game not in firing phase'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true; v_me := 1;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false; v_me := 2;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF v_game.turn <> v_me THEN RAISE EXCEPTION 'Not your turn'; END IF;

  SELECT * INTO v_priv FROM public.battleship_games_private WHERE game_id = _game_id FOR UPDATE;

  IF v_is_host THEN
    v_shots := v_game.host_shots;
    v_opp_ships := v_priv.guest_ships;
  ELSE
    v_shots := v_game.guest_shots;
    v_opp_ships := v_priv.host_ships;
  END IF;

  IF v_shots[_cell + 1] <> 0 THEN RAISE EXCEPTION 'Already fired at that cell'; END IF;

  v_is_hit := _cell = ANY(v_opp_ships);
  v_shots[_cell + 1] := CASE WHEN v_is_hit THEN 2 ELSE 1 END;

  FOREACH s IN ARRAY v_opp_ships LOOP
    IF v_shots[s + 1] <> 2 THEN v_all_sunk := false; END IF;
  END LOOP;

  IF v_all_sunk THEN
    v_status := 'finished';
    v_phase := 'finished';
    v_winner := auth.uid();
    v_msg := (CASE WHEN v_is_host THEN 'Host' ELSE 'Guest' END) || ' sinks the whole fleet and wins!';
  ELSE
    v_msg := (CASE WHEN v_is_hit THEN 'Hit! ' ELSE 'Miss. ' END)
      || (CASE WHEN v_is_host THEN 'Guest' ELSE 'Host' END) || '''s turn.';
  END IF;

  IF v_is_host THEN
    UPDATE public.battleship_games
      SET host_shots = v_shots,
          turn = CASE WHEN v_status = 'playing' THEN 2 ELSE turn END,
          status = v_status, phase = v_phase, winner_id = v_winner,
          last_message = v_msg, updated_at = now()
      WHERE id = _game_id
      RETURNING * INTO v_game;
  ELSE
    UPDATE public.battleship_games
      SET guest_shots = v_shots,
          turn = CASE WHEN v_status = 'playing' THEN 1 ELSE turn END,
          status = v_status, phase = v_phase, winner_id = v_winner,
          last_message = v_msg, updated_at = now()
      WHERE id = _game_id
      RETURNING * INTO v_game;
  END IF;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.battleship_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.battleship_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.battleship_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.battleship_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.battleship_place_ships(uuid, smallint[]) TO authenticated;
GRANT EXECUTE ON FUNCTION public.battleship_fire(uuid, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.battleship_leave_game(uuid) TO authenticated;
