-- Rock Paper Scissors: real-time head-to-head, best of 5. Picks must stay
-- hidden until both players have chosen, so — like war_games — this needs a
-- private table the client can never SELECT from directly.

CREATE TABLE public.rps_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  round smallint NOT NULL DEFAULT 1,
  host_score smallint NOT NULL DEFAULT 0,
  guest_score smallint NOT NULL DEFAULT 0,
  host_picked boolean NOT NULL DEFAULT false, -- true once host has chosen this round
  guest_picked boolean NOT NULL DEFAULT false,
  last_host_choice text, -- revealed only after the round resolves
  last_guest_choice text,
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.rps_games_private (
  game_id uuid PRIMARY KEY REFERENCES public.rps_games(id) ON DELETE CASCADE,
  host_choice text,
  guest_choice text
);

GRANT SELECT ON public.rps_games TO authenticated;
GRANT ALL ON public.rps_games TO service_role;
GRANT ALL ON public.rps_games_private TO service_role;

ALTER TABLE public.rps_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rps_games_private ENABLE ROW LEVEL SECURITY;
-- no policies on rps_games_private for authenticated: only SECURITY DEFINER
-- functions (running as the table owner) can read or write it.

CREATE POLICY "players view their rps game"
ON public.rps_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER rps_games_touch
BEFORE UPDATE ON public.rps_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.rps_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.rps_games;

CREATE OR REPLACE FUNCTION public.rps_create_game()
RETURNS public.rps_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.rps_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  INSERT INTO public.rps_games (code, host_id, status, last_message)
  VALUES (v_code, auth.uid(), 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  INSERT INTO public.rps_games_private (game_id) VALUES (v_game.id);

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.rps_join_game(_code text)
RETURNS public.rps_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.rps_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.rps_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.rps_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Make your pick.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

-- Records this player's pick for the current round. Once both players have
-- picked, resolves the round: reveals both choices, updates scores, and
-- ends the match at first-to-3.
CREATE OR REPLACE FUNCTION public.rps_choose(_game_id uuid, _choice text)
RETURNS public.rps_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.rps_games;
  v_is_host boolean;
  v_priv public.rps_games_private;
  v_host_choice text;
  v_guest_choice text;
  v_result smallint; -- 0 = tie, 1 = host wins round, 2 = guest wins round
  v_host_score smallint;
  v_guest_score smallint;
  v_status text := 'playing';
  v_winner uuid;
  v_msg text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _choice NOT IN ('rock', 'paper', 'scissors') THEN RAISE EXCEPTION 'Invalid choice'; END IF;

  SELECT * INTO v_game FROM public.rps_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  SELECT * INTO v_priv FROM public.rps_games_private WHERE game_id = _game_id FOR UPDATE;

  IF v_is_host THEN
    IF v_game.host_picked THEN RAISE EXCEPTION 'Already picked this round'; END IF;
    UPDATE public.rps_games_private SET host_choice = _choice WHERE game_id = _game_id;
    UPDATE public.rps_games SET host_picked = true WHERE id = _game_id;
  ELSE
    IF v_game.guest_picked THEN RAISE EXCEPTION 'Already picked this round'; END IF;
    UPDATE public.rps_games_private SET guest_choice = _choice WHERE game_id = _game_id;
    UPDATE public.rps_games SET guest_picked = true WHERE id = _game_id;
  END IF;

  SELECT * INTO v_game FROM public.rps_games WHERE id = _game_id;

  IF NOT (v_game.host_picked AND v_game.guest_picked) THEN
    v_game.last_message := 'Waiting for the other player to pick…';
    RETURN v_game;
  END IF;

  -- both have picked: resolve the round
  SELECT * INTO v_priv FROM public.rps_games_private WHERE game_id = _game_id;
  v_host_choice := v_priv.host_choice;
  v_guest_choice := v_priv.guest_choice;

  IF v_host_choice = v_guest_choice THEN
    v_result := 0;
  ELSIF (v_host_choice = 'rock' AND v_guest_choice = 'scissors')
     OR (v_host_choice = 'paper' AND v_guest_choice = 'rock')
     OR (v_host_choice = 'scissors' AND v_guest_choice = 'paper') THEN
    v_result := 1;
  ELSE
    v_result := 2;
  END IF;

  v_host_score := v_game.host_score + (CASE WHEN v_result = 1 THEN 1 ELSE 0 END);
  v_guest_score := v_game.guest_score + (CASE WHEN v_result = 2 THEN 1 ELSE 0 END);

  IF v_host_score >= 3 THEN
    v_status := 'finished'; v_winner := v_game.host_id;
    v_msg := 'Host wins the match ' || v_host_score || '-' || v_guest_score || '!';
  ELSIF v_guest_score >= 3 THEN
    v_status := 'finished'; v_winner := v_game.guest_id;
    v_msg := 'Guest wins the match ' || v_guest_score || '-' || v_host_score || '!';
  ELSE
    v_msg := CASE
      WHEN v_result = 0 THEN 'Tie round — ' || v_host_choice || ' vs ' || v_guest_choice
      WHEN v_result = 1 THEN v_host_choice || ' beats ' || v_guest_choice || ' — host takes the round'
      ELSE v_guest_choice || ' beats ' || v_host_choice || ' — guest takes the round'
    END;
  END IF;

  UPDATE public.rps_games_private SET host_choice = NULL, guest_choice = NULL WHERE game_id = _game_id;

  UPDATE public.rps_games
    SET round = round + 1,
        host_score = v_host_score,
        guest_score = v_guest_score,
        host_picked = false,
        guest_picked = false,
        last_host_choice = v_host_choice,
        last_guest_choice = v_guest_choice,
        status = v_status,
        winner_id = v_winner,
        last_message = v_msg,
        updated_at = now()
    WHERE id = _game_id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.rps_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.rps_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.rps_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.rps_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rps_choose(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rps_leave_game(uuid) TO authenticated;
