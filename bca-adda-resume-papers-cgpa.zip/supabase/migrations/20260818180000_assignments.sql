-- Feature: assignment/deadline tracker, personal per-user (like the
-- existing subjects/attendance data, not shared — matches ownership
-- model, unlike subject_notes which is intentionally public).
-- "Reminders" here means in-app notifications via the notifications
-- table already built — true push/email still needs an external
-- provider wired through an Edge Function, which is a deployment step
-- outside what a migration can do.

CREATE TABLE public.assignments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 150),
  subject_name text CHECK (subject_name IS NULL OR char_length(subject_name) <= 60),
  description text CHECK (description IS NULL OR char_length(description) <= 1000),
  due_at timestamptz NOT NULL,
  completed boolean NOT NULL DEFAULT false,
  reminded boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX assignments_user_due_idx ON public.assignments (user_id, due_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.assignments TO authenticated;
GRANT ALL ON public.assignments TO service_role;
ALTER TABLE public.assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own assignments select" ON public.assignments FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own assignments insert" ON public.assignments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own assignments update" ON public.assignments FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own assignments delete" ON public.assignments FOR DELETE TO authenticated USING (auth.uid() = user_id);

ALTER TABLE public.assignments REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.assignments;

-- allow the new notification type
ALTER TABLE public.notifications DROP CONSTRAINT notifications_type_check;
ALTER TABLE public.notifications ADD CONSTRAINT notifications_type_check
  CHECK (type IN ('dm', 'mention', 'friend_request', 'friend_accepted', 'assignment_due'));

-- Runs periodically: notifies the owner of any assignment due within the
-- next 24 hours that hasn't been reminded about yet, then marks it so it
-- doesn't fire again. Completed assignments are skipped.
CREATE OR REPLACE FUNCTION public.remind_upcoming_assignments()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_row record;
BEGIN
  FOR v_row IN
    SELECT * FROM public.assignments
    WHERE completed = false AND reminded = false
      AND due_at BETWEEN now() AND now() + interval '24 hours'
  LOOP
    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (
      v_row.user_id,
      'assignment_due',
      '"' || v_row.title || '" is due soon',
      COALESCE(v_row.subject_name, '') ||
        CASE WHEN v_row.subject_name IS NOT NULL THEN ' — ' ELSE '' END ||
        'due ' || to_char(v_row.due_at, 'Mon DD, HH12:MI AM'),
      '/assignments'
    );
    UPDATE public.assignments SET reminded = true WHERE id = v_row.id;
  END LOOP;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.remind_upcoming_assignments() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.remind_upcoming_assignments() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'remind-upcoming-assignments',
    '*/30 * * * *',
    $cron$SELECT public.remind_upcoming_assignments();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.remind_upcoming_assignments() manually if pg_cron is unavailable.', SQLERRM;
END;
$$;
