-- Room-chat moderation gap: the War and Trade City in-game chat is
-- currently ephemeral broadcast (never touches the DB), so the existing
-- moderation tools can't reach it. Fixing this means persisting messages
-- to a new table, keeping the realtime broadcast feel via the existing
-- realtime publication, and giving moderators a DELETE policy.

CREATE TABLE public.room_chat_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id text NOT NULL,          -- bg_rooms.id or war_games.id (both uuid, stored as text for flexibility)
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL CHECK (char_length(display_name) <= 60),
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 200),
  removed_at timestamptz,         -- soft-delete by moderators, keeps the log
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX room_chat_messages_room_idx ON public.room_chat_messages (room_id, created_at);

GRANT SELECT, INSERT ON public.room_chat_messages TO authenticated;
GRANT ALL ON public.room_chat_messages TO service_role;
ALTER TABLE public.room_chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "room chat viewable by authenticated"
ON public.room_chat_messages FOR SELECT TO authenticated USING (true);

CREATE POLICY "users send their own room chat messages"
ON public.room_chat_messages FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- moderators soft-delete only (set removed_at), never hard-delete
CREATE POLICY "teachers soft-delete room chat messages"
ON public.room_chat_messages FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'teacher'))
WITH CHECK (public.has_role(auth.uid(), 'teacher'));

ALTER TABLE public.room_chat_messages REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.room_chat_messages;

-- Rate limit: reuse the shared enforce_rate_limit pattern
CREATE OR REPLACE FUNCTION public.room_chat_rate_limit_trg()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM public.enforce_rate_limit('room_chat', interval '700 milliseconds');
  RETURN NEW;
END;
$$;

CREATE TRIGGER room_chat_messages_rate_limit
BEFORE INSERT ON public.room_chat_messages
FOR EACH ROW EXECUTE FUNCTION public.room_chat_rate_limit_trg();

-- clean up old room chat (>7 days, matching the ephemeral feel but with
-- a retention window that gives mods time to act)
CREATE OR REPLACE FUNCTION public.cleanup_old_room_chat()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.room_chat_messages WHERE created_at < now() - interval '7 days';
END;
$$;
REVOKE EXECUTE ON FUNCTION public.cleanup_old_room_chat() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_old_room_chat() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'cleanup-old-room-chat',
    '0 4 * * *',
    $cron$SELECT public.cleanup_old_room_chat();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.cleanup_old_room_chat() manually if pg_cron is unavailable.', SQLERRM;
END;
$$;
