-- Feature: shared notes/resources, tagged by subject name. Not tied to
-- the `subjects` table — that table is a private per-user attendance
-- list (RLS-scoped to auth.uid() = user_id, not visible to others), so
-- it can't double as a shared "class subject" concept. Notes are tagged
-- with a free-text subject name instead, which any student can browse.
-- No file storage bucket exists in this project, so a note is either a
-- link to an external resource (Drive, PDF host, etc.) or typed text
-- content — same URL-only pattern already used for avatar_url.

CREATE TABLE public.subject_notes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subject_name text NOT NULL CHECK (char_length(subject_name) BETWEEN 1 AND 60),
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
  url text CHECK (url IS NULL OR char_length(url) <= 2000),
  content text CHECK (content IS NULL OR char_length(content) <= 5000),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (url IS NOT NULL OR content IS NOT NULL)
);

CREATE INDEX subject_notes_subject_idx ON public.subject_notes (lower(subject_name), created_at DESC);

GRANT SELECT, INSERT, DELETE ON public.subject_notes TO authenticated;
GRANT ALL ON public.subject_notes TO service_role;
ALTER TABLE public.subject_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notes viewable by authenticated"
ON public.subject_notes FOR SELECT TO authenticated USING (true);

CREATE POLICY "users add their own notes"
ON public.subject_notes FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "owner or teacher can delete a note"
ON public.subject_notes FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'teacher'));

CREATE OR REPLACE FUNCTION public.subject_notes_rate_limit_trg()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM public.enforce_rate_limit('subject_note', interval '2 seconds');
  RETURN NEW;
END;
$$;

CREATE TRIGGER subject_notes_rate_limit
BEFORE INSERT ON public.subject_notes
FOR EACH ROW EXECUTE FUNCTION public.subject_notes_rate_limit_trg();
