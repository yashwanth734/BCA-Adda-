-- Feature: in-app notifications for DMs, @mentions in chat, and friend
-- requests. True push/email delivery needs an external provider (FCM,
-- APNs, SMTP/Resend, etc.) wired through a Supabase Edge Function with
-- real credentials — that's a deployment/config step, not something a
-- migration can provide. This is the in-app half: bell icon, unread
-- badge, realtime delivery.

CREATE TABLE public.notifications (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE, -- recipient
  type text NOT NULL CHECK (type IN ('dm', 'mention', 'friend_request', 'friend_accepted')),
  title text NOT NULL,
  body text,
  link text, -- in-app route to open when clicked
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX notifications_user_idx ON public.notifications (user_id, created_at DESC);

GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "see your own notifications"
ON public.notifications FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "mark your own notifications read"
ON public.notifications FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
-- no INSERT policy for authenticated — only the trigger functions below
-- (running SECURITY DEFINER) create notifications.

ALTER TABLE public.notifications REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- DM received
CREATE OR REPLACE FUNCTION public.notify_dm_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_thread public.dm_threads;
  v_recipient uuid;
  v_sender_name text;
BEGIN
  SELECT * INTO v_thread FROM public.dm_threads WHERE id = NEW.thread_id;
  v_recipient := CASE WHEN v_thread.user_a = NEW.sender_id THEN v_thread.user_b ELSE v_thread.user_a END;

  SELECT COALESCE(full_name, username) INTO v_sender_name FROM public.profiles WHERE id = NEW.sender_id;

  INSERT INTO public.notifications (user_id, type, title, body, link)
  VALUES (v_recipient, 'dm', COALESCE(v_sender_name, 'New message'), left(NEW.content, 120), '/dm/' || NEW.thread_id);

  RETURN NEW;
END;
$$;

CREATE TRIGGER dm_messages_notify
AFTER INSERT ON public.dm_messages
FOR EACH ROW EXECUTE FUNCTION public.notify_dm_trg();

-- @mention in a chat message
CREATE OR REPLACE FUNCTION public.notify_mentions_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_sender_name text;
  v_mentioned record;
BEGIN
  SELECT COALESCE(full_name, username) INTO v_sender_name FROM public.profiles WHERE id = NEW.user_id;

  FOR v_mentioned IN
    SELECT DISTINCT p.id
    FROM regexp_matches(NEW.content, '@([A-Za-z0-9_]+)', 'g') AS m(handle)
    JOIN public.profiles p ON lower(p.username) = lower(m.handle[1])
    WHERE p.id <> NEW.user_id
  LOOP
    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (
      v_mentioned.id,
      'mention',
      COALESCE(v_sender_name, 'Someone') || ' mentioned you',
      left(NEW.content, 120),
      '/chat?channel=' || NEW.channel_id
    );
  END LOOP;

  RETURN NEW;
END;
$$;

CREATE TRIGGER messages_notify_mentions
AFTER INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.notify_mentions_trg();

-- friend request sent / accepted
CREATE OR REPLACE FUNCTION public.notify_friend_request_trg()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_requester_name text;
  v_addressee_name text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT COALESCE(full_name, username) INTO v_requester_name FROM public.profiles WHERE id = NEW.requester_id;
    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (NEW.addressee_id, 'friend_request', COALESCE(v_requester_name, 'Someone') || ' sent you a friend request', NULL, '/friends');
  ELSIF TG_OP = 'UPDATE' AND NEW.status = 'accepted' AND OLD.status IS DISTINCT FROM 'accepted' THEN
    SELECT COALESCE(full_name, username) INTO v_addressee_name FROM public.profiles WHERE id = NEW.addressee_id;
    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (NEW.requester_id, 'friend_accepted', COALESCE(v_addressee_name, 'Someone') || ' accepted your friend request', NULL, '/friends');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER friend_requests_notify_insert
AFTER INSERT ON public.friend_requests
FOR EACH ROW EXECUTE FUNCTION public.notify_friend_request_trg();

CREATE TRIGGER friend_requests_notify_update
AFTER UPDATE ON public.friend_requests
FOR EACH ROW EXECUTE FUNCTION public.notify_friend_request_trg();

-- trim old read notifications so the table doesn't grow forever
CREATE OR REPLACE FUNCTION public.cleanup_old_notifications()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.notifications WHERE read = true AND created_at < now() - interval '30 days';
  DELETE FROM public.notifications WHERE created_at < now() - interval '90 days';
END;
$$;
REVOKE EXECUTE ON FUNCTION public.cleanup_old_notifications() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_old_notifications() TO service_role;

DO $$
BEGIN
  PERFORM cron.schedule(
    'cleanup-old-notifications',
    '30 3 * * *',
    $cron$SELECT public.cleanup_old_notifications();$cron$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron scheduling skipped (%) — schedule public.cleanup_old_notifications() manually if pg_cron is unavailable.', SQLERRM;
END;
$$;
