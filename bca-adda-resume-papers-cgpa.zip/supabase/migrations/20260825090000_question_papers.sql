-- Feature: previous year question papers, shared and browsable by
-- subject + year, same open "shared with everyone" model as
-- subject_notes. Uses the note-attachments storage bucket for uploaded
-- PDF/image papers (a question paper is conceptually the same kind of
-- artifact as a note attachment, so reusing the bucket avoids creating a
-- fourth storage bucket for what's really the same use case).

CREATE TABLE public.question_papers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subject_name text NOT NULL CHECK (char_length(subject_name) BETWEEN 1 AND 60),
  semester int CHECK (semester IS NULL OR semester BETWEEN 1 AND 8),
  year int CHECK (year IS NULL OR year BETWEEN 2000 AND 2100),
  exam_type text CHECK (exam_type IS NULL OR exam_type IN ('mid_sem', 'end_sem', 'internal', 'other')),
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 150),
  url text NOT NULL CHECK (url ~ '^https://[^[:space:]]+$'), -- always a file/link, unlike subject_notes this isn't optional
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX question_papers_subject_idx ON public.question_papers (lower(subject_name), year DESC);
CREATE INDEX question_papers_semester_idx ON public.question_papers (semester);

GRANT SELECT, INSERT, DELETE ON public.question_papers TO authenticated;
GRANT ALL ON public.question_papers TO service_role;
ALTER TABLE public.question_papers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "question papers viewable by authenticated"
ON public.question_papers FOR SELECT TO authenticated USING (true);

CREATE POLICY "users add their own question papers"
ON public.question_papers FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- same MFA-verified teacher moderation pattern as subject_notes/projects
CREATE POLICY "owner or verified teacher can delete a question paper"
ON public.question_papers FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.has_verified_teacher_role());

CREATE OR REPLACE FUNCTION public.question_papers_rate_limit_trg()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM public.enforce_rate_limit('upload_question_paper', interval '2 seconds');
  RETURN NEW;
END;
$$;

CREATE TRIGGER question_papers_rate_limit
BEFORE INSERT ON public.question_papers
FOR EACH ROW EXECUTE FUNCTION public.question_papers_rate_limit_trg();
