ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS edited_at timestamptz;

CREATE POLICY "Users can update their own messages"
ON public.messages FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reported_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  message_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  target_type text NOT NULL CHECK (target_type IN ('message','user')),
  reason text NOT NULL CHECK (reason IN ('abuse','harassment','spam','hate_speech','nsfw','other')),
  details text CHECK (details IS NULL OR length(details) <= 1000),
  message_snapshot text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','reviewing','resolved','dismissed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Reporters can see their own reports"
ON public.reports FOR SELECT TO authenticated
USING (auth.uid() = reporter_id);

CREATE POLICY "Users can file reports"
ON public.reports FOR INSERT TO authenticated
WITH CHECK (auth.uid() = reporter_id AND reporter_id <> COALESCE(reported_user_id, '00000000-0000-0000-0000-000000000000'::uuid));

CREATE TRIGGER reports_touch_updated_at
BEFORE UPDATE ON public.reports
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE INDEX reports_reporter_idx ON public.reports (reporter_id, created_at DESC);