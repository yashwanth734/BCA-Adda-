-- Feature 5: friend requests + private direct messages.
-- DMs need their own tables (not the existing channels/messages, which
-- are intentionally open/world-readable to any authenticated user) so
-- that a thread's contents are only visible to its two participants.

CREATE TABLE public.friend_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  requester_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  addressee_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined')),
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  CHECK (requester_id <> addressee_id),
  UNIQUE (requester_id, addressee_id)
);

GRANT SELECT, INSERT, UPDATE ON public.friend_requests TO authenticated;
GRANT ALL ON public.friend_requests TO service_role;
ALTER TABLE public.friend_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "see requests you sent or received"
ON public.friend_requests FOR SELECT TO authenticated
USING (auth.uid() = requester_id OR auth.uid() = addressee_id);

CREATE POLICY "send a friend request"
ON public.friend_requests FOR INSERT TO authenticated
WITH CHECK (auth.uid() = requester_id);

CREATE POLICY "respond to a request sent to you"
ON public.friend_requests FOR UPDATE TO authenticated
USING (auth.uid() = addressee_id)
WITH CHECK (auth.uid() = addressee_id);

ALTER TABLE public.friend_requests REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.friend_requests;

CREATE TABLE public.dm_threads (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_a uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  user_b uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (user_a <> user_b)
);
-- one thread per unordered pair, regardless of who created it
CREATE UNIQUE INDEX dm_threads_pair_idx ON public.dm_threads (LEAST(user_a, user_b), GREATEST(user_a, user_b));

GRANT SELECT ON public.dm_threads TO authenticated;
GRANT ALL ON public.dm_threads TO service_role;
ALTER TABLE public.dm_threads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "see your own dm threads"
ON public.dm_threads FOR SELECT TO authenticated
USING (auth.uid() = user_a OR auth.uid() = user_b);

CREATE TABLE public.dm_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  thread_id uuid NOT NULL REFERENCES public.dm_threads(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.dm_messages TO authenticated;
GRANT ALL ON public.dm_messages TO service_role;
ALTER TABLE public.dm_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "see messages in your own threads"
ON public.dm_messages FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.dm_threads t
    WHERE t.id = dm_messages.thread_id AND (t.user_a = auth.uid() OR t.user_b = auth.uid())
  )
);

CREATE POLICY "send messages in your own threads"
ON public.dm_messages FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = sender_id
  AND EXISTS (
    SELECT 1 FROM public.dm_threads t
    WHERE t.id = dm_messages.thread_id AND (t.user_a = auth.uid() OR t.user_b = auth.uid())
  )
);

ALTER TABLE public.dm_messages REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.dm_messages;

CREATE TRIGGER dm_messages_rate_limit
BEFORE INSERT ON public.dm_messages
FOR EACH ROW EXECUTE FUNCTION public.messages_rate_limit_trg();

-- Accepts a pending request addressed to the caller.
CREATE OR REPLACE FUNCTION public.accept_friend_request(_request_id uuid)
RETURNS public.friend_requests
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_req public.friend_requests;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  UPDATE public.friend_requests
    SET status = 'accepted', responded_at = now()
    WHERE id = _request_id AND addressee_id = auth.uid() AND status = 'pending'
    RETURNING * INTO v_req;
  IF v_req.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  RETURN v_req;
END;
$$;
GRANT EXECUTE ON FUNCTION public.accept_friend_request(uuid) TO authenticated;

-- Gets (or lazily creates) the DM thread with another user. Requires an
-- accepted friendship — DMs are for friends, not open to any signed-in user.
CREATE OR REPLACE FUNCTION public.start_dm_thread(_other_user uuid)
RETURNS public.dm_threads
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_thread public.dm_threads;
  v_friends boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF auth.uid() = _other_user THEN RAISE EXCEPTION 'Cannot DM yourself'; END IF;

  SELECT EXISTS (
    SELECT 1 FROM public.friend_requests
    WHERE status = 'accepted'
      AND ((requester_id = auth.uid() AND addressee_id = _other_user)
        OR (requester_id = _other_user AND addressee_id = auth.uid()))
  ) INTO v_friends;
  IF NOT v_friends THEN RAISE EXCEPTION 'You can only DM accepted friends'; END IF;

  SELECT * INTO v_thread FROM public.dm_threads
    WHERE LEAST(user_a, user_b) = LEAST(auth.uid(), _other_user)
      AND GREATEST(user_a, user_b) = GREATEST(auth.uid(), _other_user);

  IF v_thread.id IS NULL THEN
    INSERT INTO public.dm_threads (user_a, user_b) VALUES (auth.uid(), _other_user)
      RETURNING * INTO v_thread;
  END IF;

  RETURN v_thread;
END;
$$;
GRANT EXECUTE ON FUNCTION public.start_dm_thread(uuid) TO authenticated;
