-- Bootstrap the first teacher account, safely.
--
-- Every signup gets 'student' by design (see handle_new_user_role() and
-- SECURITY.md's Authorization section) — there is no self-service path
-- to 'teacher', which is correct and deliberate. That means a brand-new
-- deployment has zero teachers and no way to create one except direct
-- database access. This function is that access path, made safe:
--
--   - service_role only. NOT callable by 'authenticated' or 'anon' at
--     any privilege level — this is not, and must never become, a
--     self-service "first signup wins" mechanism. That would just be a
--     slower-motion version of the exact signup-metadata escalation
--     path this project already closed.
--   - Self-limiting: refuses to run at all once a single teacher
--     already exists, so it can't be reused later as a backdoor by
--     anyone who gains service-role access some other way expecting a
--     quiet privilege-grant tool to already be sitting there.
--   - Takes an email, not a UUID — no need to hand-look-up the user's
--     id in auth.users first.
--
-- USAGE (run once, in the Supabase SQL editor, as the project owner):
--
--   SELECT public.bootstrap_first_teacher('you@yourschool.edu');
--
-- After that succeeds, use public.grant_role(uuid, 'teacher') from
-- within the app (as that first teacher) for every teacher after this one.

CREATE OR REPLACE FUNCTION public.bootstrap_first_teacher(_email text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_teacher_count int;
BEGIN
  SELECT count(*) INTO v_teacher_count FROM public.user_roles WHERE role = 'teacher';
  IF v_teacher_count > 0 THEN
    RAISE EXCEPTION 'A teacher already exists — use grant_role() instead, as an existing teacher.';
  END IF;

  SELECT id INTO v_user_id FROM auth.users WHERE lower(email) = lower(_email);
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'No user found with email %. They must sign up first, then re-run this.', _email;
  END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (v_user_id, 'teacher')
  ON CONFLICT (user_id, role) DO NOTHING;

  INSERT INTO public.security_events (user_id, event_type, detail)
  VALUES (v_user_id, 'role_granted', 'teacher granted via bootstrap_first_teacher (one-time setup)');

  RETURN 'Granted teacher to ' || _email || ' (' || v_user_id || ')';
END;
$$;

-- Deliberately no GRANT EXECUTE to authenticated or anon at all — only
-- the service_role / project owner running this from the SQL editor can
-- call it. This is the whole point: friction is a feature here, not a
-- bug to be optimized away, because the alternative is a self-service
-- role-grant race condition.
REVOKE ALL ON FUNCTION public.bootstrap_first_teacher(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.bootstrap_first_teacher(text) TO service_role;
