-- Othello (Reversi): standard 8x8 board, standard start position,
-- standard rules — flip any opponent line you bracket, must pass if you
-- have no legal move, game ends when neither side can move. No hidden
-- info, so one public table is enough (same pattern as connect_four_games).

CREATE TABLE public.othello_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  host_id uuid NOT NULL,
  guest_id uuid,
  -- 64 cells, row-major 8x8. 0 = empty, 1 = host (black), 2 = guest (white).
  board smallint[] NOT NULL DEFAULT array_fill(0::smallint, ARRAY[64]),
  turn smallint NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  winner_id uuid,
  last_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.othello_games TO authenticated;
GRANT ALL ON public.othello_games TO service_role;

ALTER TABLE public.othello_games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "players view their othello game"
ON public.othello_games FOR SELECT TO authenticated
USING (host_id = auth.uid() OR guest_id = auth.uid());

CREATE TRIGGER othello_games_touch
BEFORE UPDATE ON public.othello_games
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.othello_games REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.othello_games;

-- Pure helper: does `me` have any legal move on this board? Scans every
-- empty cell and checks all 8 directions for a valid bracketing line.
-- Not meant to be called by clients directly.
CREATE OR REPLACE FUNCTION public.othello_has_move(_board smallint[], _me smallint, _opp smallint)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  r int; c int; dr int; dc int;
  rr int; cc int; seen_opp boolean;
  dirs int[][] := ARRAY[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
  d int;
BEGIN
  FOR r IN 0..7 LOOP
    FOR c IN 0..7 LOOP
      IF _board[r*8+c+1] <> 0 THEN CONTINUE; END IF;
      FOR d IN 1..8 LOOP
        dr := dirs[d][1]; dc := dirs[d][2];
        rr := r + dr; cc := c + dc;
        seen_opp := false;
        WHILE rr BETWEEN 0 AND 7 AND cc BETWEEN 0 AND 7 AND _board[rr*8+cc+1] = _opp LOOP
          seen_opp := true;
          rr := rr + dr; cc := cc + dc;
        END LOOP;
        IF seen_opp AND rr BETWEEN 0 AND 7 AND cc BETWEEN 0 AND 7 AND _board[rr*8+cc+1] = _me THEN
          RETURN true;
        END IF;
      END LOOP;
    END LOOP;
  END LOOP;
  RETURN false;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.othello_has_move(smallint[], smallint, smallint) FROM PUBLIC, anon;

CREATE OR REPLACE FUNCTION public.othello_create_game()
RETURNS public.othello_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_code text;
  v_game public.othello_games;
  v_board smallint[] := array_fill(0::smallint, ARRAY[64]);
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  v_code := upper(substring(md5(random()::text || clock_timestamp()::text), 1, 5));

  -- standard Othello starting position (row 3-4, col 3-4, alternating diagonals)
  v_board[3*8+3+1] := 2; -- (3,3) white
  v_board[3*8+4+1] := 1; -- (3,4) black
  v_board[4*8+3+1] := 1; -- (4,3) black
  v_board[4*8+4+1] := 2; -- (4,4) white

  INSERT INTO public.othello_games (code, host_id, board, status, last_message)
  VALUES (v_code, auth.uid(), v_board, 'waiting', 'Waiting for opponent to join…')
  RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.othello_join_game(_code text)
RETURNS public.othello_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.othello_games;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO v_game FROM public.othello_games WHERE code = upper(_code);
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_game.host_id = auth.uid() THEN RETURN v_game; END IF;
  IF v_game.guest_id IS NOT NULL AND v_game.guest_id <> auth.uid() THEN
    RAISE EXCEPTION 'Room is full';
  END IF;

  UPDATE public.othello_games
    SET guest_id = auth.uid(),
        status = 'playing',
        last_message = 'Game on! Host (black) goes first.',
        updated_at = now()
    WHERE id = v_game.id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.othello_place(_game_id uuid, _cell smallint)
RETURNS public.othello_games
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_game public.othello_games;
  v_is_host boolean;
  v_me smallint; v_opp smallint;
  v_board smallint[];
  v_row int; v_col int;
  dirs int[][] := ARRAY[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
  d int; dr int; dc int; rr int; cc int;
  to_flip int[]; flipped_any boolean := false;
  fi int;
  v_status text := 'playing';
  v_winner uuid;
  v_msg text;
  v_host_count int; v_guest_count int;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  IF _cell < 0 OR _cell > 63 THEN RAISE EXCEPTION 'Invalid cell'; END IF;

  SELECT * INTO v_game FROM public.othello_games WHERE id = _game_id FOR UPDATE;
  IF v_game.id IS NULL THEN RAISE EXCEPTION 'Game not found'; END IF;
  IF v_game.status <> 'playing' THEN RAISE EXCEPTION 'Game not active'; END IF;

  IF auth.uid() = v_game.host_id THEN v_is_host := true; v_me := 1; v_opp := 2;
  ELSIF auth.uid() = v_game.guest_id THEN v_is_host := false; v_me := 2; v_opp := 1;
  ELSE RAISE EXCEPTION 'Not a player'; END IF;

  IF v_game.turn <> v_me THEN RAISE EXCEPTION 'Not your turn'; END IF;

  v_board := v_game.board;
  IF v_board[_cell+1] <> 0 THEN RAISE EXCEPTION 'Cell already taken'; END IF;

  v_row := _cell / 8; v_col := _cell % 8;

  FOR d IN 1..8 LOOP
    dr := dirs[d][1]; dc := dirs[d][2];
    rr := v_row + dr; cc := v_col + dc;
    to_flip := ARRAY[]::int[];
    WHILE rr BETWEEN 0 AND 7 AND cc BETWEEN 0 AND 7 AND v_board[rr*8+cc+1] = v_opp LOOP
      to_flip := to_flip || (rr*8+cc);
      rr := rr + dr; cc := cc + dc;
    END LOOP;
    IF array_length(to_flip, 1) > 0 AND rr BETWEEN 0 AND 7 AND cc BETWEEN 0 AND 7 AND v_board[rr*8+cc+1] = v_me THEN
      flipped_any := true;
      FOR fi IN 1..array_length(to_flip, 1) LOOP
        v_board[to_flip[fi]+1] := v_me;
      END LOOP;
    END IF;
  END LOOP;

  IF NOT flipped_any THEN RAISE EXCEPTION 'Illegal move — must bracket at least one opponent line'; END IF;

  v_board[_cell+1] := v_me;

  IF public.othello_has_move(v_board, v_opp, v_me) THEN
    v_msg := (CASE WHEN v_is_host THEN 'Guest' ELSE 'Host' END) || '''s turn.';
    -- turn flips to opponent below
  ELSIF public.othello_has_move(v_board, v_me, v_opp) THEN
    v_msg := 'No legal move for the other player — you go again.';
    v_opp := v_me; -- so the CASE below keeps the turn on v_me
  ELSE
    v_status := 'finished';
    v_host_count := 0; v_guest_count := 0;
    FOR d IN 1..64 LOOP
      IF v_board[d] = 1 THEN v_host_count := v_host_count + 1;
      ELSIF v_board[d] = 2 THEN v_guest_count := v_guest_count + 1; END IF;
    END LOOP;
    IF v_host_count > v_guest_count THEN
      v_winner := v_game.host_id;
      v_msg := 'No moves left — host wins ' || v_host_count || '-' || v_guest_count || '!';
    ELSIF v_guest_count > v_host_count THEN
      v_winner := v_game.guest_id;
      v_msg := 'No moves left — guest wins ' || v_guest_count || '-' || v_host_count || '!';
    ELSE
      v_msg := 'No moves left — it''s a tie ' || v_host_count || '-' || v_guest_count || '!';
    END IF;
  END IF;

  UPDATE public.othello_games
    SET board = v_board,
        turn = CASE WHEN v_status = 'playing' THEN v_opp ELSE turn END,
        status = v_status,
        winner_id = v_winner,
        last_message = v_msg,
        updated_at = now()
    WHERE id = _game_id
    RETURNING * INTO v_game;

  RETURN v_game;
END;
$$;

CREATE OR REPLACE FUNCTION public.othello_leave_game(_game_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  DELETE FROM public.othello_games WHERE id = _game_id AND host_id = auth.uid();
END;
$$;

GRANT EXECUTE ON FUNCTION public.othello_create_game() TO authenticated;
GRANT EXECUTE ON FUNCTION public.othello_join_game(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.othello_place(uuid, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.othello_leave_game(uuid) TO authenticated;
