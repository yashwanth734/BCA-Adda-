import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// Security headers applied to EVERY response this app returns, success or
// error path alike. This is the real enforcement point — the <meta
// http-equiv="Content-Security-Policy"> tag in __root.tsx still exists as
// a defense-in-depth fallback (some CDN/edge configurations occasionally
// strip custom headers from cached responses), but a meta tag alone can
// never set frame-ancestors, Strict-Transport-Security, or
// X-Content-Type-Options — those require real HTTP headers, which is
// exactly what this function provides.
//
// Directives below were chosen by inspecting what this app actually
// loads, not copied from a template:
//   - Google Fonts (fonts.googleapis.com stylesheet, fonts.gstatic.com
//     font files) — confirmed via __root.tsx's <link> tags
//   - Supabase REST + Realtime websocket (*.supabase.co, wss://*.supabase.co)
//   - No other third-party script/style/font origins found anywhere in src/
//
// 'unsafe-inline' remains on script-src and style-src: this is an SSR
// app (TanStack Start) whose hydration payload and Tailwind-driven inline
// style attributes rely on it. Removing it would require a nonce-based
// CSP wired through the SSR render pipeline itself — a larger change than
// this pass, and not verifiable without a live build. Documented here
// rather than silently dropped.
//
// img-src keeps 'data:' even though avatar_url/subject_notes.url are now
// DB-constrained to https-only: Tailwind can emit data-URI background
// images for certain form-control style resets, and removing this
// without a live build to verify would risk breaking UI silently.
function buildSecurityHeaders(request: Request): Headers {
  const headers = new Headers();

  const csp = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https:",
    "connect-src 'self' https://*.supabase.co wss://*.supabase.co",
    "object-src 'none'",
    "base-uri 'self'",
    "frame-ancestors 'none'", // only settable via a real header, not the meta tag
  ].join("; ");
  headers.set("Content-Security-Policy", csp);

  // legacy pair to frame-ancestors, for browsers that don't honor it
  headers.set("X-Frame-Options", "DENY");

  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");

  // Only disable APIs this app genuinely never uses — no video/voice
  // calls, no location features, no payments, no USB device access.
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()");

  // HSTS only on an actually-HTTPS request. Sending it over plain HTTP
  // would tell the browser to force HTTPS on every future visit even if
  // the deployment doesn't support HTTPS yet — a real way to break a
  // non-HTTPS deployment, which is exactly what was asked to be avoided.
  // max-age is a conservative 180 days with no includeSubDomains/preload
  // (both are hard to safely undo); raise it once HTTPS is confirmed
  // solid in production. See SECURITY.md.
  const proto = request.headers.get("x-forwarded-proto") ?? new URL(request.url).protocol.replace(":", "");
  if (proto === "https") {
    headers.set("Strict-Transport-Security", "max-age=15552000");
  }

  return headers;
}

function withSecurityHeaders(response: Response, request: Request): Response {
  const headers = new Headers(response.headers);
  for (const [key, value] of buildSecurityHeaders(request)) {
    headers.set(key, value);
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      const normalized = await normalizeCatastrophicSsrResponse(response);
      return withSecurityHeaders(normalized, request);
    } catch (error) {
      console.error(error);
      return withSecurityHeaders(
        new Response(renderErrorPage(), {
          status: 500,
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
        request,
      );
    }
  },
};
