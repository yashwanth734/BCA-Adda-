import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        // Avoid refetch storms on tab focus / remount that made the app feel slow.
        staleTime: 60_000,
        gcTime: 5 * 60_000,
        refetchOnWindowFocus: false,
        // Unlike refetchOnWindowFocus (which fires on every alt-tab), this
        // only fires when the browser genuinely lost and regained network
        // connectivity — exactly the "something was broken, now it's not,
        // go get fresh data" case this app should recover from
        // automatically instead of leaving stale/missed realtime updates
        // sitting there until the user manually refreshes.
        refetchOnReconnect: true,
        retry: 1,
      },
    },
  });


  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });

  return router;
};
