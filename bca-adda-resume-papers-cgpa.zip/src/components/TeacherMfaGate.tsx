import { useEffect, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ShieldCheck, Loader2, Check, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";

type Status = "checking" | "ok" | "needs_enroll" | "needs_challenge";

/**
 * Server-side RLS now requires an aal2 (MFA-verified) session for every
 * teacher-gated policy (see 20260823090000_require_mfa_for_teacher_actions.sql)
 * — that's the actual enforcement, and it holds regardless of this
 * component. This gate exists purely so a teacher who hasn't satisfied
 * that yet gets one clear, guided screen instead of running into a wall
 * of silent RLS-denied empty results scattered across different pages.
 *
 * Students are entirely unaffected — the underlying policies already
 * exclude them via the role check, and this component only activates
 * for accounts that hold the teacher role.
 */
export function TeacherMfaGate({ children }: { children: ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const { isTeacher, loading: roleLoading } = useRole();
  const [status, setStatus] = useState<Status>("checking");
  const [factorId, setFactorId] = useState<string | null>(null);

  const checkLevel = async () => {
    const { data, error } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
    if (error || !data) {
      // fail open on the client — the RLS layer is the real enforcement,
      // and blocking the whole app on an unrelated MFA-status-check
      // error would be a worse failure mode than a teacher occasionally
      // seeing an empty moderation queue until they retry.
      setStatus("ok");
      return;
    }
    if (data.currentLevel === "aal2") {
      setStatus("ok");
      return;
    }
    if (data.nextLevel === "aal2") {
      // a verified factor exists, just not satisfied this session
      const { data: factors } = await supabase.auth.mfa.listFactors();
      const verified = factors?.totp?.find((f) => f.status === "verified");
      setFactorId(verified?.id ?? null);
      setStatus(verified ? "needs_challenge" : "needs_enroll");
      return;
    }
    setStatus("needs_enroll");
  };

  useEffect(() => {
    if (authLoading || roleLoading) return;
    if (!user || !isTeacher) {
      setStatus("ok");
      return;
    }
    checkLevel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, roleLoading, user, isTeacher]);

  if (authLoading || roleLoading || !user || !isTeacher || status === "ok") {
    return <>{children}</>;
  }

  if (status === "checking") {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (status === "needs_enroll") {
    return (
      <div className="grid min-h-screen place-items-center px-5">
        <div className="paper max-w-md p-8 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-gold">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="mt-4 text-2xl">Two-factor authentication required</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Teacher accounts must have two-factor authentication enabled before accessing moderation,
            attendance, and other teacher tools. This protects the whole school's data — a compromised
            teacher password alone can no longer reach it.
          </p>
          <Link
            to="/settings/security"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
          >
            Set up two-factor authentication
          </Link>
          <p className="mt-4 text-xs text-muted-foreground">
            Come back here once it's set up — this check runs again automatically.
          </p>
        </div>
      </div>
    );
  }

  // needs_challenge: a factor exists, just needs this session verified
  return <MfaChallenge factorId={factorId!} onVerified={() => setStatus("ok")} />;
}

function MfaChallenge({ factorId, onVerified }: { factorId: string; onVerified: () => void }) {
  const { signOut } = useAuth();
  const [code, setCode] = useState("");
  const [verifying, setVerifying] = useState(false);

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifying(true);
    try {
      const { data: challenge, error: challengeError } = await supabase.auth.mfa.challenge({ factorId });
      if (challengeError) throw challengeError;
      const { error: verifyError } = await supabase.auth.mfa.verify({
        factorId,
        challengeId: challenge.id,
        code: code.trim(),
      });
      if (verifyError) throw verifyError;
      onVerified();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "That code didn't work");
      setCode("");
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center px-5">
      <div className="paper max-w-md p-8 text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-mint">
          <ShieldCheck className="h-6 w-6" />
        </div>
        <h1 className="mt-4 text-2xl">Confirm it's you</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Enter the code from your authenticator app to unlock teacher tools for this session.
        </p>
        <form onSubmit={verify} className="mt-6 flex gap-2">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            placeholder="6-digit code"
            inputMode="numeric"
            maxLength={6}
            autoFocus
            className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 text-center font-mono text-lg tracking-widest outline-none focus:border-ink"
          />
          <button
            disabled={verifying || code.length < 6}
            className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-coral px-4 font-semibold text-primary-foreground disabled:opacity-60"
          >
            {verifying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
          </button>
        </form>
        <button
          onClick={() => signOut()}
          className="mt-5 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Sign out instead
        </button>
      </div>
    </div>
  );
}
