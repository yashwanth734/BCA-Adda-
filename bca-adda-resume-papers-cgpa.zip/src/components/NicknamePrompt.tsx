import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Sparkles } from "lucide-react";
import type { User } from "@supabase/supabase-js";

type Profile = {
  id: string;
  username: string;
  full_name: string | null;
  semester: number | null;
};

export function NicknamePrompt({ user }: { user: User }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [open, setOpen] = useState(false);
  const [nickname, setNickname] = useState("");
  const [semester, setSemester] = useState<string>("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, username, full_name, semester")
        .eq("id", user.id)
        .maybeSingle();
      if (cancelled) return;
      if (data) {
        setProfile(data as Profile);
        if (!data.full_name) {
          setNickname(
            (user.user_metadata?.full_name as string | undefined) ??
              (user.user_metadata?.name as string | undefined) ??
              "",
          );
          setOpen(true);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user.id, user.user_metadata]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = nickname.trim();
    if (trimmed.length < 2) {
      toast.error("Nickname must be at least 2 characters");
      return;
    }
    setSaving(true);
    const sem = parseInt(semester, 10);
    const updates: { full_name: string; semester?: number } = { full_name: trimmed };
    if (!Number.isNaN(sem) && sem >= 1 && sem <= 8) updates.semester = sem;

    const { error } = await supabase.from("profiles").update(updates).eq("id", user.id);

    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (profile)
      setProfile({
        ...profile,
        full_name: trimmed,
        semester: updates.semester ?? profile.semester,
      });
    toast.success("Nice to meet you, " + trimmed.split(" ")[0] + "!");
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ink/40 p-4 backdrop-blur-sm">
      <div className="paper w-full max-w-md p-6">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-accent">
          <Sparkles className="h-6 w-6" />
        </div>
        <h2 className="mt-4 text-2xl">Pick a nickname</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          This is the name your classmates will see in chat. You can change it later.
        </p>

        <form onSubmit={save} className="mt-5 space-y-4">
          <div>
            <label className="text-sm font-medium">Nickname</label>
            <input
              autoFocus
              required
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              maxLength={40}
              placeholder="e.g. Riya, codeBabu, dev_dude"
              className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Semester (optional)</label>
            <select
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
              className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
            >
              <option value="">Prefer not to say</option>
              {[1, 2, 3, 4, 5, 6].map((s) => (
                <option key={s} value={s}>Semester {s}</option>
              ))}
            </select>
          </div>
          <button
            disabled={saving}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-6 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            Continue to chat
          </button>
        </form>
      </div>
    </div>
  );
}
