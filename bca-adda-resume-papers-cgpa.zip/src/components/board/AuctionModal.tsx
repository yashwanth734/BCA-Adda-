import { useEffect, useState } from "react";
import { Gavel } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { money, tileAt } from "@/lib/board/client";
import type { GameAction, GameState } from "@/lib/board/types";

export function AuctionModal({
  state,
  userId,
  act,
  busy,
}: {
  state: GameState;
  userId: string;
  act: (a: GameAction) => void;
  busy: boolean;
}) {
  const a = state.auction;
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    if (!a) return;
    setAmount(String(a.highest + 10));
    setFlash(true);
    const t = setTimeout(() => setFlash(false), 400);
    return () => clearTimeout(t);
  }, [a?.highest, a?.tile]);

  if (state.phase !== "auction" || !a) return null;
  const tile = tileAt(a.tile);
  const me = state.players.find((p) => p.id === userId);
  const bidder = state.players[a.turnIndex];
  const myTurn = bidder?.id === userId;
  const leader = state.players.find((p) => p.id === a.highestBidder);

  const submit = () => {
    const n = Math.floor(Number(amount));
    if (!Number.isFinite(n) || n <= a.highest) return setError(`Bid must beat ${money(a.highest)}.`);
    if (me && n > me.cash) return setError("You cannot bid more than your cash.");
    setError(null);
    act({ type: "bid", amount: n });
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ink/70 p-4">
      <div className="w-full max-w-md animate-scale-in rounded-2xl border-2 border-ink bg-background p-5 shadow-soft">
        <div className="flex items-center gap-2">
          <Gavel className="h-5 w-5 text-coral" />
          <h2 className="font-display text-xl">Auction — {tile.name}</h2>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          List price {money(tile.price ?? 0)} · nobody bought it, so the table bids.
        </p>

        <div
          className={`mt-4 rounded-xl border border-border p-4 text-center transition-colors ${
            flash ? "bg-mint/40" : "bg-muted/40"
          }`}
        >
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Highest bid</p>
          <p className="font-display text-3xl">{money(a.highest)}</p>
          <p className="text-sm">{leader ? `by ${leader.name}` : "no bids yet"}</p>
        </div>

        <p className="mt-3 text-center text-sm font-semibold">
          {myTurn ? "Your move" : `Waiting for ${bidder?.name ?? "…"}`}
        </p>

        {myTurn ? (
          <div className="mt-3 space-y-2">
            <div className="flex gap-2">
              <Input
                type="number"
                value={amount}
                min={a.highest + 1}
                onChange={(e) => setAmount(e.target.value)}
                disabled={busy}
              />
              <Button onClick={submit} disabled={busy}>
                Bid
              </Button>
            </div>
            <div className="flex gap-2">
              {[10, 50, 100].map((step) => (
                <Button
                  key={step}
                  size="sm"
                  variant="outline"
                  onClick={() => setAmount(String(a.highest + step))}
                >
                  +{step}
                </Button>
              ))}
              <Button
                size="sm"
                variant="ghost"
                className="ml-auto"
                disabled={busy}
                onClick={() => act({ type: "passBid" })}
              >
                Pass
              </Button>
            </div>
            {error ? <p className="text-xs text-destructive">{error}</p> : null}
            <p className="text-xs text-muted-foreground">Your cash: {money(me?.cash ?? 0)}</p>
          </div>
        ) : null}
      </div>
    </div>
  );
}
