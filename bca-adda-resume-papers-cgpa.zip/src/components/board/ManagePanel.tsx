import { Building2, HandCoins, KeyRound, Landmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { money, mortgageValue, tileAt, unmortgageCost } from "@/lib/board/client";
import { GROUPS, groupTiles, JAIL_FINE } from "@/lib/board/tiles";
import type { GameAction, GameState } from "@/lib/board/types";

/** Property management: build / sell / mortgage, plus jail actions. */
export function ManagePanel({
  state,
  userId,
  act,
  busy,
  selected,
}: {
  state: GameState;
  userId: string;
  act: (a: GameAction) => void;
  busy: boolean;
  selected: number | null;
}) {
  const me = state.players.find((p) => p.id === userId);
  if (!me) return null;

  const mine = Object.entries(state.holdings)
    .filter(([, h]) => h.owner === userId)
    .map(([k, h]) => ({ tile: tileAt(Number(k)), h }))
    .sort((a, b) => a.tile.index - b.tile.index);

  const ownsGroup = (g: keyof typeof GROUPS) =>
    groupTiles(g).every((t) => state.holdings[String(t)]?.owner === userId);

  return (
    <div className="space-y-3">
      {me.jail ? (
        <div className="rounded-xl border-2 border-ink bg-amber-100/60 p-3 dark:bg-muted">
          <p className="flex items-center gap-2 text-sm font-bold">
            <KeyRound className="h-4 w-4" /> You are in the Holding Bay
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Attempt {Math.min(me.jailTurns + 1, 3)} of 3 — roll doubles, pay the fine, or use a
            pardon pass.
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            <Button
              size="sm"
              disabled={busy || me.cash < JAIL_FINE}
              onClick={() => act({ type: "payJail" })}
            >
              Pay {money(JAIL_FINE)}
            </Button>
            <Button
              size="sm"
              variant="outline"
              disabled={busy || me.jailPass <= 0}
              onClick={() => act({ type: "useJailPass" })}
            >
              Use pardon pass ({me.jailPass})
            </Button>
          </div>
        </div>
      ) : null}

      <div className="paper rounded-2xl p-3">
        <p className="flex items-center gap-2 text-sm font-bold">
          <Landmark className="h-4 w-4" /> Your estates ({mine.length})
        </p>
        {mine.length === 0 ? (
          <p className="mt-2 text-xs text-muted-foreground">Buy something to get started.</p>
        ) : (
          <ul className="mt-2 space-y-2">
            {mine.map(({ tile, h }) => {
              const isEstate = tile.kind === "estate";
              const full = isEstate && tile.group ? ownsGroup(tile.group) : false;
              const canBuild =
                full && !h.mortgaged && h.houses < 5 && me.cash >= (tile.buildCost ?? 0);
              return (
                <li
                  key={tile.index}
                  className={`rounded-lg border p-2 ${
                    selected === tile.index ? "border-coral" : "border-border"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold">{tile.name}</span>
                    <span className="text-[11px] text-muted-foreground">
                      {h.mortgaged
                        ? "mortgaged"
                        : h.houses >= 5
                          ? "tower"
                          : h.houses
                            ? `${h.houses} house${h.houses > 1 ? "s" : ""}`
                            : full
                              ? "full set"
                              : "—"}
                    </span>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {isEstate ? (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2 text-xs"
                          disabled={busy || !canBuild}
                          onClick={() => act({ type: "build", tile: tile.index })}
                        >
                          <Building2 className="mr-1 h-3 w-3" />
                          Build {money(tile.buildCost ?? 0)}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2 text-xs"
                          disabled={busy || h.houses === 0}
                          onClick={() => act({ type: "sellHouse", tile: tile.index })}
                        >
                          Sell house
                        </Button>
                      </>
                    ) : null}
                    {h.mortgaged ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 px-2 text-xs"
                        disabled={busy || me.cash < unmortgageCost(tile)}
                        onClick={() => act({ type: "unmortgage", tile: tile.index })}
                      >
                        <HandCoins className="mr-1 h-3 w-3" />
                        Unmortgage {money(unmortgageCost(tile))}
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 px-2 text-xs"
                        disabled={busy || h.houses > 0}
                        onClick={() => act({ type: "mortgage", tile: tile.index })}
                      >
                        <HandCoins className="mr-1 h-3 w-3" />
                        Mortgage {money(mortgageValue(tile))}
                      </Button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
