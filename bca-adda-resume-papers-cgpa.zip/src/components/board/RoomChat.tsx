import { useEffect, useRef, useState } from "react";
import { MessageCircle, Send, X, Flag } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ReportDialog, type ReportTarget } from "@/components/ReportDialog";

type DbMsg = {
  id: string;
  room_id: string;
  user_id: string;
  display_name: string;
  content: string;
  removed_at: string | null;
  created_at: string;
};

type ChatMsg = {
  id: string;
  from: string;
  name: string;
  color: string;
  text: string;
  ts: number;
  reactions: Record<string, string[]>;
  removed: boolean;
};

function colorFor(userId: string) {
  const colors = ["#e56b3f", "#7c5cbf", "#d4a017", "#3a8c7c", "#c0392b", "#2980b9"];
  let h = 0;
  for (let i = 0; i < userId.length; i++) h = (h * 31 + userId.charCodeAt(i)) >>> 0;
  return colors[h % colors.length];
}

/** Persistent in-room chat backed by room_chat_messages, still realtime via supabase. */
export function RoomChat({
  roomId,
  userId,
  name,
  color,
  variant = "floating",
}: {
  roomId: string;
  userId: string;
  name: string;
  color: string;
  variant?: "floating" | "inline";
}) {
  const [open, setOpen] = useState(variant === "inline");
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [text, setText] = useState("");
  const [unread, setUnread] = useState(0);
  const [reportTarget, setReportTarget] = useState<ReportTarget | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);
  const openRef = useRef(open);
  openRef.current = open;

  // load the most recent 50 messages on mount. Fetch newest-first, then
  // reverse for display — fetching ascending with a flat limit would
  // return the OLDEST 50 in the room instead once a room's chat passes
  // that count, which is the same bug this file's sibling (chat.tsx) had.
  useEffect(() => {
    if (!roomId) return;
    supabase
      .from("room_chat_messages")
      .select("id,room_id,user_id,display_name,content,removed_at,created_at")
      .eq("room_id", roomId)
      .order("created_at", { ascending: false })
      .limit(50)
      .then(({ data }) => {
        if (!data) return;
        setMsgs(
          [...data].reverse().map((m: DbMsg) => ({
            id: m.id,
            from: m.user_id,
            name: m.display_name,
            color: colorFor(m.user_id),
            text: m.content,
            ts: new Date(m.created_at).getTime(),
            reactions: {},
            removed: !!m.removed_at,
          })),
        );
      });
  }, [roomId]);

  // realtime subscription for new messages and moderation soft-deletes
  useEffect(() => {
    const ch = supabase
      .channel(`room_chat_messages:${roomId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "room_chat_messages",
          filter: `room_id=eq.${roomId}`,
        },
        ({ new: m }) => {
          const msg = m as DbMsg;
          if (msg.user_id === userId) return; // we already added it optimistically
          const chatMsg: ChatMsg = {
            id: msg.id,
            from: msg.user_id,
            name: msg.display_name,
            color: colorFor(msg.user_id),
            text: msg.content,
            ts: new Date(msg.created_at).getTime(),
            reactions: {},
            removed: false,
          };
          setMsgs((prev) => [...prev.slice(-99), chatMsg]);
          if (!openRef.current) setUnread((u) => u + 1);
        },
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "room_chat_messages",
          filter: `room_id=eq.${roomId}`,
        },
        ({ new: m }) => {
          const msg = m as DbMsg;
          if (msg.removed_at) {
            setMsgs((prev) =>
              prev.map((cm) => (cm.id === msg.id ? { ...cm, removed: true, text: "[removed]" } : cm)),
            );
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [roomId, userId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, open]);

  const send = async () => {
    const body = text.trim().slice(0, 200);
    if (!body) return;
    setText("");

    // optimistic
    const optimistic: ChatMsg = {
      id: `opt-${Date.now()}`,
      from: userId,
      name,
      color,
      text: body,
      ts: Date.now(),
      reactions: {},
      removed: false,
    };
    setMsgs((prev) => [...prev.slice(-99), optimistic]);

    const { error } = await supabase
      .from("room_chat_messages")
      .insert({ room_id: roomId, user_id: userId, display_name: name, content: body });
    if (error) {
      setMsgs((prev) => prev.filter((m) => m.id !== optimistic.id));
    }
  };

  const handleKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") send();
  };

  if (variant === "floating") {
    return (
      <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end gap-2">
        {open && (
          <div className="flex h-72 w-72 flex-col overflow-hidden rounded-2xl border-2 border-ink bg-card shadow-pop">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <span className="font-display text-sm font-bold">Room chat</span>
              <button onClick={() => setOpen(false)}>
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-2 text-sm">
              {msgs.map((m) => (
                <div key={m.id} className="mb-1">
                  <span className="font-semibold" style={{ color: m.color }}>{m.name}: </span>
                  <span className={m.removed ? "italic text-muted-foreground" : ""}>{m.text}</span>
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <div className="flex gap-1 border-t border-border p-2">
              <Input
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={handleKey}
                placeholder="Say something…"
                maxLength={200}
                className="h-7 text-xs"
              />
              <Button size="icon" className="h-7 w-7 shrink-0" onClick={send}>
                <Send className="h-3 w-3" />
              </Button>
            </div>
          </div>
        )}
        <button
          onClick={() => { setOpen((v) => !v); setUnread(0); }}
          className="relative grid h-10 w-10 place-items-center rounded-full bg-ink text-cream shadow-pop"
        >
          <MessageCircle className="h-5 w-5" />
          {unread > 0 && (
            <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full bg-coral text-[10px] font-bold text-white">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </button>
      </div>
    );
  }

  // inline variant
  return (
    <div className="flex h-full flex-col overflow-hidden rounded-2xl border-2 border-ink bg-card">
      {reportTarget && (
        <ReportDialog
          target={reportTarget}
          reporterId={userId}
          onClose={() => setReportTarget(null)}
        />
      )}
      <div className="border-b border-border px-3 py-2 font-display text-sm font-bold">Room chat</div>
      <div className="flex-1 overflow-y-auto p-2 text-sm">
        {msgs.map((m) => (
          <div key={m.id} className="group mb-1 flex items-start gap-1">
            <div className="flex-1">
              <span className="font-semibold" style={{ color: m.color }}>{m.name}: </span>
              <span className={m.removed ? "italic text-muted-foreground" : ""}>{m.text}</span>
            </div>
            {!m.removed && m.from !== userId && (
              <button
                onClick={() => setReportTarget({ type: "message", messageId: m.id, snapshot: m.text, authorLabel: m.name, reportedUserId: m.from })}
                className="mt-0.5 shrink-0 rounded p-0.5 text-muted-foreground opacity-0 hover:text-coral group-hover:opacity-100"
                aria-label="Report"
              >
                <Flag className="h-3 w-3" />
              </button>
            )}
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div className="flex gap-1 border-t border-border p-2">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Say something…"
          maxLength={200}
          className="h-7 text-xs"
        />
        <Button size="icon" className="h-7 w-7 shrink-0" onClick={send}>
          <Send className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
