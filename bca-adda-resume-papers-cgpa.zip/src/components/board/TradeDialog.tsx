import { useMemo, useState } from "react";
import { ArrowLeftRight, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { money, tileAt } from "@/lib/board/client";
import type { GameAction, GameState } from "@/lib/board/types";
import { cn } from "@/lib/utils";

function TilePicker({
  tiles,
  chosen,
  toggle,
  empty,
}: {
  tiles: number[];
  chosen: number[];
  toggle: (t: number) => void;
  empty: string;
}) {
  if (tiles.length === 0) return <p className="text-xs text-muted-foreground">{empty}</p>;
  return (
    <div className="flex flex-wrap gap-1">
      {tiles.map((t) => (
        <button
          key={t}
          type="button"
          onClick={() => toggle(t)}
          className={cn(
            "rounded-md border border-border px-2 py-1 text-xs",
            chosen.includes(t) && "border-coral bg-coral/10 font-semibold",
          )}
        >
          {tileAt(t).name}
        </button>
      ))}
    </div>
  );
}

export function TradeDialog({
  state,
  userId,
  act,
  busy,
}: {
  state: GameState;
  userId: string;
  act: (a: GameAction) => void;
  busy: boolean;
}) {
  const me = state.players.find((p) => p.id === userId);
  const rivals = state.players.filter((p) => p.id !== userId && !p.bankrupt);
  const [open, setOpen] = useState(false);
  const [to, setTo] = useState(rivals[0]?.id ?? "");
  const [giveCash, setGiveCash] = useState("0");
  const [getCash, setGetCash] = useState("0");
  const [giveTiles, setGiveTiles] = useState<number[]>([]);
  const [getTiles, setGetTiles] = useState<number[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  const owned = useMemo(
    () => (id: string) =>
      Object.entries(state.holdings)
        .filter(([, h]) => h.owner === id && h.houses === 0)
        .map(([k]) => Number(k))
        .sort((a, b) => a - b),
    [state.holdings],
  );

  const target = state.players.find((p) => p.id === to);
  const gc = Math.max(0, Math.floor(Number(giveCash) || 0));
  const rc = Math.max(0, Math.floor(Number(getCash) || 0));

  const submit = () => {
    if (!target) return setError("Pick an opponent.");
    if (gc > (me?.cash ?? 0)) return setError("You do not have that much cash.");
    if (rc > target.cash) return setError("They do not have that much cash.");
    if (!gc && !rc && !giveTiles.length && !getTiles.length)
      return setError("Add something to the offer.");
    setError(null);
    act({
      type: "proposeTrade",
      offer: { to: target.id, giveCash: gc, getCash: rc, giveTiles, getTiles },
    });
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setOpen(false);
      setGiveTiles([]);
      setGetTiles([]);
      setGiveCash("0");
      setGetCash("0");
    }, 900);
  };

  const incoming = state.trades.filter((t) => t.status === "pending" && t.to === userId);

  return (
    <>
      {incoming.map((t) => {
        const from = state.players.find((p) => p.id === t.from);
        return (
          <div key={t.id} className="rounded-xl border-2 border-coral bg-coral/5 p-3 text-sm">
            <p className="font-bold">Trade offer from {from?.name}</p>
            <p className="mt-1 text-xs">
              They give: {money(t.giveCash)}
              {t.giveTiles.length ? ` + ${t.giveTiles.map((x) => tileAt(x).name).join(", ")}` : ""}
            </p>
            <p className="text-xs">
              They want: {money(t.getCash)}
              {t.getTiles.length ? ` + ${t.getTiles.map((x) => tileAt(x).name).join(", ")}` : ""}
            </p>
            <div className="mt-2 flex gap-2">
              <Button
                size="sm"
                disabled={busy}
                onClick={() => act({ type: "respondTrade", id: t.id, accept: true })}
              >
                <Check className="mr-1 h-3.5 w-3.5" /> Accept
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={busy}
                onClick={() => act({ type: "respondTrade", id: t.id, accept: false })}
              >
                <X className="mr-1 h-3.5 w-3.5" /> Decline
              </Button>
            </div>
          </div>
        );
      })}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" disabled={rivals.length === 0}>
            <ArrowLeftRight className="mr-1 h-4 w-4" /> Trade
          </Button>
        </DialogTrigger>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Propose a trade</DialogTitle>
            <DialogDescription>
              Estates with houses cannot be traded — sell buildings first.
            </DialogDescription>
          </DialogHeader>

          {sent ? (
            <div className="grid place-items-center py-10 text-center animate-scale-in">
              <div className="grid h-14 w-14 place-items-center rounded-full bg-mint">
                <Check className="h-7 w-7 text-ink" />
              </div>
              <p className="mt-3 font-semibold">Offer sent to {target?.name}</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {rivals.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setTo(r.id);
                      setGetTiles([]);
                    }}
                    className={cn(
                      "rounded-full border border-border px-3 py-1 text-sm",
                      to === r.id && "border-ink bg-ink text-cream",
                    )}
                  >
                    {r.name}
                  </button>
                ))}
              </div>

              <div className="rounded-xl border border-border p-3">
                <p className="text-sm font-bold">You give</p>
                <Input
                  type="number"
                  min={0}
                  value={giveCash}
                  onChange={(e) => setGiveCash(e.target.value)}
                  className="my-2 h-9"
                />
                <TilePicker
                  tiles={owned(userId)}
                  chosen={giveTiles}
                  empty="No tradable estates."
                  toggle={(t) =>
                    setGiveTiles((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]))
                  }
                />
              </div>

              <div className="rounded-xl border border-border p-3">
                <p className="text-sm font-bold">You get</p>
                <Input
                  type="number"
                  min={0}
                  value={getCash}
                  onChange={(e) => setGetCash(e.target.value)}
                  className="my-2 h-9"
                />
                <TilePicker
                  tiles={target ? owned(target.id) : []}
                  chosen={getTiles}
                  empty="They have nothing tradable."
                  toggle={(t) =>
                    setGetTiles((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]))
                  }
                />
              </div>

              {error ? <p className="text-xs text-destructive">{error}</p> : null}
              <Button className="w-full" onClick={submit} disabled={busy}>
                Send offer
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
