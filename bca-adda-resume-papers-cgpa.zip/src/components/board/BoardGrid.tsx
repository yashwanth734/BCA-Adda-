import { cellFor, groupColor, money, tileAt, tilePercent } from "@/lib/board/client";
import { TILES } from "@/lib/board/tiles";
import type { GameState } from "@/lib/board/types";
import { cn } from "@/lib/utils";

const KIND_ICON: Record<string, string> = {
  start: "🚀",
  reward: "🎁",
  event: "✨",
  tax: "🧾",
  transit: "🚈",
  utility: "⚡",
  jail: "🔒",
  gotojail: "🚨",
  parking: "🌴",
};

function Buildings({ houses }: { houses: number }) {
  if (!houses) return null;
  if (houses >= 5) return <span className="text-[9px] leading-none">🏨</span>;
  return (
    <span className="text-[8px] leading-none tracking-tighter">{"🏠".repeat(houses)}</span>
  );
}

export function BoardGrid({
  state,
  selected,
  onSelect,
}: {
  state: GameState;
  selected: number | null;
  onSelect: (tile: number) => void;
}) {
  const live = state.players.filter((p) => !p.bankrupt);

  return (
    <div className="relative aspect-square w-full select-none rounded-2xl border-2 border-ink bg-cream p-1 shadow-soft">
      <div className="grid h-full w-full grid-cols-11 grid-rows-11 gap-[2px]">
        {TILES.map((t) => {
          const c = cellFor(t.index);
          const h = state.holdings[String(t.index)];
          const owner = h ? state.players.find((p) => p.id === h.owner) : null;
          return (
            <button
              key={t.index}
              type="button"
              onClick={() => onSelect(t.index)}
              style={{ gridRow: c.row, gridColumn: c.col }}
              className={cn(
                "relative flex min-h-0 min-w-0 flex-col items-center justify-center overflow-hidden rounded-[4px] border border-ink/15 bg-background p-[1px] text-center transition-transform hover:scale-[1.06] hover:z-10",
                selected === t.index && "ring-2 ring-coral",
                h?.mortgaged && "opacity-60",
              )}
              title={`${t.name}${t.price ? ` · ${money(t.price)}` : ""}`}
            >
              {t.group ? (
                <span
                  className="absolute inset-x-0 top-0 h-[18%]"
                  style={{ background: groupColor(t) }}
                />
              ) : null}
              {owner ? (
                <span
                  className="absolute inset-x-0 bottom-0 h-[14%]"
                  style={{ background: owner.color }}
                />
              ) : null}
              <span className="mt-[10%] text-[7px] font-semibold leading-[1.05] sm:text-[9px]">
                {t.kind === "estate" ? t.name : `${KIND_ICON[t.kind] ?? ""}`}
              </span>
              {t.kind !== "estate" ? (
                <span className="text-[6px] leading-tight text-muted-foreground sm:text-[7px]">
                  {t.name}
                </span>
              ) : null}
              <Buildings houses={h?.houses ?? 0} />
              {h?.mortgaged ? (
                <span className="text-[6px] font-bold text-destructive">MTG</span>
              ) : null}
            </button>
          );
        })}

        {/* centre */}
        <div
          style={{ gridRow: "2 / span 9", gridColumn: "2 / span 9" }}
          className="flex min-h-0 min-w-0 flex-col items-center justify-center overflow-hidden rounded-xl bg-ink p-4 text-cream"
        >
          <p className="font-display text-2xl sm:text-4xl">Trade City</p>
          <p className="mt-1 text-[10px] uppercase tracking-[0.3em] opacity-70">
            round {state.round}
          </p>
          <div className="mt-3 flex gap-2">
            {(state.dice ?? [null, null]).map((d, i) => (
              <div
                key={i}
                className="grid h-10 w-10 place-items-center rounded-lg bg-cream font-display text-xl text-ink shadow-pop sm:h-12 sm:w-12 sm:text-2xl"
              >
                {d ?? "–"}
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs opacity-80">Free parking pot: {money(state.pot)}</p>
          <p className="mt-1 max-w-[16rem] text-center text-[11px] opacity-70">
            {state.log[state.log.length - 1]?.text ?? "Roll to begin."}
          </p>
        </div>
      </div>

      {/* player tokens */}
      {live.map((p, idx) => {
        const pos = tilePercent(p.pos);
        const offset = idx % 4;
        return (
          <div
            key={p.id}
            className="pointer-events-none absolute z-20 grid h-[3.2%] min-h-3 w-[3.2%] min-w-3 place-items-center rounded-full border-2 border-cream text-[7px] font-bold text-cream shadow-md transition-all duration-500 ease-out"
            style={{
              background: p.color,
              left: `calc(${pos.left}% + ${(offset % 2 ? 1 : -1) * 5}px)`,
              top: `calc(${pos.top}% + ${(offset > 1 ? 1 : -1) * 5}px)`,
              transform: "translate(-50%, -50%)",
            }}
            title={`${p.name} · ${tileAt(p.pos).name}`}
          >
            {p.jail ? "!" : ""}
          </div>
        );
      })}
    </div>
  );
}
