import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { WifiOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

/**
 * Silent auto-recovery for the two "the app looks broken but isn't
 * actually crashed" problems that don't throw a React error and so never
 * reach the error boundary:
 *
 *   1. The browser's network connection drops and comes back (laptop
 *      sleep, wifi blip, switching networks). Chat/game/notification
 *      realtime subscriptions can silently miss updates during the
 *      outage, and React Query's cache goes stale with no visible sign
 *      anything is wrong.
 *   2. Supabase's realtime websocket itself disconnects (it auto-
 *      reconnects at the transport level, but the app's own data can
 *      still be stale for whatever happened during the gap).
 *
 * Detection -> automatic fix: on regaining connectivity, invalidate every
 * React Query cache entry so every visible screen refetches current data,
 * and surface a brief, honest "back online" toast rather than silently
 * changing data underneath the user with no explanation at all.
 *
 * This does not try to fix everything — a genuinely broken query (bad
 * RLS, a real bug) will just fail again on refetch, and React Query's
 * own error state / the route error boundary handles that. This only
 * targets "the network was the problem, and now it isn't."
 */
export function ConnectionWatchdog() {
  const queryClient = useQueryClient();
  const [offline, setOffline] = useState(false);
  const wasOffline = useRef(false);

  useEffect(() => {
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      setOffline(true);
      wasOffline.current = true;
    }

    const handleOffline = () => {
      setOffline(true);
      wasOffline.current = true;
    };

    const handleOnline = () => {
      setOffline(false);
      if (wasOffline.current) {
        wasOffline.current = false;
        toast.success("Back online — refreshing…", { duration: 2500 });
        queryClient.invalidateQueries();
      }
    };

    window.addEventListener("offline", handleOffline);
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("online", handleOnline);
    };
  }, [queryClient]);

  // Supabase's realtime client exposes connection state via the
  // underlying socket. If it closes unexpectedly (not from us calling
  // removeChannel), treat it the same way as a network drop once it
  // reconnects — refresh data rather than leave it stale.
  useEffect(() => {
    const socket = supabase.realtime;
    let sawDisconnect = false;

    // supabase-js v2's RealtimeClient exposes onOpen/onClose/onError as
    // registration functions on the underlying Phoenix socket wrapper.
    // Not exercised against a live connection from this environment —
    // if these hooks don't fire as expected on your Supabase client
    // version, the network online/offline handling above still covers
    // the most common real-world case (wifi drop) independently.
    try {
      socket.onClose(() => {
        sawDisconnect = true;
      });
      socket.onOpen(() => {
        if (sawDisconnect) {
          sawDisconnect = false;
          queryClient.invalidateQueries();
        }
      });
    } catch {
      // if this Supabase client version doesn't expose these hooks the
      // same way, fail quietly — the network listeners above are the
      // primary recovery mechanism and don't depend on this.
    }
  }, [queryClient]);

  if (!offline) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 flex items-center justify-center gap-2 bg-ink px-4 py-2 text-sm font-semibold text-cream">
      <WifiOff className="h-4 w-4" />
      You're offline — some things may not update until you're back online.
      <Loader2 className="h-3.5 w-3.5 animate-spin opacity-70" />
    </div>
  );
}
