import { useEffect, useState } from "react";
import { Loader2, Users } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";

type Props = {
  gameType:
    | "connect_four"
    | "tic_tac_toe"
    | "othello"
    | "dots_and_boxes"
    | "checkers"
    | "battleship";
  gameLabel: string; // e.g. "Connect Four"
  // fired when the backend matched us and a match_found notification lands
  onMatchFound: (code: string) => void;
};

export function MatchmakingButton({ gameType, gameLabel, onMatchFound }: Props) {
  const { user } = useAuth();
  const [inQueue, setInQueue] = useState(false);
  const [busy, setBusy] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const qc = useQueryClient();

  // watch for a match_found notification — that's how we know the trigger fired
  useEffect(() => {
    if (!user || !inQueue) return;
    const ch = supabase
      .channel(`matchmaking:${user.id}:${gameType}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const n = payload.new as { type: string; body: string | null };
          if (n.type === "match_found" && n.body) {
            const codeMatch = n.body.match(/room ([A-Z]{5})/);
            if (codeMatch) {
              setInQueue(false);
              qc.invalidateQueries({ queryKey: ["notifications", user.id] });
              onMatchFound(codeMatch[1]);
            }
          }
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user, inQueue, gameType, onMatchFound, qc]);

  // elapsed timer while in queue
  useEffect(() => {
    if (!inQueue) { setElapsed(0); return; }
    const id = setInterval(() => setElapsed((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [inQueue]);

  if (!user) return null;

  const join = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("matchmaking_queue")
      .insert({ user_id: user.id, game_type: gameType });
    setBusy(false);
    if (error) return toast.error(error.message);
    setInQueue(true);
    toast.success(`Looking for a ${gameLabel} opponent…`);
  };

  const leave = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("matchmaking_queue")
      .delete()
      .eq("user_id", user.id)
      .eq("game_type", gameType);
    setBusy(false);
    if (error) return toast.error(error.message);
    setInQueue(false);
    toast("Left the queue");
  };

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  if (inQueue) {
    return (
      <div className="flex items-center gap-3 rounded-2xl border-2 border-ink bg-secondary px-4 py-3">
        <Loader2 className="h-4 w-4 animate-spin shrink-0" />
        <span className="flex-1 text-sm font-semibold">
          Finding an opponent… {fmt(elapsed)}
        </span>
        <button
          onClick={leave}
          disabled={busy}
          className="text-xs font-semibold text-muted-foreground hover:text-coral disabled:opacity-60"
        >
          Cancel
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={join}
      disabled={busy}
      className="inline-flex w-full items-center justify-center gap-2 rounded-full border-2 border-ink bg-cream px-5 py-3 font-semibold shadow-pop hover:-translate-y-0.5 transition-transform disabled:opacity-60"
    >
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Users className="h-4 w-4" />}
      Quick match — find a random opponent
    </button>
  );
}
