import { useState } from "react";
import { Eye, Loader2 } from "lucide-react";
import { useSpectate } from "@/lib/useSpectate";

type Props = {
  table: string;
  label: string; // e.g. "a Connect Four"
  // Called once a valid playing game is found. The parent renders it.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onJoin: (game: any) => void;
};

export function SpectateEntry({ table, label, onJoin }: Props) {
  const [code, setCode] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const { game, loading, error } = useSpectate({
    table,
    code,
    enabled: submitted && code.length >= 4,
  });

  // Forward the game to the parent as soon as it loads.
  if (game && submitted) {
    onJoin(game);
    return null;
  }

  return (
    <div className="paper p-6">
      <h3 className="flex items-center gap-2 text-xl">
        <Eye className="h-5 w-5 text-muted-foreground" /> Watch {label} game
      </h3>
      <p className="mt-1 text-sm text-muted-foreground">Enter a room code to spectate — read only.</p>
      <div className="mt-5 flex gap-2">
        <input
          value={code}
          onChange={(e) => { setCode(e.target.value.toUpperCase()); setSubmitted(false); }}
          maxLength={5}
          placeholder="ABCDE"
          className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
        />
        <button
          disabled={loading || code.length < 4}
          onClick={() => setSubmitted(true)}
          className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />}
          Watch
        </button>
      </div>
      {error && <p className="mt-2 text-sm text-coral">{error}</p>}
    </div>
  );
}
