import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, ShieldAlert, X } from "lucide-react";

export type ReportTarget = {
  type: "message" | "user";
  messageId?: string;
  reportedUserId?: string;
  snapshot?: string;
  authorLabel?: string;
};

const REASONS: { value: string; label: string }[] = [
  { value: "abuse", label: "Abusive content" },
  { value: "harassment", label: "Harassment or bullying" },
  { value: "hate_speech", label: "Hate speech" },
  { value: "spam", label: "Spam or scam" },
  { value: "nsfw", label: "Sexual / NSFW content" },
  { value: "other", label: "Something else" },
];

export function ReportDialog({
  target,
  reporterId,
  onClose,
}: {
  target: ReportTarget;
  reporterId: string;
  onClose: () => void;
}) {
  const [reason, setReason] = useState("abuse");
  const [details, setDetails] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (target.reportedUserId === reporterId) {
      toast.error("You can't report yourself.");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("reports").insert({
      reporter_id: reporterId,
      reported_user_id: target.reportedUserId ?? null,
      message_id: target.messageId ?? null,
      target_type: target.type,
      reason,
      details: details.trim() ? details.trim().slice(0, 1000) : null,
      message_snapshot: target.snapshot?.slice(0, 2000) ?? null,
    });
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Report submitted. Thanks for keeping BCA Adda safe.");
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ink/50 p-4">
      <form
        onSubmit={submit}
        className="w-full max-w-md rounded-2xl border-2 border-ink/15 bg-card p-5 shadow-lg"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2 font-display text-xl">
            <ShieldAlert className="h-5 w-5 text-coral" />
            Report {target.type === "message" ? "message" : "user"}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-1.5 text-muted-foreground hover:bg-secondary"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {target.snapshot && (
          <div className="mt-3 rounded-xl bg-secondary px-3 py-2 text-sm">
            <div className="text-xs font-semibold text-muted-foreground">
              {target.authorLabel ?? "Message"}
            </div>
            <div className="mt-0.5 line-clamp-3 whitespace-pre-wrap break-words">{target.snapshot}</div>
          </div>
        )}

        <div className="mt-4">
          <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Reason
          </label>
          <div className="mt-2 grid gap-1.5">
            {REASONS.map((r) => (
              <label
                key={r.value}
                className={`flex cursor-pointer items-center gap-2 rounded-xl border-2 px-3 py-2 text-sm font-medium ${
                  reason === r.value ? "border-ink bg-secondary" : "border-ink/15 hover:bg-secondary"
                }`}
              >
                <input
                  type="radio"
                  name="reason"
                  value={r.value}
                  checked={reason === r.value}
                  onChange={() => setReason(r.value)}
                  className="accent-current"
                />
                {r.label}
              </label>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            More details (optional)
          </label>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            maxLength={1000}
            rows={3}
            placeholder="Tell us what happened…"
            className="mt-1 w-full resize-none rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
          />
          <div className="mt-1 text-right text-[11px] text-muted-foreground">{details.length}/1000</div>
        </div>

        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full px-4 py-2 text-sm font-semibold hover:bg-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-1.5 rounded-full bg-coral px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            Submit report
          </button>
        </div>
      </form>
    </div>
  );
}
