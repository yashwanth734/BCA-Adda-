import { useEffect, useRef, useState } from "react";
import { Send, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

type Msg = { id: string; user_id: string; display_name: string; content: string; removed_at: string | null; created_at: string };

type Props = {
  roomId: string; // the game room's id, passed as room_id in room_chat_messages
};

export function GameRoomChat({ roomId }: Props) {
  const { user } = useAuth();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!roomId) return;
    // Same fix as RoomChat.tsx: fetch newest-first, reverse for display,
    // instead of ascending+limit which returns the oldest messages once
    // a room passes the limit.
    supabase
      .from("room_chat_messages")
      .select("id,user_id,display_name,content,removed_at,created_at")
      .eq("room_id", roomId)
      .order("created_at", { ascending: false })
      .limit(100)
      .then(({ data }) => setMsgs(((data ?? []) as Msg[]).reverse()));

    const ch = supabase
      .channel(`room_chat:${roomId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "room_chat_messages", filter: `room_id=eq.${roomId}` },
        ({ new: m }) => setMsgs((prev) => [...prev, m as Msg]),
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "room_chat_messages", filter: `room_id=eq.${roomId}` },
        ({ new: m }) => {
          const msg = m as Msg;
          if (msg.removed_at) setMsgs((prev) => prev.map((p) => p.id === msg.id ? { ...p, removed_at: msg.removed_at } : p));
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [roomId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs]);

  if (!user) return null;

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!draft.trim() || !roomId) return;
    setSending(true);
    const content = draft.trim();
    setDraft("");
    const { data: profile } = await supabase.from("profiles").select("username,full_name").eq("id", user.id).maybeSingle();
    const display_name = (profile as any)?.full_name ?? (profile as any)?.username ?? "Player";
    const { error } = await supabase.from("room_chat_messages").insert({ room_id: roomId, user_id: user.id, display_name, content });
    setSending(false);
    if (error) { toast.error(error.message); setDraft(content); }
  };

  return (
    <div className="flex h-48 flex-col overflow-hidden rounded-2xl border-2 border-ink">
      <div className="border-b border-border px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-muted-foreground">
        Room chat
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-1 p-2">
        {msgs.length === 0 ? (
          <p className="mt-4 text-center text-xs text-muted-foreground">No messages yet.</p>
        ) : (
          msgs.map((m) => {
            if (m.removed_at) return <p key={m.id} className="px-1 text-xs italic text-muted-foreground">[removed]</p>;
            const isMe = m.user_id === user.id;
            return (
              <div key={m.id} className={`flex gap-1.5 ${isMe ? "flex-row-reverse" : ""}`}>
                <span className={`max-w-[80%] rounded-xl px-2.5 py-1 text-xs ${isMe ? "bg-ink text-cream" : "bg-secondary"}`}>
                  {!isMe && <span className="mr-1 font-semibold">{m.display_name}:</span>}
                  {m.content}
                </span>
              </div>
            );
          })
        )}
      </div>
      <form onSubmit={send} className="flex border-t border-border">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          maxLength={200}
          placeholder="Say something…"
          className="flex-1 bg-transparent px-3 py-2 text-sm outline-none"
        />
        <button disabled={sending || !draft.trim()} className="px-3 text-muted-foreground hover:text-foreground disabled:opacity-40">
          {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
        </button>
      </form>
    </div>
  );
}
