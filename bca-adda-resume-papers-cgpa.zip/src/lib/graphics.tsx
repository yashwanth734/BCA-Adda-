import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Quality = "low" | "medium" | "high";
const KEY = "gfx-quality";

const Ctx = createContext<{ quality: Quality; setQuality: (q: Quality) => void }>({
  quality: "high",
  setQuality: () => {},
});

export function GraphicsProvider({ children }: { children: ReactNode }) {
  const [quality, setQuality] = useState<Quality>("high");

  useEffect(() => {
    const saved = localStorage.getItem(KEY) as Quality | null;
    if (saved === "low" || saved === "medium" || saved === "high") {
      setQuality(saved);
      return;
    }
    // sensible default for low-power devices
    const cores = navigator.hardwareConcurrency ?? 8;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced || cores <= 4) setQuality("medium");
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("gfx-low", "gfx-medium", "gfx-high");
    root.classList.add(`gfx-${quality}`);
    localStorage.setItem(KEY, quality);
  }, [quality]);

  return <Ctx.Provider value={{ quality, setQuality }}>{children}</Ctx.Provider>;
}

export const useGraphics = () => useContext(Ctx);

export function GraphicsToggle({ className = "" }: { className?: string }) {
  const { quality, setQuality } = useGraphics();
  const options: Quality[] = ["low", "medium", "high"];
  return (
    <div
      className={`inline-flex items-center gap-0.5 rounded-full border-2 border-ink bg-cream p-0.5 ${className}`}
      role="group"
      aria-label="Graphics quality"
    >
      {options.map((q) => (
        <button
          key={q}
          type="button"
          onClick={() => setQuality(q)}
          aria-pressed={quality === q}
          className={`rounded-full px-2.5 py-1 text-[11px] font-bold capitalize transition-colors ${
            quality === q ? "bg-ink text-cream" : "text-ink/70 hover:text-ink"
          }`}
        >
          {q}
        </button>
      ))}
    </div>
  );
}
