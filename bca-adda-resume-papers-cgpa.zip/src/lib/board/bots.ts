// Rule-based opponents for Trade City. Pure functions: given a state they
// return the single next action the bot wants to take.
import { GROUPS, JAIL_FINE, TILES, groupTiles } from "./tiles";
import type { BotLevel, GameAction, GameState } from "./types";
import { currentPlayer, ownedTiles, ownsWholeGroup, playerById } from "./engine";

const RESERVE: Record<BotLevel, number> = {
  easy: 0,
  medium: 120,
  hard: 220,
  expert: 300,
};

const BUY_APPETITE: Record<BotLevel, number> = {
  easy: 0.55,
  medium: 0.8,
  hard: 0.92,
  expert: 1,
};

export function botDelay(level: BotLevel = "medium") {
  const base = { easy: 1400, medium: 1100, hard: 850, expert: 650 }[level];
  return base + Math.floor(Math.random() * 500);
}

/** Highest bid this bot is willing to make for a tile. */
function bidCeiling(s: GameState, botId: string, tile: number, level: BotLevel) {
  const t = TILES[tile]!;
  const price = t.price ?? 0;
  const me = playerById(s, botId)!;
  let ceiling = price * (level === "easy" ? 0.6 : level === "medium" ? 0.9 : 1.15);
  if (t.kind === "estate" && t.group) {
    const mine = groupTiles(t.group).filter((i) => s.holdings[String(i)]?.owner === botId).length;
    if (mine > 0) ceiling *= 1 + 0.25 * mine;
  }
  return Math.max(0, Math.min(Math.floor(ceiling), me.cash - RESERVE[level]));
}

export function botAction(s: GameState, botId: string): GameAction | null {
  const me = playerById(s, botId);
  if (!me || me.bankrupt || s.phase === "over") return null;
  const level: BotLevel = me.bot ?? "medium";

  // Auctions run outside the turn order.
  if (s.phase === "auction" && s.auction) {
    if (s.players[s.auction.turnIndex]?.id !== botId) return null;
    const ceiling = bidCeiling(s, botId, s.auction.tile, level);
    const next = s.auction.highest + Math.max(10, Math.floor(s.auction.highest * 0.1));
    if (next <= ceiling) return { type: "bid", amount: next };
    return { type: "passBid" };
  }

  // Answer trades even when it is not our turn.
  const offer = s.trades.find((t) => t.status === "pending" && t.to === botId);
  if (offer) {
    const value = (tiles: number[]) =>
      tiles.reduce((sum, i) => sum + (TILES[i]?.price ?? 0), 0);
    const incoming = value(offer.giveTiles) + offer.giveCash;
    const outgoing = value(offer.getTiles) + offer.getCash;
    const margin = level === "easy" ? 0.85 : level === "expert" ? 1.25 : 1.05;
    return { type: "respondTrade", id: offer.id, accept: incoming >= outgoing * margin };
  }

  if (currentPlayer(s).id !== botId) return null;

  if (s.phase === "roll") {
    if (me.jail) {
      if (me.jailPass > 0) return { type: "useJailPass" };
      const wantsOut = level !== "easy" && me.cash > JAIL_FINE + RESERVE[level];
      if (wantsOut) return { type: "payJail" };
    }
    return { type: "roll" };
  }

  // Debt first: sell buildings, then mortgage.
  if (me.cash < 0) {
    const owned = ownedTiles(s, botId);
    const withHouses = owned.find((i) => (s.holdings[String(i)]?.houses ?? 0) > 0);
    if (withHouses !== undefined) return { type: "sellHouse", tile: withHouses };
    const free = owned.find((i) => !s.holdings[String(i)]?.mortgaged);
    if (free !== undefined) return { type: "mortgage", tile: free };
    return { type: "resign" };
  }

  if (s.pendingBuy && s.pendingBuy.playerId === botId) {
    const t = TILES[s.pendingBuy.tile]!;
    const price = t.price ?? 0;
    const affordable = me.cash - price >= RESERVE[level];
    const keen =
      Math.random() < BUY_APPETITE[level] ||
      (!!t.group && groupTiles(t.group).some((i) => s.holdings[String(i)]?.owner === botId));
    return affordable && keen ? { type: "buy" } : { type: "decline" };
  }

  // Build on completed districts when comfortable.
  if (level !== "easy") {
    const candidates = ownedTiles(s, botId)
      .map((i) => ({ i, t: TILES[i]! }))
      .filter(({ t }) => t.kind === "estate" && !!t.group)
      .filter(({ i, t }) => {
        const h = s.holdings[String(i)]!;
        if (h.mortgaged || h.houses >= 5) return false;
        if (!ownsWholeGroup(s, botId, t.group!)) return false;
        if (groupTiles(t.group!).some((g) => s.holdings[String(g)]?.mortgaged)) return false;
        const counts = groupTiles(t.group!).map((g) => s.holdings[String(g)]?.houses ?? 0);
        if (h.houses > Math.min(...counts)) return false;
        return me.cash - (t.buildCost ?? 0) >= RESERVE[level];
      })
      .sort((a, b) => (b.t.rent?.[1] ?? 0) - (a.t.rent?.[1] ?? 0));
    if (candidates.length > 0) return { type: "build", tile: candidates[0]!.i };
  }

  // Lift mortgages when flush.
  if (level === "hard" || level === "expert") {
    const stuck = ownedTiles(s, botId).find((i) => s.holdings[String(i)]?.mortgaged);
    if (stuck !== undefined) {
      const cost = Math.ceil((TILES[stuck]!.price ?? 0) * 0.55);
      if (me.cash - cost >= RESERVE[level] * 2) return { type: "unmortgage", tile: stuck };
    }
  }

  return { type: "endTurn" };
}

export const BOT_NAMES = [
  "Ava Ledger",
  "Rohit Rupee",
  "Neon Nita",
  "Baron Bhatt",
  "Cash Kiran",
  "Tara Tycoon",
];

export const GROUP_LABELS = Object.fromEntries(
  Object.entries(GROUPS).map(([k, v]) => [k, v.label]),
) as Record<string, string>;
