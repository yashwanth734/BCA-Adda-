// Server-only logic for Trade City rooms. Never imported by client code
// directly — always reached through src/lib/board/board.functions.ts.
import { createGame, applyAction, settleDebts, RuleError, type SeatInput } from "./engine";
import { botAction, BOT_NAMES } from "./bots";
import type { GameAction, GameState, BotLevel } from "./types";

export const SEAT_COLORS = [
  "#ff5c7a",
  "#39d0d8",
  "#ffc85c",
  "#8b7dff",
  "#4ade80",
  "#fb923c",
  "#f472b6",
  "#60a5fa",
];

export type RoomRow = {
  id: string;
  code: string;
  name: string;
  host_id: string;
  status: string;
  is_private: boolean;
  max_players: number;
  state: unknown;
  version: number;
  winner_id: string | null;
};

export type MemberRow = {
  id: string;
  room_id: string;
  user_id: string;
  seat: number;
  color: string;
  display_name: string | null;
  is_ready: boolean;
  is_bot: boolean;
};

type Admin = Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"];

export function newCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 5; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}

export async function loadRoom(admin: Admin, roomId: string) {
  const { data: room, error } = await admin
    .from("bg_rooms")
    .select("*")
    .eq("id", roomId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!room) throw new RuleError("Room not found.");
  const { data: members, error: mErr } = await admin
    .from("bg_room_members")
    .select("*")
    .eq("room_id", roomId)
    .order("seat");
  if (mErr) throw new Error(mErr.message);
  return { room: room as unknown as RoomRow, members: (members ?? []) as unknown as MemberRow[] };
}

async function displayName(admin: Admin, userId: string) {
  const { data } = await admin
    .from("profiles")
    .select("full_name, username")
    .eq("id", userId)
    .maybeSingle();
  return data?.full_name || data?.username || "Trader";
}

export async function createRoom(
  admin: Admin,
  userId: string,
  input: { name: string; isPrivate: boolean; maxPlayers: number },
) {
  const name = input.name.trim().slice(0, 40) || "Trade City table";
  let code = newCode();
  for (let attempt = 0; attempt < 5; attempt++) {
    const { data: clash } = await admin.from("bg_rooms").select("id").eq("code", code).maybeSingle();
    if (!clash) break;
    code = newCode();
  }
  const { data, error } = await admin
    .from("bg_rooms")
    .insert({
      code,
      name,
      host_id: userId,
      is_private: input.isPrivate,
      max_players: input.maxPlayers,
      status: "lobby",
      state: {},
    })
    .select("id, code")
    .single();
  if (error) throw new Error(error.message);
  await admin.from("bg_room_members").insert({
    room_id: data.id,
    user_id: userId,
    seat: 0,
    color: SEAT_COLORS[0]!,
    display_name: await displayName(admin, userId),
    is_ready: true,
  });
  return { id: data.id as string, code: data.code as string };
}

export async function joinRoom(admin: Admin, userId: string, code: string) {
  const { data: room } = await admin
    .from("bg_rooms")
    .select("*")
    .eq("code", code.trim().toUpperCase())
    .maybeSingle();
  if (!room) throw new RuleError("No table with that code.");
  const { data: members } = await admin
    .from("bg_room_members")
    .select("*")
    .eq("room_id", room.id)
    .order("seat");
  const list = (members ?? []) as unknown as MemberRow[];
  if (list.some((m) => m.user_id === userId)) return { id: room.id as string };
  if (room.status !== "lobby") throw new RuleError("That match already started.");
  if (list.length >= (room.max_players as number)) throw new RuleError("That table is full.");
  const taken = new Set(list.map((m) => m.seat));
  let seat = 0;
  while (taken.has(seat)) seat++;
  const { error } = await admin.from("bg_room_members").insert({
    room_id: room.id,
    user_id: userId,
    seat,
    color: SEAT_COLORS[seat % SEAT_COLORS.length]!,
    display_name: await displayName(admin, userId),
    is_ready: false,
  });
  if (error) throw new Error(error.message);
  return { id: room.id as string };
}

/** Lobby bots live in bg_rooms.state so they need no auth.users row. */
export type LobbyBot = { id: string; name: string; level: BotLevel; color: string };

export function lobbyBots(room: RoomRow): LobbyBot[] {
  const raw = (room.state as { lobbyBots?: LobbyBot[] } | null)?.lobbyBots;
  return Array.isArray(raw) ? raw : [];
}

export async function addBot(admin: Admin, userId: string, roomId: string, level: BotLevel) {
  const { room, members } = await loadRoom(admin, roomId);
  if (room.host_id !== userId) throw new RuleError("Only the host can add opponents.");
  if (room.status !== "lobby") throw new RuleError("The match already started.");
  const bots = lobbyBots(room);
  if (members.length + bots.length >= room.max_players) throw new RuleError("The table is full.");
  const used = new Set(bots.map((b) => b.name));
  const name = BOT_NAMES.find((n) => !used.has(n)) ?? `${BOT_NAMES[0]} ${bots.length + 1}`;
  const seat = members.length + bots.length;
  const next = [
    ...bots,
    {
      id: `bot:${Math.random().toString(36).slice(2, 10)}`,
      name,
      level,
      color: SEAT_COLORS[seat % SEAT_COLORS.length]!,
    },
  ];
  const { error } = await admin
    .from("bg_rooms")
    .update({ state: { lobbyBots: next } as unknown as never })
    .eq("id", roomId);
  if (error) throw new Error(error.message);
  return { ok: true };
}

export async function removeBot(admin: Admin, userId: string, roomId: string, botId: string) {
  const { room } = await loadRoom(admin, roomId);
  if (room.host_id !== userId) throw new RuleError("Only the host can remove opponents.");
  if (room.status !== "lobby") throw new RuleError("The match already started.");
  const next = lobbyBots(room).filter((b) => b.id !== botId);
  const { error } = await admin
    .from("bg_rooms")
    .update({ state: { lobbyBots: next } as unknown as never })
    .eq("id", roomId);
  if (error) throw new Error(error.message);
  return { ok: true };
}

export async function setReady(admin: Admin, userId: string, roomId: string, ready: boolean) {
  const { error } = await admin
    .from("bg_room_members")
    .update({ is_ready: ready, last_seen: new Date().toISOString() })
    .eq("room_id", roomId)
    .eq("user_id", userId)
    .eq("is_bot", false);
  if (error) throw new Error(error.message);
  return { ok: true };
}

export async function leaveRoom(admin: Admin, userId: string, roomId: string) {
  const { room, members } = await loadRoom(admin, roomId);
  if (room.status === "playing") {
    const state = room.state as GameState;
    if (state?.players?.some((p) => p.id === userId && !p.bankrupt)) {
      const next = settleDebts(applyAction(state, userId, { type: "resign" }));
      await saveState(admin, room, next);
    }
    return { ok: true };
  }
  await admin.from("bg_room_members").delete().eq("room_id", roomId).eq("user_id", userId);
  const humans = members.filter((m) => !m.is_bot && m.user_id !== userId);
  if (humans.length === 0) await admin.from("bg_rooms").delete().eq("id", roomId);
  else if (room.host_id === userId)
    await admin.from("bg_rooms").update({ host_id: humans[0]!.user_id }).eq("id", roomId);
  return { ok: true };
}

function seatsFrom(members: MemberRow[], bots: LobbyBot[]): SeatInput[] {
  const humans: SeatInput[] = members
    .slice()
    .sort((a, b) => a.seat - b.seat)
    .map((m) => ({
      id: m.user_id,
      name: m.display_name ?? "Trader",
      color: m.color,
      isBot: false,
    }));
  const botSeats: SeatInput[] = bots.map((b) => ({
    id: b.id,
    name: `${b.name} · ${b.level}`,
    color: b.color,
    isBot: true,
    bot: b.level,
  }));
  return [...humans, ...botSeats];
}

export async function startGame(admin: Admin, userId: string, roomId: string) {
  const { room, members } = await loadRoom(admin, roomId);
  if (room.host_id !== userId) throw new RuleError("Only the host can start the match.");
  if (room.status !== "lobby") throw new RuleError("Already started.");
  const bots = lobbyBots(room);
  if (members.length + bots.length < 2) throw new RuleError("You need at least two players.");
  if (members.some((m) => !m.is_ready)) throw new RuleError("Everyone must be ready.");
  let state = createGame(seatsFrom(members, bots));
  state = await runBots(state);
  const { error } = await admin
    .from("bg_rooms")
    .update({ status: "playing", state: state as unknown as never, version: room.version + 1 })
    .eq("id", roomId);
  if (error) throw new Error(error.message);
  return { ok: true };
}

async function saveState(admin: Admin, room: RoomRow, state: GameState) {
  const winner = state.players.find((p) => p.id === state.winner);
  const patch = {
    state: state as unknown as never,
    version: room.version + 1,
    ...(state.phase === "over"
      ? {
          status: "finished",
          winner_id: winner && !winner.isBot ? winner.id : null,
        }
      : {}),
  };
  const { error } = await admin.from("bg_rooms").update(patch).eq("id", room.id);
  if (error) throw new Error(error.message);
}

/** Let bot players take their turns until a human is up (or the game ends). */
async function runBots(state: GameState) {
  let s = state;
  for (let i = 0; i < 200; i++) {
    if (s.phase === "over") break;
    const actorId =
      s.phase === "auction" && s.auction
        ? s.players[s.auction.turnIndex]?.id
        : s.players[s.turn]?.id;
    const pending = s.trades.find((t) => t.status === "pending");
    const botId =
      pending && s.players.find((p) => p.id === pending.to)?.isBot
        ? pending.to
        : s.players.find((p) => p.id === actorId)?.isBot
          ? actorId
          : null;
    if (!botId) break;
    const action = botAction(s, botId);
    if (!action) break;
    try {
      s = settleDebts(applyAction(s, botId, action));
    } catch {
      // A bot picked an illegal move — end its turn defensively.
      try {
        s = settleDebts(applyAction(s, botId, { type: "endTurn" }));
      } catch {
        break;
      }
    }
  }
  return s;
}

export async function act(admin: Admin, userId: string, roomId: string, action: GameAction) {
  const { room } = await loadRoom(admin, roomId);
  if (room.status !== "playing") throw new RuleError("This match is not running.");
  const state = room.state as GameState;
  if (!state?.players?.length) throw new RuleError("Match state is missing.");
  const actorId = action.type === "timeout" ? userId : userId;
  let next = settleDebts(applyAction(state, actorId, action));
  next = await runBots(next);
  await saveState(admin, room, next);
  return { ok: true };
}
