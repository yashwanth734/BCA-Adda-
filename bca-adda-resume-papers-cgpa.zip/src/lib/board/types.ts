// Core types for Trade City — an original property-trading board game.

export type GroupId =
  | "slate"
  | "teal"
  | "violet"
  | "amber"
  | "rose"
  | "emerald"
  | "sky"
  | "gold";

export type TileKind =
  | "start"
  | "estate"
  | "transit"
  | "utility"
  | "tax"
  | "event"
  | "reward"
  | "jail"
  | "gotojail"
  | "parking";

export type Tile = {
  index: number;
  kind: TileKind;
  name: string;
  /** Estates only */
  group?: GroupId;
  price?: number;
  /** rent[0] = bare land, 1..4 = houses, 5 = tower */
  rent?: number[];
  buildCost?: number;
  /** tax tiles */
  amount?: number;
  icon?: string;
};

export type Holding = {
  owner: string;
  houses: number; // 0..5, 5 === tower/hotel
  mortgaged: boolean;
};

export type Player = {
  id: string;
  name: string;
  color: string;
  avatarUrl?: string | null;
  cash: number;
  pos: number;
  jail: boolean;
  jailTurns: number;
  bankrupt: boolean;
  isBot: boolean;
  bot?: BotLevel;
  xp: number;
  jailPass: number;
};

export type BotLevel = "easy" | "medium" | "hard" | "expert";

export type LogEntry = { id: string; text: string; ts: number; kind?: string };

export type PendingBuy = { tile: number; playerId: string };

export type Auction = {
  tile: number;
  highest: number;
  highestBidder: string | null;
  turnIndex: number;
  passed: string[];
};

export type TradeOffer = {
  id: string;
  from: string;
  to: string;
  giveCash: number;
  getCash: number;
  giveTiles: number[];
  getTiles: number[];
  status: "pending" | "accepted" | "declined";
};

export type GameState = {
  v: 1;
  players: Player[];
  turn: number;
  phase: "lobby" | "roll" | "resolve" | "auction" | "over";
  dice: [number, number] | null;
  doubles: number;
  holdings: Record<string, Holding>;
  pendingBuy: PendingBuy | null;
  auction: Auction | null;
  trades: TradeOffer[];
  pot: number; // free-parking pot
  log: LogEntry[];
  turnEndsAt: number | null;
  round: number;
  winner: string | null;
  startedAt: number | null;
};

export type GameAction =
  | { type: "roll" }
  | { type: "buy" }
  | { type: "decline" }
  | { type: "bid"; amount: number }
  | { type: "passBid" }
  | { type: "build"; tile: number }
  | { type: "sellHouse"; tile: number }
  | { type: "mortgage"; tile: number }
  | { type: "unmortgage"; tile: number }
  | { type: "payJail" }
  | { type: "useJailPass" }
  | { type: "endTurn" }
  | { type: "resign" }
  | { type: "proposeTrade"; offer: Omit<TradeOffer, "id" | "from" | "status"> }
  | { type: "respondTrade"; id: string; accept: boolean }
  | { type: "timeout" };
