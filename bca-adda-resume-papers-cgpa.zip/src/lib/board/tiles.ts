import type { GroupId, Tile } from "./types";

/**
 * Trade City — an entirely original 40-tile board.
 * Names, districts, prices and artwork are invented for this project.
 */

export const GROUPS: Record<GroupId, { label: string; color: string; count: number }> = {
  slate: { label: "Old Quarter", color: "#7c8aa5", count: 2 },
  teal: { label: "Dock Row", color: "#2fb5b0", count: 3 },
  violet: { label: "Studio Mile", color: "#8b6df0", count: 3 },
  amber: { label: "Market Belt", color: "#f0a63a", count: 3 },
  rose: { label: "Garden Ring", color: "#f0567c", count: 3 },
  emerald: { label: "Tech Park", color: "#35c47a", count: 3 },
  sky: { label: "Skyline Ave", color: "#48a7f5", count: 3 },
  gold: { label: "Crown Heights", color: "#e8c249", count: 2 },
};

const estate = (
  index: number,
  name: string,
  group: GroupId,
  price: number,
  rent: number[],
  buildCost: number,
): Tile => ({ index, kind: "estate", name, group, price, rent, buildCost });

export const TILES: Tile[] = [
  { index: 0, kind: "start", name: "Launch Pad", icon: "rocket" },
  estate(1, "Neem Lane", "slate", 60, [2, 10, 30, 90, 160, 250], 50),
  { index: 2, kind: "reward", name: "Civic Chest", icon: "gift" },
  estate(3, "Banyan Row", "slate", 60, [4, 20, 60, 180, 320, 450], 50),
  { index: 4, kind: "tax", name: "City Levy", amount: 200, icon: "receipt" },
  { index: 5, kind: "transit", name: "North Skyport", price: 200, icon: "plane" },
  estate(6, "Coral Quay", "teal", 100, [6, 30, 90, 270, 400, 550], 50),
  { index: 7, kind: "event", name: "Wildcard", icon: "sparkles" },
  estate(8, "Anchor Walk", "teal", 100, [6, 30, 90, 270, 400, 550], 50),
  estate(9, "Saltwind Pier", "teal", 120, [8, 40, 100, 300, 450, 600], 50),
  { index: 10, kind: "jail", name: "Holding Bay", icon: "lock" },
  estate(11, "Indigo Studio", "violet", 140, [10, 50, 150, 450, 625, 750], 100),
  { index: 12, kind: "utility", name: "Solar Grid", price: 150, icon: "zap" },
  estate(13, "Reel Street", "violet", 140, [10, 50, 150, 450, 625, 750], 100),
  estate(14, "Canvas Court", "violet", 160, [12, 60, 180, 500, 700, 900], 100),
  { index: 15, kind: "transit", name: "Harbor Terminal", price: 200, icon: "ship" },
  estate(16, "Spice Bazaar", "amber", 180, [14, 70, 200, 550, 750, 950], 100),
  { index: 17, kind: "reward", name: "Civic Chest", icon: "gift" },
  estate(18, "Copper Arcade", "amber", 180, [14, 70, 200, 550, 750, 950], 100),
  estate(19, "Lantern Square", "amber", 200, [16, 80, 220, 600, 800, 1000], 100),
  { index: 20, kind: "parking", name: "Riverside Rest", icon: "palmtree" },
  estate(21, "Jasmine Terrace", "rose", 220, [18, 90, 250, 700, 875, 1050], 150),
  { index: 22, kind: "event", name: "Wildcard", icon: "sparkles" },
  estate(23, "Orchid Crescent", "rose", 220, [18, 90, 250, 700, 875, 1050], 150),
  estate(24, "Tulip Boulevard", "rose", 240, [20, 100, 300, 750, 925, 1100], 150),
  { index: 25, kind: "transit", name: "East Railyard", price: 200, icon: "train" },
  estate(26, "Cipher Campus", "emerald", 260, [22, 110, 330, 800, 975, 1150], 150),
  estate(27, "Quantum Lane", "emerald", 260, [22, 110, 330, 800, 975, 1150], 150),
  { index: 28, kind: "utility", name: "Hydro Works", price: 150, icon: "droplets" },
  estate(29, "Pixel Yard", "emerald", 280, [24, 120, 360, 850, 1025, 1200], 150),
  { index: 30, kind: "gotojail", name: "Report to Holding", icon: "siren" },
  estate(31, "Zenith Tower", "sky", 300, [26, 130, 390, 900, 1100, 1275], 200),
  estate(32, "Aurora Deck", "sky", 300, [26, 130, 390, 900, 1100, 1275], 200),
  { index: 33, kind: "reward", name: "Civic Chest", icon: "gift" },
  estate(34, "Vertex Plaza", "sky", 320, [28, 150, 450, 1000, 1200, 1400], 200),
  { index: 35, kind: "transit", name: "West Metro Hub", price: 200, icon: "train-front" },
  { index: 36, kind: "event", name: "Wildcard", icon: "sparkles" },
  estate(37, "Coronet Mile", "gold", 350, [35, 175, 500, 1100, 1300, 1500], 200),
  { index: 38, kind: "tax", name: "Luxury Duty", amount: 100, icon: "gem" },
  estate(39, "Regalia Heights", "gold", 400, [50, 200, 600, 1400, 1700, 2000], 200),
];

export const TILE_COUNT = TILES.length;

export const groupTiles = (group: GroupId) =>
  TILES.filter((t) => t.kind === "estate" && t.group === group).map((t) => t.index);

export const TRANSIT_TILES = TILES.filter((t) => t.kind === "transit").map((t) => t.index);
export const UTILITY_TILES = TILES.filter((t) => t.kind === "utility").map((t) => t.index);

/** Transit rent scales with how many hubs the owner controls. */
export const TRANSIT_RENT = [0, 25, 50, 100, 200];

export type CardEffect =
  | { kind: "cash"; amount: number }
  | { kind: "moveTo"; tile: number; collectStart?: boolean }
  | { kind: "moveBy"; steps: number }
  | { kind: "jail" }
  | { kind: "jailPass" }
  | { kind: "payEach"; amount: number }
  | { kind: "collectEach"; amount: number }
  | { kind: "repairs"; perHouse: number; perTower: number };

export type Card = { id: string; text: string; effect: CardEffect };

/** Wildcard deck — random events. */
export const EVENT_CARDS: Card[] = [
  { id: "e1", text: "Metro line extended. Advance to Launch Pad.", effect: { kind: "moveTo", tile: 0, collectStart: true } },
  { id: "e2", text: "Festival crowd pulls you to Lantern Square.", effect: { kind: "moveTo", tile: 19, collectStart: true } },
  { id: "e3", text: "Investor buyout — collect ₹1,500.", effect: { kind: "cash", amount: 1500 } },
  { id: "e4", text: "Server outage at your studio. Pay ₹450.", effect: { kind: "cash", amount: -450 } },
  { id: "e5", text: "Caught fare-dodging. Report to Holding Bay.", effect: { kind: "jail" } },
  { id: "e6", text: "Traffic jam. Move back 3 tiles.", effect: { kind: "moveBy", steps: -3 } },
  { id: "e7", text: "Board pardon — keep this pass to skip Holding once.", effect: { kind: "jailPass" } },
  { id: "e8", text: "Street audit: pay ₹250 per house, ₹1,000 per tower.", effect: { kind: "repairs", perHouse: 250, perTower: 1000 } },
  { id: "e9", text: "Ferry ticket refunded. Advance to Harbor Terminal.", effect: { kind: "moveTo", tile: 15, collectStart: true } },
  { id: "e10", text: "You win the design jam. Every rival pays you ₹250.", effect: { kind: "collectEach", amount: 250 } },
  { id: "e11", text: "Skyport upgrade fee. Pay ₹600.", effect: { kind: "cash", amount: -600 } },
  { id: "e12", text: "Rooftop launch party. Advance to Regalia Heights.", effect: { kind: "moveTo", tile: 39, collectStart: true } },
];

/** Civic Chest deck — community rewards. */
export const REWARD_CARDS: Card[] = [
  { id: "r1", text: "Civic grant approved. Collect ₹1,000.", effect: { kind: "cash", amount: 1000 } },
  { id: "r2", text: "Neighbourhood clean-up refund. Collect ₹400.", effect: { kind: "cash", amount: 400 } },
  { id: "r3", text: "Water bill correction. Collect ₹250.", effect: { kind: "cash", amount: 250 } },
  { id: "r4", text: "Sponsor a school lab. Pay ₹500.", effect: { kind: "cash", amount: -500 } },
  { id: "r5", text: "Health check camp fee. Pay ₹300.", effect: { kind: "cash", amount: -300 } },
  { id: "r6", text: "Volunteer stipend from each rival: ₹150.", effect: { kind: "collectEach", amount: 150 } },
  { id: "r7", text: "You host the block party. Pay each rival ₹200.", effect: { kind: "payEach", amount: 200 } },
  { id: "r8", text: "Community pardon — skip Holding Bay once.", effect: { kind: "jailPass" } },
  { id: "r9", text: "Return to Launch Pad and collect your salary.", effect: { kind: "moveTo", tile: 0, collectStart: true } },
  { id: "r10", text: "Property survey: pay ₹100 per house, ₹500 per tower.", effect: { kind: "repairs", perHouse: 100, perTower: 500 } },
  { id: "r11", text: "Old deposit released. Collect ₹750.", effect: { kind: "cash", amount: 750 } },
  { id: "r12", text: "Zoning violation. Report to Holding Bay.", effect: { kind: "jail" } },
];

export const START_CASH: Record<number, number> = {
  2: 1500,
  3: 1500,
  4: 1500,
  6: 2000,
  8: 2500,
};

export const PASS_START_BONUS = 200;
export const JAIL_FINE = 50;
export const JAIL_TILE = 10;
export const TURN_SECONDS = 45;

export const PLAYER_COLORS = [
  "#f0567c",
  "#48a7f5",
  "#35c47a",
  "#f0a63a",
  "#8b6df0",
  "#2fb5b0",
  "#e8c249",
  "#ff7a45",
];
