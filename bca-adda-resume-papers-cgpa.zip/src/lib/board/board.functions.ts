import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { GameAction } from "./types";

const roomId = z.object({ roomId: z.string().uuid() });

const actionSchema: z.ZodType<GameAction> = z.union([
  z.object({ type: z.literal("roll") }),
  z.object({ type: z.literal("buy") }),
  z.object({ type: z.literal("decline") }),
  z.object({ type: z.literal("bid"), amount: z.number().int().min(1).max(100000) }),
  z.object({ type: z.literal("passBid") }),
  z.object({ type: z.literal("build"), tile: z.number().int().min(0).max(39) }),
  z.object({ type: z.literal("sellHouse"), tile: z.number().int().min(0).max(39) }),
  z.object({ type: z.literal("mortgage"), tile: z.number().int().min(0).max(39) }),
  z.object({ type: z.literal("unmortgage"), tile: z.number().int().min(0).max(39) }),
  z.object({ type: z.literal("payJail") }),
  z.object({ type: z.literal("useJailPass") }),
  z.object({ type: z.literal("endTurn") }),
  z.object({ type: z.literal("resign") }),
  z.object({
    type: z.literal("proposeTrade"),
    offer: z.object({
      to: z.string().min(1).max(64),
      giveCash: z.number().int().min(0).max(100000),
      getCash: z.number().int().min(0).max(100000),
      giveTiles: z.array(z.number().int().min(0).max(39)).max(28),
      getTiles: z.array(z.number().int().min(0).max(39)).max(28),
    }),
  }),
  z.object({ type: z.literal("respondTrade"), id: z.string().min(1).max(64), accept: z.boolean() }),
  z.object({ type: z.literal("timeout") }),
]) as z.ZodType<GameAction>;

export const bgCreateRoom = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        name: z.string().trim().max(40).default("Trade City table"),
        isPrivate: z.boolean().default(false),
        maxPlayers: z.union([z.literal(2), z.literal(3), z.literal(4), z.literal(6), z.literal(8)]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { createRoom } = await import("./room.server");
    return createRoom(supabaseAdmin, context.userId, data);
  });

export const bgJoinRoom = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ code: z.string().trim().min(3).max(8) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { joinRoom } = await import("./room.server");
    return joinRoom(supabaseAdmin, context.userId, data.code);
  });

export const bgLeaveRoom = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => roomId.parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { leaveRoom } = await import("./room.server");
    return leaveRoom(supabaseAdmin, context.userId, data.roomId);
  });

export const bgSetReady = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => roomId.extend({ ready: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { setReady } = await import("./room.server");
    return setReady(supabaseAdmin, context.userId, data.roomId, data.ready);
  });

export const bgAddBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    roomId.extend({ level: z.enum(["easy", "medium", "hard", "expert"]) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { addBot } = await import("./room.server");
    return addBot(supabaseAdmin, context.userId, data.roomId, data.level);
  });

export const bgRemoveBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => roomId.extend({ botId: z.string().min(1).max(64) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { removeBot } = await import("./room.server");
    return removeBot(supabaseAdmin, context.userId, data.roomId, data.botId);
  });

export const bgStartGame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => roomId.parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { startGame } = await import("./room.server");
    return startGame(supabaseAdmin, context.userId, data.roomId);
  });

export const bgAct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => roomId.extend({ action: actionSchema }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { act } = await import("./room.server");
    return act(supabaseAdmin, context.userId, data.roomId, data.action);
  });
