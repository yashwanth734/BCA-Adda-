// Browser-safe helpers + types for the Trade City board UI.
import { GROUPS, TILES } from "./tiles";
import type { GameState, Tile } from "./types";

export type RoomRow = {
  id: string;
  code: string;
  name: string;
  host_id: string;
  status: string;
  is_private: boolean;
  max_players: number;
  state: unknown;
  version: number;
  winner_id: string | null;
  created_at?: string;
  updated_at?: string;
};

export type MemberRow = {
  id: string;
  room_id: string;
  user_id: string;
  seat: number;
  color: string;
  display_name: string | null;
  is_ready: boolean;
  is_bot: boolean;
};

export type LobbyBot = { id: string; name: string; level: string; color: string };

export const lobbyBotsOf = (room: RoomRow | null): LobbyBot[] => {
  const raw = (room?.state as { lobbyBots?: LobbyBot[] } | null)?.lobbyBots;
  return Array.isArray(raw) ? raw : [];
};

export const gameStateOf = (room: RoomRow | null): GameState | null => {
  const s = room?.state as GameState | null;
  return s && Array.isArray(s.players) && s.players.length ? s : null;
};

export const money = (n: number) => `₹${Math.round(n).toLocaleString("en-IN")}`;

export const tileAt = (i: number): Tile => TILES[i]!;

export const groupColor = (t: Tile) => (t.group ? GROUPS[t.group].color : "transparent");

/** 11x11 ring coordinates (1-indexed row/col) for a tile index. */
export function cellFor(i: number): { row: number; col: number } {
  if (i === 0) return { row: 11, col: 11 };
  if (i < 10) return { row: 11, col: 11 - i };
  if (i === 10) return { row: 11, col: 1 };
  if (i < 20) return { row: 11 - (i - 10), col: 1 };
  if (i === 20) return { row: 1, col: 1 };
  if (i < 30) return { row: 1, col: 1 + (i - 20) };
  if (i === 30) return { row: 1, col: 11 };
  return { row: 1 + (i - 30), col: 11 };
}

/** Percentage position of a tile's centre on the square board. */
export function tilePercent(i: number) {
  const { row, col } = cellFor(i);
  const unit = 100 / 11;
  return { left: (col - 1) * unit + unit / 2, top: (row - 1) * unit + unit / 2 };
}

export const mortgageValue = (t: Tile) => Math.floor((t.price ?? 0) / 2);
export const unmortgageCost = (t: Tile) => Math.ceil(mortgageValue(t) * 1.1);

export const REACTIONS = ["👍", "😂", "🔥", "😱", "🤝", "💸"] as const;
