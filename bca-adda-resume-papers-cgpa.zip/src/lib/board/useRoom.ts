import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { MemberRow, RoomRow } from "./client";

/** Live room row + members, kept in sync through realtime. */
export function useRoom(roomId: string) {
  const [room, setRoom] = useState<RoomRow | null>(null);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);

  const load = useCallback(async () => {
    const [{ data: r }, { data: m }] = await Promise.all([
      supabase.from("bg_rooms").select("*").eq("id", roomId).maybeSingle(),
      supabase.from("bg_room_members").select("*").eq("room_id", roomId).order("seat"),
    ]);
    setRoom((r as unknown as RoomRow) ?? null);
    setMembers((m ?? []) as unknown as MemberRow[]);
    setMissing(!r);
    setLoading(false);
  }, [roomId]);

  useEffect(() => {
    void load();
    const channel = supabase
      .channel(`bg_room:${roomId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bg_rooms", filter: `id=eq.${roomId}` },
        (payload) => {
          if (payload.eventType === "DELETE") setMissing(true);
          else setRoom(payload.new as unknown as RoomRow);
        },
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bg_room_members", filter: `room_id=eq.${roomId}` },
        () => void load(),
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [roomId, load]);

  return { room, members, loading, missing, reload: load };
}
