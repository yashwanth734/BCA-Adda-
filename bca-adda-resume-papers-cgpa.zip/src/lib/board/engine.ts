import {
  EVENT_CARDS,
  GROUPS,
  JAIL_FINE,
  JAIL_TILE,
  PASS_START_BONUS,
  REWARD_CARDS,
  START_CASH,
  TILES,
  TILE_COUNT,
  TRANSIT_RENT,
  TRANSIT_TILES,
  TURN_SECONDS,
  UTILITY_TILES,
  groupTiles,
  type Card,
} from "./tiles";
import type { GameAction, GameState, Holding, Player, Tile } from "./types";

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

const uid = () => Math.random().toString(36).slice(2, 10);

export class RuleError extends Error {}

function fail(msg: string): never {
  throw new RuleError(msg);
}

const tileAt = (i: number): Tile => TILES[((i % TILE_COUNT) + TILE_COUNT) % TILE_COUNT]!;

const holding = (s: GameState, tile: number): Holding | undefined => s.holdings[String(tile)];

export const ownerOf = (s: GameState, tile: number) => holding(s, tile)?.owner ?? null;

const log = (s: GameState, text: string, kind = "info") => {
  s.log.push({ id: uid(), text, ts: Date.now(), kind });
  if (s.log.length > 120) s.log.splice(0, s.log.length - 120);
};

export const playerById = (s: GameState, id: string) => s.players.find((p) => p.id === id);

export const currentPlayer = (s: GameState) => s.players[s.turn]!;

const alive = (s: GameState) => s.players.filter((p) => !p.bankrupt);

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x)) as T;

export function ownedTiles(s: GameState, playerId: string) {
  return Object.entries(s.holdings)
    .filter(([, h]) => h.owner === playerId)
    .map(([k]) => Number(k))
    .sort((a, b) => a - b);
}

export function netWorth(s: GameState, playerId: string) {
  let total = playerById(s, playerId)?.cash ?? 0;
  for (const idx of ownedTiles(s, playerId)) {
    const t = tileAt(idx);
    const h = holding(s, idx)!;
    total += h.mortgaged ? Math.floor((t.price ?? 0) / 2) : (t.price ?? 0);
    total += h.houses * Math.floor((t.buildCost ?? 0) / 2);
  }
  return total;
}

export function ownsWholeGroup(s: GameState, playerId: string, group: keyof typeof GROUPS) {
  const tiles = groupTiles(group);
  return tiles.length > 0 && tiles.every((i) => ownerOf(s, i) === playerId);
}

/* ------------------------------------------------------------------ */
/* setup                                                               */
/* ------------------------------------------------------------------ */

export type SeatInput = {
  id: string;
  name: string;
  color: string;
  avatarUrl?: string | null;
  isBot?: boolean;
  bot?: Player["bot"];
};

export function createGame(seats: SeatInput[]): GameState {
  const cash = START_CASH[seats.length] ?? 1500;
  const state: GameState = {
    v: 1,
    players: seats.map((s) => ({
      id: s.id,
      name: s.name,
      color: s.color,
      avatarUrl: s.avatarUrl ?? null,
      cash,
      pos: 0,
      jail: false,
      jailTurns: 0,
      bankrupt: false,
      isBot: !!s.isBot,
      bot: s.bot,
      xp: 0,
      jailPass: 0,
    })),
    turn: 0,
    phase: "roll",
    dice: null,
    doubles: 0,
    holdings: {},
    pendingBuy: null,
    auction: null,
    trades: [],
    pot: 0,
    log: [],
    turnEndsAt: Date.now() + TURN_SECONDS * 1000,
    round: 1,
    winner: null,
    startedAt: Date.now(),
  };
  log(state, `Match started with ${seats.length} traders. Everyone gets ₹${cash}.`, "start");
  return state;
}

/* ------------------------------------------------------------------ */
/* money                                                               */
/* ------------------------------------------------------------------ */

function pay(s: GameState, fromId: string, amount: number, toId?: string | null) {
  const from = playerById(s, fromId)!;
  from.cash -= amount;
  if (toId) {
    const to = playerById(s, toId);
    if (to) to.cash += amount;
  } else {
    s.pot += amount;
  }
}

function bankrupt(s: GameState, playerId: string, creditorId?: string | null) {
  const p = playerById(s, playerId)!;
  p.bankrupt = true;
  for (const idx of ownedTiles(s, playerId)) {
    const h = s.holdings[String(idx)]!;
    if (creditorId) {
      h.owner = creditorId;
      h.houses = 0;
    } else {
      delete s.holdings[String(idx)];
    }
  }
  if (creditorId && p.cash > 0) {
    const c = playerById(s, creditorId);
    if (c) c.cash += p.cash;
  }
  p.cash = 0;
  log(s, `${p.name} is bankrupt and out of the match.`, "bankrupt");
  checkWinner(s);
}

function checkWinner(s: GameState) {
  const left = alive(s);
  if (left.length === 1) {
    s.phase = "over";
    s.winner = left[0]!.id;
    s.pendingBuy = null;
    s.auction = null;
    s.turnEndsAt = null;
    log(s, `🏆 ${left[0]!.name} owns Trade City!`, "win");
  }
}

/* ------------------------------------------------------------------ */
/* rent                                                                */
/* ------------------------------------------------------------------ */

export function rentFor(s: GameState, tile: number, diceSum: number): number {
  const t = tileAt(tile);
  const h = holding(s, tile);
  if (!h || h.mortgaged) return 0;
  if (t.kind === "estate") {
    const base = t.rent![h.houses]!;
    if (h.houses === 0 && ownsWholeGroup(s, h.owner, t.group!)) return base * 2;
    return base;
  }
  if (t.kind === "transit") {
    const count = TRANSIT_TILES.filter((i) => ownerOf(s, i) === h.owner).length;
    return TRANSIT_RENT[count] ?? 0;
  }
  if (t.kind === "utility") {
    const count = UTILITY_TILES.filter((i) => ownerOf(s, i) === h.owner).length;
    return diceSum * (count >= 2 ? 10 : 4);
  }
  return 0;
}

/* ------------------------------------------------------------------ */
/* movement + landing                                                  */
/* ------------------------------------------------------------------ */

function moveTo(s: GameState, p: Player, tile: number, collectStart: boolean) {
  const passed = tile < p.pos;
  p.pos = ((tile % TILE_COUNT) + TILE_COUNT) % TILE_COUNT;
  if (passed && collectStart) {
    p.cash += PASS_START_BONUS;
    log(s, `${p.name} passed Launch Pad and collected ₹${PASS_START_BONUS}.`, "cash");
  }
}

function sendToJail(s: GameState, p: Player) {
  p.pos = JAIL_TILE;
  p.jail = true;
  p.jailTurns = 0;
  s.doubles = 0;
  log(s, `${p.name} is sent to the Holding Bay.`, "jail");
}

function drawCard(s: GameState, p: Player, deck: Card[], label: string) {
  const card = deck[Math.floor(Math.random() * deck.length)]!;
  log(s, `${label}: ${card.text}`, "card");
  const e = card.effect;
  switch (e.kind) {
    case "cash":
      p.cash += e.amount;
      if (e.amount < 0) s.pot += -e.amount;
      break;
    case "moveTo":
      moveTo(s, p, e.tile, !!e.collectStart);
      resolveLanding(s, p, s.dice ? s.dice[0] + s.dice[1] : 7);
      break;
    case "moveBy":
      p.pos = ((p.pos + e.steps) % TILE_COUNT + TILE_COUNT) % TILE_COUNT;
      resolveLanding(s, p, s.dice ? s.dice[0] + s.dice[1] : 7);
      break;
    case "jail":
      sendToJail(s, p);
      break;
    case "jailPass":
      p.jailPass += 1;
      break;
    case "payEach": {
      for (const other of alive(s)) {
        if (other.id === p.id) continue;
        p.cash -= e.amount;
        other.cash += e.amount;
      }
      break;
    }
    case "collectEach": {
      for (const other of alive(s)) {
        if (other.id === p.id) continue;
        other.cash -= e.amount;
        p.cash += e.amount;
      }
      break;
    }
    case "repairs": {
      let bill = 0;
      for (const idx of ownedTiles(s, p.id)) {
        const h = s.holdings[String(idx)]!;
        bill += h.houses === 5 ? e.perTower : h.houses * e.perHouse;
      }
      p.cash -= bill;
      s.pot += bill;
      if (bill > 0) log(s, `${p.name} paid ₹${bill} in upkeep.`, "cash");
      break;
    }
  }
}

function resolveLanding(s: GameState, p: Player, diceSum: number) {
  const t = tileAt(p.pos);
  switch (t.kind) {
    case "start":
      p.cash += PASS_START_BONUS;
      log(s, `${p.name} landed on Launch Pad. Bonus ₹${PASS_START_BONUS}.`, "cash");
      break;
    case "estate":
    case "transit":
    case "utility": {
      const h = holding(s, p.pos);
      if (!h) {
        if (p.cash >= (t.price ?? 0)) {
          s.pendingBuy = { tile: p.pos, playerId: p.id };
        } else {
          startAuction(s, p.pos);
        }
      } else if (h.owner !== p.id && !h.mortgaged) {
        const rent = rentFor(s, p.pos, diceSum);
        pay(s, p.id, rent, h.owner);
        log(s, `${p.name} paid ₹${rent} rent at ${t.name}.`, "rent");
      }
      break;
    }
    case "tax":
      p.cash -= t.amount ?? 0;
      s.pot += t.amount ?? 0;
      log(s, `${p.name} paid ₹${t.amount} — ${t.name}.`, "cash");
      break;
    case "parking":
      if (s.pot > 0) {
        p.cash += s.pot;
        log(s, `${p.name} scooped the ₹${s.pot} Riverside pot!`, "cash");
        s.pot = 0;
      } else {
        log(s, `${p.name} takes a breather at Riverside Rest.`);
      }
      break;
    case "gotojail":
      sendToJail(s, p);
      break;
    case "event":
      drawCard(s, p, EVENT_CARDS, "Wildcard");
      break;
    case "reward":
      drawCard(s, p, REWARD_CARDS, "Civic Chest");
      break;
    case "jail":
      log(s, `${p.name} is just visiting the Holding Bay.`);
      break;
  }
}

/* ------------------------------------------------------------------ */
/* auction                                                             */
/* ------------------------------------------------------------------ */

function startAuction(s: GameState, tile: number) {
  const bidders = alive(s);
  if (bidders.length < 2) {
    s.pendingBuy = null;
    return;
  }
  s.pendingBuy = null;
  s.auction = {
    tile,
    highest: 0,
    highestBidder: null,
    turnIndex: s.turn,
    passed: [],
  };
  s.phase = "auction";
  log(s, `${tileAt(tile).name} goes to auction — opening bid ₹10.`, "auction");
  advanceAuction(s, false);
}

function auctionSeats(s: GameState) {
  return s.players.filter((p) => !p.bankrupt);
}

function advanceAuction(s: GameState, step = true) {
  const a = s.auction!;
  const seats = auctionSeats(s);
  const active = seats.filter((p) => !a.passed.includes(p.id));
  if (active.length <= 1) {
    finishAuction(s);
    return;
  }
  let guard = 0;
  do {
    if (step || guard > 0) a.turnIndex = (a.turnIndex + 1) % s.players.length;
    guard++;
    if (guard > s.players.length * 2) break;
    step = true;
  } while (
    s.players[a.turnIndex]!.bankrupt ||
    a.passed.includes(s.players[a.turnIndex]!.id)
  );
  s.turnEndsAt = Date.now() + 20_000;
}

function finishAuction(s: GameState) {
  const a = s.auction!;
  const t = tileAt(a.tile);
  if (a.highestBidder && a.highest > 0) {
    const winner = playerById(s, a.highestBidder)!;
    winner.cash -= a.highest;
    s.holdings[String(a.tile)] = { owner: winner.id, houses: 0, mortgaged: false };
    log(s, `${winner.name} won ${t.name} at auction for ₹${a.highest}.`, "auction");
  } else {
    log(s, `No bids for ${t.name}. It stays on the market.`, "auction");
  }
  s.auction = null;
  s.phase = "resolve";
  s.turnEndsAt = Date.now() + TURN_SECONDS * 1000;
}

/* ------------------------------------------------------------------ */
/* turn flow                                                           */
/* ------------------------------------------------------------------ */

function nextTurn(s: GameState) {
  s.pendingBuy = null;
  s.dice = null;
  s.doubles = 0;
  let guard = 0;
  do {
    s.turn = (s.turn + 1) % s.players.length;
    if (s.turn === 0) s.round += 1;
    guard++;
  } while (s.players[s.turn]!.bankrupt && guard <= s.players.length);
  s.phase = "roll";
  s.turnEndsAt = Date.now() + TURN_SECONDS * 1000;
}

const requireTurn = (s: GameState, playerId: string) => {
  if (s.phase === "over") fail("The match is over.");
  if (currentPlayer(s).id !== playerId) fail("It is not your turn.");
  return currentPlayer(s);
};

/* ------------------------------------------------------------------ */
/* build / mortgage                                                    */
/* ------------------------------------------------------------------ */

function groupHouseCounts(s: GameState, group: keyof typeof GROUPS) {
  return groupTiles(group).map((i) => holding(s, i)?.houses ?? 0);
}

function doBuild(s: GameState, p: Player, tile: number) {
  const t = tileAt(tile);
  if (t.kind !== "estate") fail("You can only build on estates.");
  const h = holding(s, tile);
  if (!h || h.owner !== p.id) fail("You do not own that estate.");
  if (h.mortgaged) fail("Lift the mortgage before building.");
  if (!ownsWholeGroup(s, p.id, t.group!)) fail(`You need every estate in ${GROUPS[t.group!].label}.`);
  if (groupTiles(t.group!).some((i) => holding(s, i)?.mortgaged)) fail("A district estate is mortgaged.");
  if (h.houses >= 5) fail("This estate already has a tower.");
  const counts = groupHouseCounts(s, t.group!);
  if (h.houses > Math.min(...counts)) fail("Build evenly across the district first.");
  if (p.cash < (t.buildCost ?? 0)) fail("Not enough cash to build.");
  p.cash -= t.buildCost ?? 0;
  h.houses += 1;
  log(s, `${p.name} built ${h.houses === 5 ? "a tower" : "a house"} on ${t.name}.`, "build");
}

function doSellHouse(s: GameState, p: Player, tile: number) {
  const t = tileAt(tile);
  const h = holding(s, tile);
  if (!h || h.owner !== p.id) fail("You do not own that estate.");
  if (h.houses <= 0) fail("Nothing to sell there.");
  const counts = groupHouseCounts(s, t.group!);
  if (h.houses < Math.max(...counts)) fail("Sell evenly across the district first.");
  h.houses -= 1;
  p.cash += Math.floor((t.buildCost ?? 0) / 2);
  log(s, `${p.name} sold a building on ${t.name}.`, "build");
}

function doMortgage(s: GameState, p: Player, tile: number) {
  const t = tileAt(tile);
  const h = holding(s, tile);
  if (!h || h.owner !== p.id) fail("You do not own that property.");
  if (h.mortgaged) fail("Already mortgaged.");
  if (h.houses > 0) fail("Sell the buildings first.");
  h.mortgaged = true;
  p.cash += Math.floor((t.price ?? 0) / 2);
  log(s, `${p.name} mortgaged ${t.name}.`, "mortgage");
}

function doUnmortgage(s: GameState, p: Player, tile: number) {
  const t = tileAt(tile);
  const h = holding(s, tile);
  if (!h || h.owner !== p.id) fail("You do not own that property.");
  if (!h.mortgaged) fail("That property is not mortgaged.");
  const cost = Math.ceil((t.price ?? 0) * 0.55);
  if (p.cash < cost) fail(`You need ₹${cost} to lift this mortgage.`);
  p.cash -= cost;
  h.mortgaged = false;
  log(s, `${p.name} lifted the mortgage on ${t.name}.`, "mortgage");
}

/* ------------------------------------------------------------------ */
/* main reducer                                                        */
/* ------------------------------------------------------------------ */

export function applyAction(prev: GameState, playerId: string, action: GameAction): GameState {
  const s = clone(prev);
  const me = playerById(s, playerId);
  if (!me) fail("You are not in this match.");
  if (me!.bankrupt && action.type !== "timeout") fail("You are out of the match.");

  switch (action.type) {
    case "roll": {
      const p = requireTurn(s, playerId);
      if (s.phase !== "roll") fail("You already rolled this turn.");
      const d: [number, number] = [1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)];
      s.dice = d;
      const sum = d[0] + d[1];
      const isDouble = d[0] === d[1];
      log(s, `${p.name} rolled ${d[0]} + ${d[1]} = ${sum}${isDouble ? " (double!)" : ""}.`, "dice");

      if (p.jail) {
        if (isDouble) {
          p.jail = false;
          p.jailTurns = 0;
          log(s, `${p.name} rolled doubles and walked free.`, "jail");
        } else {
          p.jailTurns += 1;
          if (p.jailTurns >= 3) {
            p.cash -= JAIL_FINE;
            s.pot += JAIL_FINE;
            p.jail = false;
            p.jailTurns = 0;
            log(s, `${p.name} paid the ₹${JAIL_FINE} fine after three tries.`, "jail");
          } else {
            s.phase = "resolve";
            s.turnEndsAt = Date.now() + TURN_SECONDS * 1000;
            return s;
          }
        }
      } else if (isDouble) {
        s.doubles += 1;
        if (s.doubles >= 3) {
          sendToJail(s, p);
          s.phase = "resolve";
          return s;
        }
      }

      moveTo(s, p, p.pos + sum, true);
      resolveLanding(s, p, sum);
      if ((s.phase as string) !== "auction") {
        s.phase = "resolve";
        s.turnEndsAt = Date.now() + TURN_SECONDS * 1000;
      }
      return s;
    }

    case "buy": {
      const p = requireTurn(s, playerId);
      if (!s.pendingBuy || s.pendingBuy.playerId !== p.id) fail("Nothing to buy right now.");
      const t = tileAt(s.pendingBuy.tile);
      if (p.cash < (t.price ?? 0)) fail("Not enough cash.");
      p.cash -= t.price ?? 0;
      s.holdings[String(t.index)] = { owner: p.id, houses: 0, mortgaged: false };
      log(s, `${p.name} bought ${t.name} for ₹${t.price}.`, "buy");
      s.pendingBuy = null;
      return s;
    }

    case "decline": {
      const p = requireTurn(s, playerId);
      if (!s.pendingBuy || s.pendingBuy.playerId !== p.id) fail("Nothing to decline.");
      startAuction(s, s.pendingBuy.tile);
      return s;
    }

    case "bid": {
      if (s.phase !== "auction" || !s.auction) fail("No auction running.");
      const a = s.auction;
      if (s.players[a.turnIndex]!.id !== playerId) fail("Wait for your bidding turn.");
      const amount = Math.floor(action.amount);
      if (!Number.isFinite(amount) || amount <= a.highest) fail(`Bid must beat ₹${a.highest}.`);
      if (amount > me!.cash) fail("You cannot bid more than your cash.");
      a.highest = amount;
      a.highestBidder = playerId;
      log(s, `${me!.name} bids ₹${amount}.`, "auction");
      advanceAuction(s);
      return s;
    }

    case "passBid": {
      if (s.phase !== "auction" || !s.auction) fail("No auction running.");
      const a = s.auction;
      if (s.players[a.turnIndex]!.id !== playerId) fail("Wait for your bidding turn.");
      if (!a.passed.includes(playerId)) a.passed.push(playerId);
      log(s, `${me!.name} passed.`, "auction");
      advanceAuction(s);
      return s;
    }

    case "build":
      doBuild(s, me!, action.tile);
      return s;
    case "sellHouse":
      doSellHouse(s, me!, action.tile);
      return s;
    case "mortgage":
      doMortgage(s, me!, action.tile);
      return s;
    case "unmortgage":
      doUnmortgage(s, me!, action.tile);
      return s;

    case "payJail": {
      const p = requireTurn(s, playerId);
      if (!p.jail) fail("You are not in the Holding Bay.");
      if (p.cash < JAIL_FINE) fail("Not enough cash for the fine.");
      p.cash -= JAIL_FINE;
      s.pot += JAIL_FINE;
      p.jail = false;
      p.jailTurns = 0;
      log(s, `${p.name} paid the ₹${JAIL_FINE} release fine.`, "jail");
      return s;
    }

    case "useJailPass": {
      const p = requireTurn(s, playerId);
      if (!p.jail) fail("You are not in the Holding Bay.");
      if (p.jailPass <= 0) fail("You have no pardon pass.");
      p.jailPass -= 1;
      p.jail = false;
      p.jailTurns = 0;
      log(s, `${p.name} used a pardon pass.`, "jail");
      return s;
    }

    case "endTurn": {
      const p = requireTurn(s, playerId);
      if (s.phase === "auction") fail("Finish the auction first.");
      if (s.phase === "roll") fail("Roll the dice first.");
      if (s.pendingBuy) startAuction(s, s.pendingBuy.tile);
      if ((s.phase as string) === "auction") return s;
      if (p.cash < 0) fail("Settle your debt by selling or mortgaging, or resign.");
      if (s.dice && s.dice[0] === s.dice[1] && !p.jail && s.doubles > 0 && s.doubles < 3) {
        s.phase = "roll";
        s.dice = null;
        s.turnEndsAt = Date.now() + TURN_SECONDS * 1000;
        log(s, `${p.name} rolled doubles — one more turn.`, "dice");
        return s;
      }
      nextTurn(s);
      return s;
    }

    case "resign": {
      bankrupt(s, playerId, null);
      if (s.phase !== "over" && currentPlayer(s).bankrupt) nextTurn(s);
      return s;
    }

    case "proposeTrade": {
      const o = action.offer;
      const to = playerById(s, o.to);
      if (!to || to.bankrupt || to.id === playerId) fail("Pick a live opponent.");
      if (o.giveCash < 0 || o.getCash < 0) fail("Cash amounts must be positive.");
      if (o.giveCash > me!.cash) fail("You do not have that much cash.");
      if (o.getCash > to.cash) fail("They do not have that much cash.");
      if (o.giveTiles.some((t) => ownerOf(s, t) !== playerId)) fail("You do not own everything you offered.");
      if (o.getTiles.some((t) => ownerOf(s, t) !== to.id)) fail("They do not own everything you requested.");
      if ([...o.giveTiles, ...o.getTiles].some((t) => (holding(s, t)?.houses ?? 0) > 0))
        fail("Sell buildings before trading an estate.");
      s.trades.push({ ...o, id: uid(), from: playerId, status: "pending" });
      log(s, `${me!.name} sent a trade offer to ${to.name}.`, "trade");
      return s;
    }

    case "respondTrade": {
      const offer = s.trades.find((t) => t.id === action.id && t.status === "pending");
      if (!offer) fail("That offer is gone.");
      if (offer.to !== playerId) fail("This offer is not for you.");
      const from = playerById(s, offer.from)!;
      if (!action.accept) {
        offer.status = "declined";
        log(s, `${me!.name} declined the trade from ${from.name}.`, "trade");
        return s;
      }
      if (offer.giveCash > from.cash || offer.getCash > me!.cash) fail("Cash no longer available.");
      if (offer.giveTiles.some((t) => ownerOf(s, t) !== from.id)) fail("Offer is stale.");
      if (offer.getTiles.some((t) => ownerOf(s, t) !== playerId)) fail("Offer is stale.");
      from.cash -= offer.giveCash;
      me!.cash += offer.giveCash;
      me!.cash -= offer.getCash;
      from.cash += offer.getCash;
      for (const t of offer.giveTiles) s.holdings[String(t)]!.owner = playerId;
      for (const t of offer.getTiles) s.holdings[String(t)]!.owner = from.id;
      offer.status = "accepted";
      log(s, `${me!.name} accepted a trade with ${from.name}.`, "trade");
      return s;
    }

    case "timeout": {
      if (s.turnEndsAt && Date.now() < s.turnEndsAt) return prev;
      if (s.phase === "auction" && s.auction) {
        const bidder = s.players[s.auction.turnIndex]!;
        if (!s.auction.passed.includes(bidder.id)) s.auction.passed.push(bidder.id);
        log(s, `${bidder.name} timed out and passed.`, "auction");
        advanceAuction(s);
        return s;
      }
      const p = currentPlayer(s);
      if (s.phase === "roll") return applyAction(s, p.id, { type: "roll" });
      if (s.pendingBuy) startAuction(s, s.pendingBuy.tile);
      if (s.phase === "auction") return s;
      if (p.cash < 0) {
        bankrupt(s, p.id, null);
        if (s.phase !== "over") nextTurn(s);
        return s;
      }
      log(s, `${p.name} ran out of time.`, "timer");
      nextTurn(s);
      return s;
    }
  }

  return s;
}

/* ------------------------------------------------------------------ */
/* solvency helper — called after every action on the server           */
/* ------------------------------------------------------------------ */

export function settleDebts(s: GameState): GameState {
  for (const p of s.players) {
    if (p.bankrupt || p.cash >= 0) continue;
    const worth = netWorth(s, p.id);
    // Bots and hopeless positions liquidate automatically.
    if (p.isBot || worth < 0) bankrupt(s, p.id, null);
  }
  checkWinner(s);
  return s;
}

export { TURN_SECONDS };
