import { supabase } from "@/integrations/supabase/client";

export type UploadBucket = "avatars" | "note-attachments" | "project-images";

const LIMITS: Record<UploadBucket, { maxBytes: number; mimeTypes: string[] }> = {
  avatars: { maxBytes: 2 * 1024 * 1024, mimeTypes: ["image/jpeg", "image/png", "image/webp", "image/gif"] },
  "note-attachments": {
    maxBytes: 10 * 1024 * 1024,
    mimeTypes: ["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"],
  },
  "project-images": { maxBytes: 5 * 1024 * 1024, mimeTypes: ["image/jpeg", "image/png", "image/webp", "image/gif"] },
};

/**
 * Uploads a file to the given bucket under a path scoped to the current
 * user (userId/randomUuid.ext), matching the storage.foldername(name)[1]
 * ownership check enforced by RLS in 20260824090000_storage_buckets.sql.
 * Returns the public URL on success, or throws with a message safe to
 * show the user directly.
 *
 * Client-side size/type checks here are for immediate feedback only —
 * the bucket's own file_size_limit/allowed_mime_types and the RLS
 * policies are what actually enforce this; a direct API call bypassing
 * this function still can't upload something the bucket itself rejects.
 */
export async function uploadFile(bucket: UploadBucket, file: File, userId: string): Promise<string> {
  const limit = LIMITS[bucket];
  if (!limit.mimeTypes.includes(file.type)) {
    throw new Error(`That file type isn't supported. Use: ${limit.mimeTypes.map((t) => t.split("/")[1]).join(", ")}`);
  }
  if (file.size > limit.maxBytes) {
    throw new Error(`File is too large — max ${Math.round(limit.maxBytes / (1024 * 1024))}MB`);
  }

  const ext = file.name.split(".").pop()?.toLowerCase() || "bin";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;

  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    contentType: file.type,
    upsert: false,
  });
  if (error) throw new Error(error.message);

  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

/** Best-effort delete — used when replacing an old file with a new one. */
export async function deleteFile(bucket: UploadBucket, publicUrl: string): Promise<void> {
  try {
    const marker = `/storage/v1/object/public/${bucket}/`;
    const idx = publicUrl.indexOf(marker);
    if (idx === -1) return;
    const path = publicUrl.slice(idx + marker.length);
    await supabase.storage.from(bucket).remove([path]);
  } catch {
    // non-critical — an orphaned file costs storage space, not correctness
  }
}
