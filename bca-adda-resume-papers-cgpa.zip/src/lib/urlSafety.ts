/**
 * Returns the URL unchanged if it's a valid https:// URL, or null if it's
 * empty, malformed, or uses any other scheme (javascript:, data:, vbscript:,
 * file:, about:, etc.). Used everywhere a user-supplied URL is later
 * rendered as a clickable link, to prevent stored XSS via dangerous URI
 * schemes. This is a client-side convenience check for immediate feedback —
 * the database also enforces the same https-only rule via a CHECK
 * constraint on profiles.avatar_url and subject_notes.url, so this
 * function being bypassed client-side (e.g. a direct API call) still
 * can't get an unsafe scheme past the database.
 */
export function sanitizeHttpsUrl(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== "https:") return null;
  } catch {
    return null;
  }
  return trimmed;
}
