import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type SpectateOptions = {
  table: string; // e.g. "connect_four_games"
  code: string;
  enabled: boolean;
};

// Returns the current game state for any playing/finished game by code,
// updating in real time via postgres_changes. The caller is responsible
// for typing the returned `game` however it needs.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function useSpectate<T = any>({ table, code, enabled }: SpectateOptions) {
  const [game, setGame] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled || !code.trim()) return;
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError(null);
      const { data, error: err } = await (supabase as any)
        .from(table)
        .select("*")
        .eq("code", code.toUpperCase())
        .in("status", ["playing", "finished"])
        .maybeSingle();
      if (cancelled) return;
      setLoading(false);
      if (err) { setError(err.message); return; }
      if (!data) { setError("Room not found or not started yet"); return; }
      setGame(data as T);
    };

    load();
    return () => { cancelled = true; };
  }, [table, code, enabled]);

  // realtime subscription once we have the game id
  const gameId = (game as any)?.id;
  useEffect(() => {
    if (!gameId) return;
    const ch = supabase
      .channel(`spectate:${table}:${gameId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table, filter: `id=eq.${gameId}` },
        (payload) => setGame(payload.new as T),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [table, gameId]);

  return { game, loading, error };
}
