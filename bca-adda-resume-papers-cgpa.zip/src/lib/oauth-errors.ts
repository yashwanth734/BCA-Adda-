// Detailed classification + logging for OAuth (Google) sign-in failures.
// Kept framework-free so it can be used from any route or component.

export type OAuthFailureKind =
  | "cancelled"
  | "popup_blocked"
  | "network"
  | "provider_disabled"
  | "session"
  | "unknown";

export type OAuthFailure = {
  kind: OAuthFailureKind;
  /** Short, user-facing headline. */
  title: string;
  /** User-facing explanation of what happened. */
  message: string;
  /** Concrete retry steps the user can follow. */
  steps: string[];
  /** Raw message kept for logs / support. */
  raw: string;
};

function rawMessage(err: unknown): string {
  if (!err) return "Unknown error";
  if (typeof err === "string") return err;
  if (err instanceof Error) return err.message;
  if (typeof err === "object") {
    const o = err as Record<string, unknown>;
    const m = o.message ?? o.error_description ?? o.error ?? o.msg;
    if (typeof m === "string") return m;
    try {
      return JSON.stringify(o);
    } catch {
      return String(err);
    }
  }
  return String(err);
}

export function classifyOAuthError(err: unknown): OAuthFailure {
  const raw = rawMessage(err);
  const t = raw.toLowerCase();

  if (
    t.includes("cancel") ||
    t.includes("closed by user") ||
    t.includes("popup_closed") ||
    t.includes("window closed") ||
    t.includes("access_denied") ||
    t.includes("user denied") ||
    t.includes("aborted")
  ) {
    return {
      kind: "cancelled",
      title: "Google sign-in was cancelled",
      message:
        "The Google window closed before the sign-in finished, so no account was connected.",
      steps: [
        "Tap “Continue with Google” again.",
        "Pick your college Google account in the popup and press Continue.",
        "Don't close or switch away from the Google window until it closes on its own.",
      ],
      raw,
    };
  }

  if (t.includes("popup") && (t.includes("block") || t.includes("open"))) {
    return {
      kind: "popup_blocked",
      title: "Your browser blocked the Google window",
      message: "The sign-in popup could not open, so Google never loaded.",
      steps: [
        "Allow popups for this site in your browser's address-bar settings.",
        "Turn off any popup/ad blocker for this page.",
        "Then tap “Continue with Google” again.",
      ],
      raw,
    };
  }

  if (
    t.includes("failed to fetch") ||
    t.includes("networkerror") ||
    t.includes("network request failed") ||
    t.includes("timeout") ||
    t.includes("timed out")
  ) {
    return {
      kind: "network",
      title: "Connection problem during sign-in",
      message: "We couldn't reach Google because the network dropped.",
      steps: [
        "Check your Wi-Fi or mobile data.",
        "Reload the page.",
        "Try “Continue with Google” once more, or use email + password below.",
      ],
      raw,
    };
  }

  if (t.includes("unsupported provider") || t.includes("provider is not enabled")) {
    return {
      kind: "provider_disabled",
      title: "Google sign-in isn't available right now",
      message: "The Google provider is not enabled for this app.",
      steps: [
        "Use email and password to sign in for now.",
        "Let the admin know Google sign-in is turned off.",
      ],
      raw,
    };
  }

  if (t.includes("session") || t.includes("token")) {
    return {
      kind: "session",
      title: "Your session couldn't be saved",
      message:
        "Google approved the sign-in but the session couldn't be stored in this browser.",
      steps: [
        "Turn off private/incognito mode, or allow cookies and site data.",
        "Reload the page and try again.",
      ],
      raw,
    };
  }

  return {
    kind: "unknown",
    title: "Google sign-in didn't complete",
    message: "Something went wrong on the way back from Google.",
    steps: [
      "Try “Continue with Google” again.",
      "If it keeps failing, sign in with email and password instead.",
    ],
    raw,
  };
}

type LogContext = Record<string, unknown>;

/** Structured console log so failures are visible in the browser console. */
export function logAuthEvent(event: string, context: LogContext = {}) {
  const payload = {
    scope: "auth",
    event,
    at: new Date().toISOString(),
    url: typeof window !== "undefined" ? window.location.href : undefined,
    ...context,
  };
  // eslint-disable-next-line no-console
  console.info("[auth]", JSON.stringify(payload));
}

export function logAuthFailure(event: string, failure: OAuthFailure, context: LogContext = {}) {
  const payload = {
    scope: "auth",
    event,
    kind: failure.kind,
    raw: failure.raw,
    at: new Date().toISOString(),
    url: typeof window !== "undefined" ? window.location.href : undefined,
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : undefined,
    ...context,
  };
  // eslint-disable-next-line no-console
  console.error("[auth] failure", JSON.stringify(payload));
}
