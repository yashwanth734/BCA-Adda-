import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Grants the caller the 'teacher' role when they present the school's
 * teacher access code. The code lives in a server-only secret, so a student
 * can never self-assign the role from the browser.
 */
export const claimTeacherRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { code: string }) => {
    const code = String(input?.code ?? "").trim();
    if (!code) throw new Error("Teacher access code is required");
    return { code };
  })
  .handler(async ({ data, context }) => {
    const expected = process.env["TEACHER_ACCESS_CODE"];
    if (!expected) throw new Error("Teacher access is not configured yet");
    if (data.code !== expected) throw new Error("Invalid teacher access code");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: context.userId, role: "teacher" });

    // Ignore duplicate (already a teacher)
    if (error && !error.message.includes("duplicate")) throw new Error(error.message);

    return { ok: true as const };
  });
