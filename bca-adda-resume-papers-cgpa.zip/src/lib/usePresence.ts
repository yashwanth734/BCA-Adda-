import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

// Tracks which user IDs are currently online using Supabase Realtime presence.
// All authenticated users join the same presence channel on mount; the hook
// exposes a Set of online user IDs so any component can check presence cheaply.
export function usePresence(userId: string | undefined) {
  const [onlineIds, setOnlineIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!userId) return;

    const channel = supabase.channel("online_users", {
      config: { presence: { key: userId } },
    });

    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState<{ userId: string }>();
        const ids = new Set<string>();
        for (const presences of Object.values(state)) {
          for (const p of presences) ids.add(p.userId);
        }
        setOnlineIds(ids);
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await channel.track({ userId });
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  const isOnline = (id: string) => onlineIds.has(id);
  return { onlineIds, isOnline };
}
