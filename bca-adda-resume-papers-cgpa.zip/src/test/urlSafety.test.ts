/**
 * sanitizeHttpsUrl — verification suite.
 *
 * This is the client-side half of the HIGH-01 stored-XSS remediation
 * (subject_notes.url / profiles.avatar_url rendered as <a href>/<img src>
 * without a scheme check). The database also enforces https-only via a
 * CHECK constraint (see 20260821094500_fix_url_scheme_xss.sql), so this
 * function being correct is defense-in-depth, not the only layer — but it
 * should still reject every dangerous scheme on its own.
 */
import { describe, it, expect } from "vitest";
import { sanitizeHttpsUrl } from "@/lib/urlSafety";

describe("sanitizeHttpsUrl", () => {
  it("accepts a plain https URL unchanged", () => {
    expect(sanitizeHttpsUrl("https://example.com/resource.pdf")).toBe(
      "https://example.com/resource.pdf",
    );
  });

  it("accepts an https URL with query params and fragment", () => {
    const url = "https://drive.google.com/file/d/abc123/view?usp=sharing";
    expect(sanitizeHttpsUrl(url)).toBe(url);
  });

  it("trims surrounding whitespace", () => {
    expect(sanitizeHttpsUrl("  https://example.com  ")).toBe("https://example.com");
  });

  it("returns null for empty or whitespace-only input", () => {
    expect(sanitizeHttpsUrl("")).toBeNull();
    expect(sanitizeHttpsUrl("   ")).toBeNull();
  });

  it("rejects javascript: URIs", () => {
    expect(sanitizeHttpsUrl("javascript:alert(document.cookie)")).toBeNull();
    expect(sanitizeHttpsUrl("JavaScript:alert(1)")).toBeNull(); // case-insensitive scheme
  });

  it("rejects data: URIs", () => {
    expect(sanitizeHttpsUrl("data:text/html,<script>alert(1)</script>")).toBeNull();
  });

  it("rejects vbscript: URIs", () => {
    expect(sanitizeHttpsUrl("vbscript:msgbox(1)")).toBeNull();
  });

  it("rejects file: URIs", () => {
    expect(sanitizeHttpsUrl("file:///etc/passwd")).toBeNull();
  });

  it("rejects about: URIs", () => {
    expect(sanitizeHttpsUrl("about:blank")).toBeNull();
  });

  it("rejects plain http (not https)", () => {
    expect(sanitizeHttpsUrl("http://example.com")).toBeNull();
  });

  it("rejects malformed input that isn't a valid URL at all", () => {
    expect(sanitizeHttpsUrl("not a url")).toBeNull();
    expect(sanitizeHttpsUrl("://broken")).toBeNull();
  });

  it("rejects a scheme-confusion attempt disguised as a path", () => {
    // this parses as a relative-looking string with no scheme at all,
    // which the URL constructor rejects outright (no base to resolve against)
    expect(sanitizeHttpsUrl("//evil.com/javascript:alert(1)")).toBeNull();
  });
});
