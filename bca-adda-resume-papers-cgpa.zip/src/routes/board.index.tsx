import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Crown, Dices, Loader2, LogIn, Plus, Trophy, Users } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { bgCreateRoom, bgJoinRoom } from "@/lib/board/board.functions";
import { lobbyBotsOf, type RoomRow } from "@/lib/board/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/board/")({
  head: () => ({
    meta: [
      { title: "Trade City Lobby — Start or Join a Match" },
      {
        name: "description",
        content:
          "Create a private table, join with a room code, or hop into an open Trade City match with friends and bots.",
      },
      { property: "og:title", content: "Trade City Lobby" },
      { property: "og:description", content: "Start or join a live property-trading match." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BoardHome,
});

type Profile = { username: string; full_name: string | null; semester: number | null };

function BoardHome() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const createRoom = useServerFn(bgCreateRoom);
  const joinRoom = useServerFn(bgJoinRoom);

  const [name, setName] = useState("Trade City table");
  const [isPrivate, setIsPrivate] = useState(false);
  const [maxPlayers, setMaxPlayers] = useState<2 | 3 | 4 | 6 | 8>(4);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState<RoomRow[]>([]);
  const [history, setHistory] = useState<RoomRow[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data: rooms } = await supabase
        .from("bg_rooms")
        .select("*")
        .eq("status", "lobby")
        .eq("is_private", false)
        .order("created_at", { ascending: false })
        .limit(12);
      if (alive) setOpen((rooms ?? []) as unknown as RoomRow[]);

      if (!user) return;
      const [{ data: prof }, { data: mine }] = await Promise.all([
        supabase.from("profiles").select("username, full_name, semester").eq("id", user.id).maybeSingle(),
        supabase.from("bg_room_members").select("room_id").eq("user_id", user.id),
      ]);
      if (!alive) return;
      setProfile((prof as Profile) ?? null);
      const ids = (mine ?? []).map((m) => m.room_id);
      if (ids.length) {
        const { data: past } = await supabase
          .from("bg_rooms")
          .select("*")
          .in("id", ids)
          .eq("status", "finished")
          .order("updated_at", { ascending: false })
          .limit(10);
        if (alive) setHistory((past ?? []) as unknown as RoomRow[]);
      }
    };
    void load();
    const t = setInterval(() => void load(), 15000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [user]);

  const wins = useMemo(
    () => history.filter((r) => r.winner_id === user?.id).length,
    [history, user],
  );

  const create = async () => {
    setBusy(true);
    try {
      const res = await createRoom({ data: { name, isPrivate, maxPlayers } });
      void navigate({ to: "/board/$roomId", params: { roomId: res.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not create the table.");
    } finally {
      setBusy(false);
    }
  };

  const join = async (roomCode: string) => {
    setBusy(true);
    try {
      const res = await joinRoom({ data: { code: roomCode } });
      void navigate({ to: "/board/$roomId", params: { roomId: res.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not join that table.");
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="paper mx-auto max-w-md rounded-2xl p-8 text-center">
        <h1 className="font-display text-2xl">Sign in to play Trade City</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Matches are synced live, so you need an account to hold a seat.
        </p>
        <Button asChild className="mt-4">
          <Link to="/auth">
            <LogIn className="mr-2 h-4 w-4" /> Sign in
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="paper rounded-2xl p-6">
        <h1 className="font-display text-3xl">Trade City</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Buy districts, build towers, run auctions and squeeze rent out of your friends. Add
          bots if the table is short on players.
        </p>
        <div className="mt-4 flex flex-wrap gap-4 text-sm">
          <span className="chip">
            <Crown className="mr-1 inline h-3.5 w-3.5" />
            {profile?.full_name || profile?.username || "Trader"}
          </span>
          <span className="chip">
            <Trophy className="mr-1 inline h-3.5 w-3.5" /> {wins} wins
          </span>
          <span className="chip">
            <Dices className="mr-1 inline h-3.5 w-3.5" /> {history.length} finished matches
          </span>
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="paper rounded-2xl p-5">
          <h2 className="font-display text-xl">New table</h2>
          <div className="mt-3 space-y-3">
            <Input value={name} maxLength={40} onChange={(e) => setName(e.target.value)} />
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-muted-foreground">Seats</span>
              {([2, 3, 4, 6, 8] as const).map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setMaxPlayers(n)}
                  className={cn(
                    "h-9 w-9 rounded-full border border-border text-sm font-semibold",
                    maxPlayers === n && "border-ink bg-ink text-cream",
                  )}
                >
                  {n}
                </button>
              ))}
            </div>
            <label className="flex items-center gap-3 text-sm">
              <Switch checked={isPrivate} onCheckedChange={setIsPrivate} />
              Private table (join by code only)
            </label>
            <Button className="w-full" onClick={create} disabled={busy}>
              <Plus className="mr-2 h-4 w-4" /> Create table
            </Button>
          </div>
        </section>

        <section className="paper rounded-2xl p-5">
          <h2 className="font-display text-xl">Join with a code</h2>
          <div className="mt-3 flex gap-2">
            <Input
              value={code}
              maxLength={8}
              placeholder="e.g. K7QW2"
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              className="uppercase tracking-[0.3em]"
            />
            <Button onClick={() => join(code)} disabled={busy || code.trim().length < 3}>
              Join
            </Button>
          </div>

          <h3 className="mt-6 text-sm font-bold">Open tables</h3>
          {open.length === 0 ? (
            <p className="mt-2 text-xs text-muted-foreground">
              Nothing public right now — create one above.
            </p>
          ) : (
            <ul className="mt-2 space-y-2">
              {open.map((r) => (
                <li
                  key={r.id}
                  className="flex items-center justify-between rounded-xl border border-border p-2.5"
                >
                  <div>
                    <p className="text-sm font-semibold">{r.name}</p>
                    <p className="text-xs text-muted-foreground">
                      <Users className="mr-1 inline h-3 w-3" />
                      up to {r.max_players} · {lobbyBotsOf(r).length} bots · code {r.code}
                    </p>
                  </div>
                  <Button size="sm" variant="outline" disabled={busy} onClick={() => join(r.code)}>
                    Join
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="paper rounded-2xl p-5">
        <h2 className="font-display text-xl">Match history</h2>
        {history.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">No finished matches yet.</p>
        ) : (
          <ul className="mt-3 divide-y divide-border">
            {history.map((r) => (
              <li key={r.id} className="flex items-center justify-between py-2 text-sm">
                <span className="font-semibold">{r.name}</span>
                <span className="text-xs text-muted-foreground">
                  {r.winner_id === user.id ? "🏆 you won" : r.winner_id ? "lost" : "bot won"} ·{" "}
                  {r.updated_at ? new Date(r.updated_at).toLocaleDateString() : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
