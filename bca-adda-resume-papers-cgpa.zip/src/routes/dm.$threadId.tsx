import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Send, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/dm/$threadId")({
  component: DmThreadPage,
});

const DM_PAGE_SIZE = 50;

type Thread = { id: string; user_a: string; user_b: string };
type DmMessage = { id: string; thread_id: string; sender_id: string; content: string; created_at: string };
type Profile = { id: string; username: string; full_name: string | null; avatar_url: string | null };

function DmThreadPage() {
  const { threadId } = Route.useParams();
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const prependAnchorRef = useRef<{ scrollHeight: number; scrollTop: number } | null>(null);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [hasMoreOlder, setHasMoreOlder] = useState(true);

  const threadQ = useQuery({
    queryKey: ["dm_thread", threadId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("dm_threads").select("id,user_a,user_b").eq("id", threadId).maybeSingle();
      if (error) throw error;
      return data as Thread | null;
    },
  });

  const otherUserId = threadQ.data ? (threadQ.data.user_a === user?.id ? threadQ.data.user_b : threadQ.data.user_a) : null;

  const otherProfileQ = useQuery({
    queryKey: ["profile", otherUserId],
    enabled: !!otherUserId,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("id,username,full_name,avatar_url").eq("id", otherUserId!).maybeSingle();
      if (error) throw error;
      return data as Profile | null;
    },
  });

  const messagesQ = useQuery({
    queryKey: ["dm_messages", threadId],
    queryFn: async () => {
      // Fetch newest-first, reverse for display — same fix as the main
      // channel chat: ascending+limit silently returns the OLDEST
      // messages once a conversation passes the page size, which for an
      // ongoing DM thread between two friends is a real, reachable case
      // over time, not just a theoretical one.
      const { data, error } = await supabase
        .from("dm_messages")
        .select("id,thread_id,sender_id,content,created_at")
        .eq("thread_id", threadId)
        .order("created_at", { ascending: false })
        .limit(DM_PAGE_SIZE);
      if (error) throw error;
      return (data ?? []).reverse() as DmMessage[];
    },
  });

  useEffect(() => {
    setHasMoreOlder(true);
  }, [threadId]);

  const loadOlderMessages = async () => {
    const current = messagesQ.data;
    if (!current || current.length === 0 || loadingOlder || !hasMoreOlder) return;
    setLoadingOlder(true);
    const oldest = current[0];
    const { data, error } = await supabase
      .from("dm_messages")
      .select("id,thread_id,sender_id,content,created_at")
      .eq("thread_id", threadId)
      .lt("created_at", oldest.created_at)
      .order("created_at", { ascending: false })
      .limit(DM_PAGE_SIZE);
    setLoadingOlder(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    const older = (data ?? []).reverse();
    if (older.length < DM_PAGE_SIZE) setHasMoreOlder(false);
    if (older.length === 0) return;
    if (scrollRef.current) {
      prependAnchorRef.current = {
        scrollHeight: scrollRef.current.scrollHeight,
        scrollTop: scrollRef.current.scrollTop,
      };
    }
    qc.setQueryData<DmMessage[]>(["dm_messages", threadId], (existing) => {
      const seen = new Set((existing ?? []).map((m) => m.id));
      return [...older.filter((m) => !seen.has(m.id)), ...(existing ?? [])];
    });
  };

  useEffect(() => {
    const ch = supabase
      .channel(`dm_messages:${threadId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "dm_messages", filter: `thread_id=eq.${threadId}` },
        (payload) => {
          const newMsg = payload.new as DmMessage;
          // append rather than invalidate-and-refetch-everything, so a
          // new message arriving doesn't wipe out older messages the
          // user already loaded via "Load older messages"
          qc.setQueryData<DmMessage[]>(["dm_messages", threadId], (old) => {
            if (!old) return [newMsg];
            if (old.some((m) => m.id === newMsg.id)) return old;
            return [...old, newMsg];
          });
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [threadId, qc]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (prependAnchorRef.current) {
      const { scrollHeight: prevHeight, scrollTop: prevTop } = prependAnchorRef.current;
      prependAnchorRef.current = null;
      el.scrollTop = el.scrollHeight - prevHeight + prevTop;
      return;
    }
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messagesQ.data]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!draft.trim() || !user) return;
    setSending(true);
    const content = draft.trim();
    setDraft("");
    const { error } = await supabase.from("dm_messages").insert({ thread_id: threadId, sender_id: user.id, content });
    setSending(false);
    if (error) {
      toast.error(error.message);
      setDraft(content);
      return;
    }
    qc.invalidateQueries({ queryKey: ["dm_messages", threadId] });
  };

  if (loading || threadQ.isLoading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to view this chat</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  if (!threadQ.data) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Conversation not found</h1>
          <Link to="/friends" className="mt-4 inline-block font-semibold hover:underline">
            Back to friends
          </Link>
        </div>
      </div>
    );
  }

  const other = otherProfileQ.data;
  const messages = messagesQ.data ?? [];

  return (
    <div className="flex h-screen flex-col">
      <header className="flex items-center gap-3 border-b border-border px-4 py-3">
        <Link to="/friends" className="rounded-full p-2 hover:bg-secondary" aria-label="Back to friends">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        {other && (
          <Link to="/profile/$userId" params={{ userId: other.id }} className="flex items-center gap-2.5">
            <div className="grid h-9 w-9 place-items-center overflow-hidden rounded-full bg-coral text-sm font-bold text-primary-foreground">
              {other.avatar_url ? (
                <img src={other.avatar_url} alt="" className="h-full w-full object-cover" />
              ) : (
                (other.full_name ?? other.username).charAt(0).toUpperCase()
              )}
            </div>
            <span className="font-display text-lg font-bold">{other.full_name ?? other.username}</span>
          </Link>
        )}
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        {messages.length === 0 ? (
          <p className="mt-10 text-center text-sm text-muted-foreground">Say hi 👋</p>
        ) : (
          <ul className="mx-auto flex max-w-2xl flex-col gap-3">
            {hasMoreOlder && (
              <li className="flex justify-center pb-1">
                <button
                  onClick={loadOlderMessages}
                  disabled={loadingOlder}
                  className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary disabled:opacity-60"
                >
                  {loadingOlder ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
                  {loadingOlder ? "Loading…" : "Load older messages"}
                </button>
              </li>
            )}
            {messages.map((m) => {
              const isMe = m.sender_id === user.id;
              return (
                <li key={m.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] whitespace-pre-wrap break-words rounded-2xl px-4 py-2.5 text-[15px] leading-relaxed ${
                      isMe ? "rounded-tr-sm bg-ink text-cream" : "rounded-tl-sm border border-border bg-card"
                    }`}
                  >
                    {m.content}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <form onSubmit={send} className="border-t border-border p-3">
        <div className="mx-auto flex max-w-2xl items-end gap-2">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(e as unknown as React.FormEvent);
              }
            }}
            rows={1}
            maxLength={2000}
            placeholder="Message…"
            className="max-h-32 flex-1 resize-none rounded-2xl border-2 border-input bg-cream px-4 py-2.5 text-[15px] outline-none focus:border-ink"
          />
          <button
            disabled={sending || !draft.trim()}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-coral text-primary-foreground disabled:opacity-50"
          >
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </button>
        </div>
      </form>
    </div>
  );
}
