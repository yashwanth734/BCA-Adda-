import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";
import { TeacherMfaGate } from "@/components/TeacherMfaGate";
import {
  ArrowLeft,
  Plus,
  Check,
  X,
  Trash2,
  CalendarDays,
  Target,
  Loader2,
  Download,
  Eye,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/attendance")({
  head: () => ({
    meta: [
      { title: "Attendance Tracker — BCA Adda" },
      { name: "description", content: "Teachers mark attendance, students track their own subject-wise percentage." },
      { property: "og:title", content: "Attendance Tracker — BCA Adda" },
      { property: "og:description", content: "Teachers mark attendance, students track their own subject-wise percentage." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AttendancePage,
});

type Subject = { id: string; name: string; target_percent: number };
type Rec = { id: string; subject_id: string; date: string; status: "present" | "absent"; user_id: string };
type Student = { id: string; username: string; full_name: string | null };

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function AttendancePage() {
  const { user, loading } = useAuth();
  const { isTeacher, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [date, setDate] = useState(todayISO());
  const [newSubject, setNewSubject] = useState("");
  const [newTarget, setNewTarget] = useState(75);
  const [adding, setAdding] = useState(false);
  const [studentId, setStudentId] = useState<string>("");

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth", search: { mode: "signin" } });
  }, [loading, user, navigate]);

  // Teachers pick a student; students always view themselves.
  const targetUserId = isTeacher ? studentId : user?.id ?? "";

  const studentsQ = useQuery({
    queryKey: ["students"],
    enabled: !!user && isTeacher,
    staleTime: 5 * 60_000,
    queryFn: async (): Promise<Student[]> => {
      const { data: roles, error: rErr } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "student");
      if (rErr) throw rErr;
      const ids = (roles ?? []).map((r) => r.user_id);
      if (ids.length === 0) return [];
      const { data, error } = await supabase
        .from("profiles")
        .select("id,username,full_name")
        .in("id", ids)
        .order("username");
      if (error) throw error;
      return (data ?? []) as Student[];
    },
  });

  useEffect(() => {
    if (isTeacher && !studentId && studentsQ.data?.length) setStudentId(studentsQ.data[0].id);
  }, [isTeacher, studentId, studentsQ.data]);

  const subjectsQ = useQuery({
    queryKey: ["subjects"],
    enabled: !!user,
    staleTime: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("subjects")
        .select("id,name,target_percent")
        .order("created_at");
      if (error) throw error;
      return (data ?? []) as Subject[];
    },
  });

  const recordsQ = useQuery({
    queryKey: ["attendance", targetUserId],
    enabled: !!user && !!targetUserId,
    staleTime: 30_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("attendance_records")
        .select("id,subject_id,date,status,user_id")
        .eq("user_id", targetUserId)
        .order("date", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Rec[];
    },
  });

  // realtime updates so attendance changes show up without refreshing
  useEffect(() => {
    if (!user || !targetUserId) return;
    const channel = supabase
      .channel(`attendance:${targetUserId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "attendance_records",
          filter: `user_id=eq.${targetUserId}`,
        },
        () => qc.invalidateQueries({ queryKey: ["attendance", targetUserId] }),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "subjects" },
        () => qc.invalidateQueries({ queryKey: ["subjects"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, targetUserId, qc]);

  const subjects = subjectsQ.data ?? [];
  const records = recordsQ.data ?? [];

  const stats = useMemo(() => {
    const map = new Map<string, { total: number; present: number; onDate?: "present" | "absent" }>();
    for (const s of subjects) map.set(s.id, { total: 0, present: 0 });
    for (const r of records) {
      const m = map.get(r.subject_id);
      if (!m) continue;
      m.total++;
      if (r.status === "present") m.present++;
      if (r.date === date) m.onDate = r.status;
    }
    return map;
  }, [subjects, records, date]);

  async function addSubject(e: React.FormEvent) {
    e.preventDefault();
    const name = newSubject.trim();
    if (!name || !user || !isTeacher) return;
    setAdding(true);
    const { error } = await supabase.from("subjects").insert({
      user_id: user.id,
      name: name.slice(0, 60),
      target_percent: Math.max(1, Math.min(100, newTarget)),
    });
    setAdding(false);
    if (error) return toast.error(error.message);
    setNewSubject("");
    setNewTarget(75);
    qc.invalidateQueries({ queryKey: ["subjects"] });
  }

  async function mark(subjectId: string, status: "present" | "absent") {
    if (!user || !isTeacher) return;
    if (!targetUserId) return toast.error("Pick a student first.");
    const existing = records.find((r) => r.subject_id === subjectId && r.date === date);

    // Tapping the same status again clears the record for that day.
    if (existing && existing.status === status) {
      const { error } = await supabase
        .from("attendance_records")
        .delete()
        .eq("subject_id", subjectId)
        .eq("user_id", targetUserId)
        .eq("date", date);
      if (error) return toast.error(error.message);
      qc.invalidateQueries({ queryKey: ["attendance", targetUserId] });
      return;
    }

    // Idempotent write: repeated submissions for the same student/subject/date
    // update the existing row instead of raising a duplicate key error.
    const { error } = await supabase
      .from("attendance_records")
      .upsert(
        { subject_id: subjectId, user_id: targetUserId, date, status, marked_by: user.id },
        { onConflict: "user_id,subject_id,date" },
      );

    if (error) {
      // Safety net if another teacher wrote the same row a moment earlier.
      if (error.code === "23505") {
        const { error: updateError } = await supabase
          .from("attendance_records")
          .update({ status, marked_by: user.id })
          .eq("subject_id", subjectId)
          .eq("user_id", targetUserId)
          .eq("date", date);
        if (updateError) return toast.error(updateError.message);
      } else {
        return toast.error(error.message);
      }
    }
    qc.invalidateQueries({ queryKey: ["attendance", targetUserId] });
  }


  async function removeSubject(id: string) {
    if (!isTeacher) return;
    if (!confirm("Delete this subject and all its records?")) return;
    const { error } = await supabase.from("subjects").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["subjects"] });
    qc.invalidateQueries({ queryKey: ["attendance"] });
  }

  function csvCell(v: string | number) {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  async function exportCsv() {
    if (!user || !targetUserId) return;
    if (records.length === 0) {
      toast.error("No attendance records to export yet.");
      return;
    }
    const { data: profile } = await supabase
      .from("profiles")
      .select("username, full_name")
      .eq("id", targetUserId)
      .maybeSingle();
    const student = profile?.full_name || profile?.username || targetUserId;

    const nameById = new Map(subjects.map((s) => [s.id, s]));
    const rows = [...records].sort((a, b) =>
      a.date === b.date
        ? (nameById.get(a.subject_id)?.name ?? "").localeCompare(nameById.get(b.subject_id)?.name ?? "")
        : a.date.localeCompare(b.date),
    );

    const header = ["Date", "Student", "Subject", "Target %", "Status"];
    const lines = [
      header.join(","),
      ...rows.map((r) =>
        [
          r.date,
          student,
          nameById.get(r.subject_id)?.name ?? "(deleted subject)",
          nameById.get(r.subject_id)?.target_percent ?? "",
          r.status === "present" ? "Present" : "Absent",
        ]
          .map(csvCell)
          .join(","),
      ),
    ];

    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `attendance-${todayISO()}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${rows.length} records`);
  }

  if (loading || !user || roleLoading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <TeacherMfaGate>
    <div className="min-h-screen grain-bg">
      <header className="mx-auto flex max-w-4xl items-center justify-between px-5 py-4">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>
        <div className="flex items-center gap-2 font-display text-lg font-bold">
          <CalendarDays className="h-5 w-5" /> Attendance
        </div>
        <Link to="/chat" className="text-sm font-semibold hover:underline">Chat</Link>
      </header>

      <main className="mx-auto max-w-4xl px-5 pb-16">
        <span className="chip">
          {isTeacher ? <Target className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
          {isTeacher ? "Teacher — mark attendance" : "Student — view only"}
        </span>
        <h1 className="mt-3 text-4xl sm:text-5xl">
          {isTeacher ? "Class attendance" : "Your attendance"}
        </h1>
        <p className="mt-2 max-w-xl text-muted-foreground">
          {isTeacher
            ? "Pick a student and a date, then tap Present or Absent for each subject."
            : "Only your teacher can mark attendance. Here's how you're tracking against each subject's target."}
        </p>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          {isTeacher && (
            <>
              <label className="text-sm font-semibold">Student</label>
              <select
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 text-sm font-semibold focus:border-ink focus:outline-none"
              >
                {(studentsQ.data ?? []).length === 0 && <option value="">No students yet</option>}
                {(studentsQ.data ?? []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.full_name || s.username}
                  </option>
                ))}
              </select>
            </>
          )}
          <label className="text-sm font-semibold">Date</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 text-sm font-semibold focus:border-ink focus:outline-none"
          />
          <button
            type="button"
            onClick={exportCsv}
            className="ml-auto inline-flex items-center gap-1.5 rounded-full border-2 border-ink/20 bg-cream px-4 py-2 text-sm font-semibold hover:bg-secondary"
          >
            <Download className="h-4 w-4" /> Export CSV
          </button>
        </div>

        {isTeacher && (
          <form onSubmit={addSubject} className="paper mt-5 flex flex-wrap items-end gap-3 p-4">
            <div className="flex-1 min-w-[180px]">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Subject name</div>
              <input
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                placeholder="e.g. Data Structures"
                maxLength={60}
                className="mt-1 w-full rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 focus:border-ink focus:outline-none"
              />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Target %</div>
              <input
                type="number"
                min={1}
                max={100}
                value={newTarget}
                onChange={(e) => setNewTarget(Number(e.target.value) || 75)}
                className="mt-1 w-24 rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 focus:border-ink focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={adding || !newSubject.trim()}
              className="inline-flex items-center gap-1.5 rounded-full bg-ink px-4 py-2 font-semibold text-cream disabled:opacity-50"
            >
              <Plus className="h-4 w-4" /> Add
            </button>
          </form>
        )}

        <div className="mt-6 space-y-3">
          {subjects.length === 0 && (
            <div className="paper p-6 text-center text-muted-foreground">
              {isTeacher ? "No subjects yet. Add your first one above." : "Your teacher hasn't added any subjects yet."}
            </div>
          )}
          {subjects.map((s) => {
            const st = stats.get(s.id) ?? { total: 0, present: 0, onDate: undefined as any };
            const pct = st.total > 0 ? Math.round((st.present / st.total) * 100) : 0;
            const meeting = pct >= s.target_percent;
            const barColor = meeting ? "bg-mint" : "bg-coral";
            return (
              <div key={s.id} className="paper p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-display text-xl truncate">{s.name}</div>
                    <div className="mt-0.5 text-xs text-muted-foreground">
                      Target {s.target_percent}% · {st.present}/{st.total} classes
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-display text-2xl ${meeting ? "text-mint" : "text-coral"}`}>
                      {pct}%
                    </div>
                    {!meeting && st.total > 0 && (
                      <div className="text-[10px] uppercase tracking-wider text-coral font-semibold">
                        Below target
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className={`h-full ${barColor} transition-all`}
                    style={{ width: `${Math.min(100, pct)}%` }}
                  />
                </div>

                <div className="mt-4 flex items-center justify-between gap-2">
                  {isTeacher ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => mark(s.id, "present")}
                        className={`inline-flex items-center gap-1 rounded-full border-2 px-3 py-1.5 text-sm font-semibold ${
                          st.onDate === "present"
                            ? "border-mint bg-mint text-foreground"
                            : "border-ink/20 bg-cream hover:bg-secondary"
                        }`}
                      >
                        <Check className="h-4 w-4" /> Present
                      </button>
                      <button
                        onClick={() => mark(s.id, "absent")}
                        className={`inline-flex items-center gap-1 rounded-full border-2 px-3 py-1.5 text-sm font-semibold ${
                          st.onDate === "absent"
                            ? "border-coral bg-coral text-cream"
                            : "border-ink/20 bg-cream hover:bg-secondary"
                        }`}
                      >
                        <X className="h-4 w-4" /> Absent
                      </button>
                    </div>
                  ) : (
                    <div className="text-sm font-semibold text-muted-foreground">
                      {st.onDate === "present" && <span className="text-mint">✓ Marked present on {date}</span>}
                      {st.onDate === "absent" && <span className="text-coral">✕ Marked absent on {date}</span>}
                      {!st.onDate && <span>No class marked on {date}</span>}
                    </div>
                  )}
                  {isTeacher && (
                    <button
                      onClick={() => removeSubject(s.id)}
                      className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs text-muted-foreground hover:text-coral"
                      aria-label={`Delete ${s.name}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
    </TeacherMfaGate>
  );
}
