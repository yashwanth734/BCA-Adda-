import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { claimTeacherRole } from "@/lib/roles.functions";
import { toast } from "sonner";
import { ArrowLeft, Loader2, RefreshCw, AlertTriangle, GraduationCap, BookOpen, Eye, EyeOff, Mail, CheckCircle2 } from "lucide-react";
import {
  classifyOAuthError,
  logAuthEvent,
  logAuthFailure,
  type OAuthFailure,
} from "@/lib/oauth-errors";




const searchSchema = z.object({
  mode: z.enum(["signin", "signup"]).optional(),
  next: z.string().optional(),
});

// Only allow same-origin relative paths as post-auth destinations.
function safeNext(next: string | undefined): string | null {
  if (!next || !next.startsWith("/") || next.startsWith("//")) return null;
  return next;
}

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  component: AuthPage,
});

function AuthPage() {
  const { mode: initialMode, next } = Route.useSearch();
  const [mode, setMode] = useState<"signin" | "signup">(initialMode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [accountType, setAccountType] = useState<"student" | "teacher">("student");
  const [teacherCode, setTeacherCode] = useState("");

  const [busy, setBusy] = useState(false);
  const [justSignedUp, setJustSignedUp] = useState(false);
  const [googleFailure, setGoogleFailure] = useState<OAuthFailure | null>(null);
  const [googleAttempts, setGoogleAttempts] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotBusy, setForgotBusy] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const claimTeacher = useServerFn(claimTeacherRole);
  const handledRef = useRef(false);
  const nextPath = safeNext(next);


  const signInWithGoogle = async () => {
    const attempt = googleAttempts + 1;
    setGoogleAttempts(attempt);
    setGoogleFailure(null);
    setBusy(true);
    const startedAt = Date.now();
    logAuthEvent("google_sign_in_start", { attempt, next: nextPath ?? "/chat" });
    try {
      setJustSignedUp(true);
      if (accountType === "teacher" && teacherCode.trim()) {
        sessionStorage.setItem("pending_teacher_code", teacherCode.trim());
      }

      const redirectUri = `${window.location.origin}/auth?next=${encodeURIComponent(
        nextPath ?? "/chat",
      )}`;

      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: redirectUri },
      });
      if (error) throw error;

      logAuthEvent("google_sign_in_returned", {
        attempt,
        ms: Date.now() - startedAt,
      });
      // supabase-js redirects the browser to Google itself, so this line
      // rarely runs before navigation happens.
    } catch (err) {
      const failure = classifyOAuthError(err);
      setJustSignedUp(false);
      setGoogleFailure(failure);
      logAuthFailure("google_sign_in_failed", failure, {
        attempt,
        ms: Date.now() - startedAt,
      });
      toast.error(failure.title, { description: failure.message });
      setBusy(false);
    }
  };


  useEffect(() => {
    if (loading || !user || handledRef.current) return;
    handledRef.current = true;

    const run = async () => {
      const pendingCode =
        teacherCode.trim() ||
        (typeof window !== "undefined"
          ? sessionStorage.getItem("pending_teacher_code") ?? ""
          : "");

      if (pendingCode) {
        try {
          await claimTeacher({ data: { code: pendingCode } });
          toast.success("Teacher access granted");
          if (typeof window !== "undefined") sessionStorage.removeItem("pending_teacher_code");
          navigate({ to: "/moderation", replace: true });
          return;
        } catch (err) {
          if (typeof window !== "undefined") sessionStorage.removeItem("pending_teacher_code");
          toast.error(
            err instanceof Error ? err.message : "Could not verify teacher access code",
          );
        }
      }

      if (nextPath) {
        navigate({ to: nextPath, replace: true });
      } else if (justSignedUp) {
        navigate({ to: "/chat", search: { welcome: 1, channel: "general" } });
      } else {
        navigate({ to: "/chat" });
      }
    };

    void run();
  }, [user, loading, navigate, justSignedUp, nextPath, teacherCode, claimTeacher]);


  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const origin = typeof window !== "undefined" ? window.location.origin : "";
        const redirectTo = nextPath
          ? `${origin}${nextPath}`
          : `${origin}/chat?welcome=1&channel=general`;
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: redirectTo,
            data: { full_name: fullName },
          },
        });
        if (error) throw error;
        setJustSignedUp(true);
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          // Only log a login_failure when Supabase's auth server actually
          // processed and rejected the request (it responds with a status
          // code either way) — not for plain network failures, which have
          // no status and are already surfaced by the ConnectionWatchdog
          // instead. Fire-and-forget: never awaited into the error path,
          // never lets a logging hiccup affect the sign-in error shown to
          // the user.
          if (typeof (error as { status?: number }).status === "number") {
            void (supabase as any).rpc("log_login_failure", { _email: email });
          }
          throw error;
        }
        // login_success is now logged automatically by a database trigger
        // reacting to auth.users.last_sign_in_at changing — not by the
        // client, so it can't be forged or omitted by calling the API directly.
        toast.success("Welcome back!");
      }

    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong";
      toast.error(message);
    } finally {
      setBusy(false);
    }
  };

  const submitForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotBusy(true);
    try {
      const origin = typeof window !== "undefined" ? window.location.origin : "";
      const { error } = await supabase.auth.resetPasswordForEmail(forgotEmail, {
        redirectTo: `${origin}/reset-password`,
      });
      if (error) throw error;
      setForgotSent(true);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Couldn't send the reset email";
      toast.error(message);
    } finally {
      setForgotBusy(false);
    }
  };

  const closeForgot = () => {
    setForgotOpen(false);
    setForgotSent(false);
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-md">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>

        <div className="paper mt-6 p-7">
          <div className="flex items-center gap-2 font-display text-xl font-bold">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-ink text-cream">B</span>
            BCA Adda
          </div>

          {forgotOpen ? (
            <ForgotPasswordPanel
              email={forgotEmail}
              setEmail={setForgotEmail}
              busy={forgotBusy}
              sent={forgotSent}
              onSubmit={submitForgotPassword}
              onBack={closeForgot}
            />
          ) : (
          <>
          <h1 className="mt-5 text-3xl">
            {mode === "signup" ? "Join the squad" : "Welcome back"}
          </h1>
          <p className="mt-1 text-muted-foreground">
            {accountType === "teacher"
              ? "Teacher access needs your college access code."
              : mode === "signup"
                ? "Create a free account to start chatting."
                : "Sign in to jump back into the rooms."}
          </p>

          <div className="mt-5 grid grid-cols-2 gap-2 rounded-2xl border-2 border-input bg-cream p-1.5">
            {([
              { key: "student", label: "Student", Icon: BookOpen },
              { key: "teacher", label: "Teacher", Icon: GraduationCap },
            ] as const).map(({ key, label, Icon }) => (
              <button
                key={key}
                type="button"
                onClick={() => setAccountType(key)}
                aria-pressed={accountType === key}
                className={`inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
                  accountType === key ? "bg-ink text-cream" : "hover:bg-secondary"
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === "signup" && (
              <div>
                <label className="text-sm font-medium">Full name</label>
                <input
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Riya Sharma"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            )}

            {accountType === "teacher" ? (
              <div>
                <label className="text-sm font-medium">Teacher access code</label>
                <input
                  required
                  value={teacherCode}
                  onChange={(e) => setTeacherCode(e.target.value)}
                  placeholder="Given by your college admin"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
                <p className="mt-1.5 text-xs text-muted-foreground">
                  Verified on the server — students can&apos;t grant themselves teacher access.
                </p>
              </div>
            ) : (
              mode === "signup" && (
                <p className="rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 text-xs text-muted-foreground">
                  🎓 New accounts join as students. Switch to the Teacher tab if you
                  have a college access code.
                </p>
              )
            )}



            <div>
              <label className="text-sm font-medium">Email</label>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@college.edu"
                autoComplete="email"
                className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Password</label>
                {mode === "signin" && (
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(email);
                      setForgotOpen(true);
                    }}
                    className="text-xs font-semibold text-muted-foreground hover:text-foreground hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative mt-1.5">
                <input
                  required
                  type={showPassword ? "text" : "password"}
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  autoComplete={mode === "signup" ? "new-password" : "current-password"}
                  className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 pr-11 outline-none focus:border-ink"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <button
              disabled={busy}
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-6 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}
              {mode === "signup" ? "Create account" : "Sign in"}
            </button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <div className="h-px flex-1 bg-border" />
            or
            <div className="h-px flex-1 bg-border" />
          </div>

          <button
            type="button"
            disabled={busy}
            onClick={signInWithGoogle}
            className="inline-flex w-full items-center justify-center gap-3 rounded-full border-2 border-ink bg-cream px-6 py-3 font-semibold hover:bg-secondary disabled:opacity-60"
          >
            <GoogleIcon />
            {googleFailure ? "Try Google again" : "Continue with Google"}
          </button>

          {googleFailure && (
            <div
              role="alert"
              className="mt-4 rounded-xl border-2 border-input bg-cream p-4 text-left"
            >
              <div className="flex items-center gap-2 font-semibold">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                {googleFailure.title}
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{googleFailure.message}</p>
              <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm">
                {googleFailure.steps.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ol>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={signInWithGoogle}
                  className="inline-flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-sm font-semibold text-cream disabled:opacity-60"
                >
                  <RefreshCw className={`h-4 w-4 ${busy ? "animate-spin" : ""}`} />
                  Retry Google sign-in
                </button>
                <button
                  type="button"
                  onClick={() => setGoogleFailure(null)}
                  className="rounded-full border-2 border-input px-4 py-2 text-sm font-semibold hover:bg-secondary"
                >
                  Use email instead
                </button>
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                Attempt {googleAttempts} · code: {googleFailure.kind}
              </p>
            </div>
          )}



          <p className="mt-5 text-center text-sm text-muted-foreground">
            {mode === "signup" ? "Already have an account?" : "New here?"}{" "}
            <button
              onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
              className="font-semibold text-foreground hover:underline"
            >
              {mode === "signup" ? "Sign in" : "Create one"}
            </button>
          </p>
          </>
          )}
        </div>
      </div>
    </div>
  );
}

function ForgotPasswordPanel({
  email,
  setEmail,
  busy,
  sent,
  onSubmit,
  onBack,
}: {
  email: string;
  setEmail: (v: string) => void;
  busy: boolean;
  sent: boolean;
  onSubmit: (e: React.FormEvent) => void;
  onBack: () => void;
}) {
  if (sent) {
    return (
      <div className="mt-5 text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-mint">
          <CheckCircle2 className="h-6 w-6" />
        </div>
        <h1 className="mt-4 text-2xl">Check your email</h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          We sent a password reset link to <strong className="text-foreground">{email}</strong>. Open it on this
          device to set a new password.
        </p>
        <button
          type="button"
          onClick={onBack}
          className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:underline"
        >
          <ArrowLeft className="h-4 w-4" /> Back to sign in
        </button>
      </div>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={onBack}
        className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back to sign in
      </button>
      <h1 className="mt-3 text-3xl">Reset your password</h1>
      <p className="mt-1 text-muted-foreground">
        Enter the email on your account and we'll send you a reset link.
      </p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <div>
          <label className="text-sm font-medium">Email</label>
          <div className="relative mt-1.5">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@college.edu"
              autoComplete="email"
              autoFocus
              className="w-full rounded-xl border-2 border-input bg-cream py-2.5 pl-10 pr-3.5 outline-none focus:border-ink"
            />
          </div>
        </div>
        <button
          disabled={busy}
          className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-6 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
        >
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}
          Send reset link
        </button>
      </form>
    </>
  );
}

function GoogleIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6 8-11.3 8a12 12 0 1 1 0-24c3 0 5.7 1.1 7.8 3l5.7-5.7A20 20 0 1 0 24 44c11 0 20-9 20-20 0-1.2-.1-2.4-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 16 19 13 24 13c3 0 5.7 1.1 7.8 3l5.7-5.7A20 20 0 0 0 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 10-2 13.6-5.2l-6.3-5.3a12 12 0 0 1-18-6.2L6.6 32.4A20 20 0 0 0 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.2-4 5.5l6.3 5.3C41 35.5 44 30.2 44 24c0-1.2-.1-2.4-.4-3.5z" />
    </svg>
  );
}

