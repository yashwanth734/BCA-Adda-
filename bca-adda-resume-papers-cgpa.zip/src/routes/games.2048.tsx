import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Trophy } from "lucide-react";

export const Route = createFileRoute("/games/2048")({
  head: () => ({
    meta: [
      { title: "2048 — Arcade" },
      { name: "description", content: "Slide tiles, combine numbers, chase 2048." },
      { property: "og:title", content: "2048" },
      { property: "og:description", content: "How high can you merge?" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Game2048,
});

const SIZE = 4;
type Board = number[][];

function emptyBoard(): Board {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
}

function addRandomTile(board: Board): Board {
  const empty: [number, number][] = [];
  board.forEach((row, r) => row.forEach((v, c) => { if (v === 0) empty.push([r, c]); }));
  if (empty.length === 0) return board;
  const [r, c] = empty[Math.floor(Math.random() * empty.length)];
  const next = board.map((row) => [...row]);
  next[r][c] = Math.random() < 0.9 ? 2 : 4;
  return next;
}

function slideRowLeft(row: number[]): { row: number[]; gained: number; moved: boolean } {
  const vals = row.filter((v) => v !== 0);
  const out: number[] = [];
  let gained = 0;
  for (let i = 0; i < vals.length; i++) {
    if (vals[i] === vals[i + 1]) {
      out.push(vals[i] * 2);
      gained += vals[i] * 2;
      i++;
    } else {
      out.push(vals[i]);
    }
  }
  while (out.length < SIZE) out.push(0);
  const moved = out.some((v, i) => v !== row[i]);
  return { row: out, gained, moved };
}

function rotateBoard(board: Board): Board {
  const next = emptyBoard();
  for (let r = 0; r < SIZE; r++) for (let c = 0; c < SIZE; c++) next[c][SIZE - 1 - r] = board[r][c];
  return next;
}

function move(board: Board, dir: "left" | "right" | "up" | "down") {
  let b = board;
  let rotations = 0;
  if (dir === "up") rotations = 3;
  else if (dir === "right") rotations = 2;
  else if (dir === "down") rotations = 1;
  for (let i = 0; i < rotations; i++) b = rotateBoard(b);

  let gained = 0;
  let moved = false;
  const result = b.map((row) => {
    const r = slideRowLeft(row);
    gained += r.gained;
    if (r.moved) moved = true;
    return r.row;
  });

  let out = result;
  for (let i = 0; i < (4 - rotations) % 4; i++) out = rotateBoard(out);
  return { board: out, gained, moved };
}

function canMove(board: Board): boolean {
  for (const dir of ["left", "right", "up", "down"] as const) {
    if (move(board, dir).moved) return true;
  }
  return false;
}

const TILE_COLORS: Record<number, string> = {
  2: "bg-cream text-ink",
  4: "bg-gold/60 text-ink",
  8: "bg-gold text-ink",
  16: "bg-coral/70 text-cream",
  32: "bg-coral text-cream",
  64: "bg-coral text-cream",
  128: "bg-violet/70 text-cream",
  256: "bg-violet text-cream",
  512: "bg-violet text-cream",
  1024: "bg-ink text-cream",
  2048: "bg-neon text-ink",
};

function Game2048() {
  const [board, setBoard] = useState<Board>(() => addRandomTile(addRandomTile(emptyBoard())));
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [over, setOver] = useState(false);
  const [won, setWon] = useState(false);
  const [wonDismissed, setWonDismissed] = useState(false);
  const touchStart = useRef<{ x: number; y: number } | null>(null);

  const play = useCallback(
    (dir: "left" | "right" | "up" | "down") => {
      if (over) return;
      const result = move(board, dir);
      if (!result.moved) return;
      const next = addRandomTile(result.board);
      setBoard(next);
      setScore((s) => {
        const total = s + result.gained;
        setBest((b) => Math.max(b, total));
        return total;
      });
      if (result.board.flat().includes(2048)) setWon(true);
      if (!canMove(next)) setOver(true);
    },
    [board, over],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const map: Record<string, "left" | "right" | "up" | "down"> = {
        ArrowLeft: "left", a: "left",
        ArrowRight: "right", d: "right",
        ArrowUp: "up", w: "up",
        ArrowDown: "down", s: "down",
      };
      const dir = map[e.key];
      if (dir) {
        e.preventDefault();
        play(dir);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [play]);

  const reset = () => {
    setBoard(addRandomTile(addRandomTile(emptyBoard())));
    setScore(0);
    setOver(false);
    setWon(false);
    setWonDismissed(false);
  };

  const onTouchStart = (e: React.TouchEvent) => {
    touchStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (!touchStart.current) return;
    const dx = e.changedTouches[0].clientX - touchStart.current.x;
    const dy = e.changedTouches[0].clientY - touchStart.current.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
    if (Math.abs(dx) > Math.abs(dy)) play(dx > 0 ? "right" : "left");
    else play(dy > 0 ? "down" : "up");
    touchStart.current = null;
  };

  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl sm:text-5xl">
        <span className="text-coral">2048</span>
      </h1>
      <div className="mt-3 flex items-center gap-2">
        <span className="chip">Score {score}</span>
        <span className="chip bg-gold">
          <Trophy className="h-3.5 w-3.5" /> Best {best}
        </span>
      </div>

      <div
        className="relative mt-6 aspect-square w-full touch-none rounded-3xl border-2 border-ink bg-ink/90 p-2 shadow-pop"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        <div className="grid h-full w-full grid-cols-4 grid-rows-4 gap-2">
          {board.flat().map((v, i) => (
            <div
              key={i}
              className={`grid place-items-center rounded-xl font-display text-lg font-bold transition-all sm:text-2xl ${
                v ? TILE_COLORS[v] ?? "bg-neon text-ink" : "bg-cream/10"
              }`}
            >
              {v || ""}
            </div>
          ))}
        </div>

        {(over || (won && !wonDismissed)) && (
          <div className="absolute inset-0 grid place-items-center rounded-3xl bg-ink/85 text-center text-cream">
            <div>
              <p className="font-display text-2xl font-bold">{won ? "You hit 2048! 🎉" : "No more moves"}</p>
              <p className="mt-1 text-sm opacity-80">Score {score}</p>
              <button
                onClick={won && !over ? () => setWonDismissed(true) : reset}
                className="mt-4 inline-flex items-center justify-center rounded-full bg-coral px-6 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
              >
                {won && !over ? "Keep going" : "Try again"}
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="mt-4 text-center text-sm text-muted-foreground">
        Arrow keys / WASD, or swipe on mobile. Combine matching tiles to reach 2048.
      </p>
    </section>
  );
}
