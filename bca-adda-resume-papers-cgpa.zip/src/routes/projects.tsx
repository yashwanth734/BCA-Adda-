import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, FolderGit2, Plus, Loader2, ExternalLink, Github, Trash2, Search, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";
import { sanitizeHttpsUrl } from "@/lib/urlSafety";
import { uploadFile } from "@/lib/uploadFile";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — BCA Adda" },
      { name: "description", content: "Student projects and portfolios." },
    ],
  }),
  component: ProjectsPage,
});

type Project = {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  tech_stack: string[];
  github_url: string | null;
  demo_url: string | null;
  image_url: string | null;
  created_at: string;
  profiles: { username: string; full_name: string | null } | null;
};

function ProjectsPage() {
  const { user, loading } = useAuth();
  const { isTeacher } = useRole();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [techStack, setTechStack] = useState("");
  const [githubUrl, setGithubUrl] = useState("");
  const [demoUrl, setDemoUrl] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [uploadingImage, setUploadingImage] = useState(false);
  const [saving, setSaving] = useState(false);

  const projectsQ = useQuery({
    queryKey: ["projects"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("id,user_id,title,description,tech_stack,github_url,demo_url,image_url,created_at,profiles(username,full_name)")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return (data ?? []) as unknown as Project[];
    },
  });

  const projects = projectsQ.data ?? [];

  const filtered = useMemo(() => {
    if (!search.trim()) return projects;
    const q = search.toLowerCase();
    return projects.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        (p.description ?? "").toLowerCase().includes(q) ||
        p.tech_stack.some((t) => t.toLowerCase().includes(q)),
    );
  }, [projects, search]);

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to see student projects</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Give your project a title");
      return;
    }
    const github = githubUrl.trim() ? sanitizeHttpsUrl(githubUrl) : null;
    if (githubUrl.trim() && !github) return toast.error("GitHub link must be a valid https:// URL");
    const demo = demoUrl.trim() ? sanitizeHttpsUrl(demoUrl) : null;
    if (demoUrl.trim() && !demo) return toast.error("Demo link must be a valid https:// URL");

    setSaving(true);
    const { error } = await supabase.from("projects").insert({
      user_id: user.id,
      title: title.trim(),
      description: description.trim() || null,
      tech_stack: techStack.split(",").map((t) => t.trim()).filter(Boolean).slice(0, 12),
      github_url: github,
      demo_url: demo,
      image_url: imageUrl || null,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Project added");
    setTitle("");
    setDescription("");
    setTechStack("");
    setGithubUrl("");
    setDemoUrl("");
    setImageUrl("");
    setShowForm(false);
    qc.invalidateQueries({ queryKey: ["projects"] });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this project?")) return;
    const { error } = await supabase.from("projects").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["projects"] });
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-3xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
              <FolderGit2 className="h-6 w-6" />
            </div>
            <h1 className="text-4xl">Projects</h1>
          </div>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
          >
            <Plus className="h-4 w-4" /> Add project
          </button>
        </div>

        {showForm && (
          <form onSubmit={submit} className="paper mt-5 space-y-3 p-5">
            <div>
              <label className="text-sm font-medium">Title</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Campus Event Tracker"
                className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 2000))}
                rows={3}
                placeholder="What it does, what you learned building it…"
                className="mt-1.5 w-full resize-none rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Tech stack (comma separated)</label>
              <input
                value={techStack}
                onChange={(e) => setTechStack(e.target.value)}
                placeholder="React, Supabase, Tailwind"
                className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">GitHub link (optional)</label>
                <input
                  value={githubUrl}
                  onChange={(e) => setGithubUrl(e.target.value)}
                  placeholder="https://github.com/…"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Live demo (optional)</label>
                <input
                  value={demoUrl}
                  onChange={(e) => setDemoUrl(e.target.value)}
                  placeholder="https://…"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Screenshot (optional)</label>
              <div className="mt-1.5 flex items-center gap-3">
                <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border-2 border-ink bg-cream px-3.5 py-2.5 text-sm font-semibold hover:bg-secondary">
                  {uploadingImage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  {uploadingImage ? "Uploading…" : imageUrl ? "Replace image" : "Upload image"}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif"
                    className="hidden"
                    disabled={uploadingImage}
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      e.target.value = "";
                      if (!file) return;
                      setUploadingImage(true);
                      try {
                        const url = await uploadFile("project-images", file, user.id);
                        setImageUrl(url);
                      } catch (err) {
                        toast.error(err instanceof Error ? err.message : "Upload failed");
                      } finally {
                        setUploadingImage(false);
                      }
                    }}
                  />
                </label>
                {imageUrl && <img src={imageUrl} alt="" className="h-12 w-12 rounded-lg object-cover" />}
              </div>
            </div>
            <button
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 font-semibold text-cream disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Add project
            </button>
          </form>
        )}

        <div className="paper mt-5 p-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search projects, tech…"
              className="w-full rounded-xl border-2 border-input bg-cream py-2.5 pl-10 pr-3.5 outline-none focus:border-ink"
            />
          </div>
        </div>

        {projectsQ.isLoading ? (
          <div className="mt-8 grid place-items-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <p className="mt-8 text-center text-muted-foreground">
            {projects.length === 0 ? "No projects shared yet — be the first!" : "Nothing matches that search."}
          </p>
        ) : (
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            {filtered.map((p) => {
              const canDelete = p.user_id === user.id || isTeacher;
              return (
                <div key={p.id} className="paper overflow-hidden p-0">
                  {p.image_url && <img src={p.image_url} alt="" className="h-40 w-full object-cover" />}
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-lg font-bold">{p.title}</h3>
                      {canDelete && (
                        <button onClick={() => remove(p.id)} className="shrink-0 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-coral" aria-label="Delete">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                    {p.description && <p className="mt-1.5 text-sm text-muted-foreground">{p.description}</p>}
                    {p.tech_stack.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {p.tech_stack.map((t) => (
                          <span key={t} className="chip">{t}</span>
                        ))}
                      </div>
                    )}
                    <div className="mt-3 flex flex-wrap gap-3 text-sm">
                      {p.github_url && (
                        <a href={p.github_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-semibold text-coral hover:underline">
                          <Github className="h-3.5 w-3.5" /> Code
                        </a>
                      )}
                      {p.demo_url && (
                        <a href={p.demo_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-semibold text-coral hover:underline">
                          <ExternalLink className="h-3.5 w-3.5" /> Live demo
                        </a>
                      )}
                    </div>
                    <Link to="/profile/$userId" params={{ userId: p.user_id }} className="mt-3 block text-xs text-muted-foreground hover:underline">
                      by {p.profiles?.full_name ?? p.profiles?.username ?? "a student"}
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
