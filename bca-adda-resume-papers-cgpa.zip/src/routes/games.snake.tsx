import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Trophy } from "lucide-react";

export const Route = createFileRoute("/games/snake")({
  head: () => ({
    meta: [
      { title: "Snake — Arcade" },
      { name: "description", content: "Classic Snake. Eat, grow, don't hit yourself." },
      { property: "og:title", content: "Snake" },
      { property: "og:description", content: "How long can you get?" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Snake,
});

const GRID = 16;
const TICK_MS = 130;

type Point = { x: number; y: number };

function randomFood(body: Point[]): Point {
  while (true) {
    const p = { x: Math.floor(Math.random() * GRID), y: Math.floor(Math.random() * GRID) };
    if (!body.some((b) => b.x === p.x && b.y === p.y)) return p;
  }
}

function Snake() {
  const [snake, setSnake] = useState<Point[]>([{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }]);
  const [food, setFood] = useState<Point>(() => randomFood([{ x: 8, y: 8 }]));
  const [dir, setDir] = useState<Point>({ x: 1, y: 0 });
  const [running, setRunning] = useState(false);
  const [over, setOver] = useState(false);
  const [best, setBest] = useState(0);
  const dirRef = useRef(dir);
  const pendingRef = useRef<Point | null>(null);
  dirRef.current = dir;

  const reset = () => {
    const start = [{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }];
    setSnake(start);
    setFood(randomFood(start));
    setDir({ x: 1, y: 0 });
    pendingRef.current = null;
    setOver(false);
    setRunning(true);
  };

  const turn = useCallback((next: Point) => {
    const cur = dirRef.current;
    if (cur.x + next.x === 0 && cur.y + next.y === 0) return; // no 180s
    pendingRef.current = next;
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp" || e.key === "w") turn({ x: 0, y: -1 });
      else if (e.key === "ArrowDown" || e.key === "s") turn({ x: 0, y: 1 });
      else if (e.key === "ArrowLeft" || e.key === "a") turn({ x: -1, y: 0 });
      else if (e.key === "ArrowRight" || e.key === "d") turn({ x: 1, y: 0 });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [turn]);

  useEffect(() => {
    if (!running || over) return;
    const id = setInterval(() => {
      if (pendingRef.current) {
        setDir(pendingRef.current);
        dirRef.current = pendingRef.current;
        pendingRef.current = null;
      }
      setSnake((prev) => {
        const head = { x: prev[0].x + dirRef.current.x, y: prev[0].y + dirRef.current.y };
        const hitWall = head.x < 0 || head.y < 0 || head.x >= GRID || head.y >= GRID;
        const hitSelf = prev.some((s) => s.x === head.x && s.y === head.y);
        if (hitWall || hitSelf) {
          setRunning(false);
          setOver(true);
          setBest((b) => Math.max(b, prev.length - 3));
          return prev;
        }
        const ate = head.x === food.x && head.y === food.y;
        const body = [head, ...prev];
        if (ate) {
          setFood(randomFood(body));
        } else {
          body.pop();
        }
        return body;
      });
    }, TICK_MS);
    return () => clearInterval(id);
  }, [running, over, food]);

  const score = snake.length - 3;

  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl sm:text-5xl">
        <span className="text-coral">Snake</span>
      </h1>
      <div className="mt-3 flex items-center gap-2">
        <span className="chip">Score {score}</span>
        <span className="chip bg-gold">
          <Trophy className="h-3.5 w-3.5" /> Best {best}
        </span>
      </div>

      <div className="relative mt-6 aspect-square w-full overflow-hidden rounded-3xl border-2 border-ink bg-ink shadow-pop">
        <div
          className="absolute inset-0 grid"
          style={{ gridTemplateColumns: `repeat(${GRID}, 1fr)`, gridTemplateRows: `repeat(${GRID}, 1fr)` }}
        >
          {snake.map((s, i) => (
            <div
              key={i}
              className={`rounded-[3px] ${i === 0 ? "bg-neon" : "bg-mint"}`}
              style={{ gridColumnStart: s.x + 1, gridRowStart: s.y + 1 }}
            />
          ))}
          <div
            className="grid place-items-center rounded-full bg-coral text-xs"
            style={{ gridColumnStart: food.x + 1, gridRowStart: food.y + 1 }}
          >
            🍎
          </div>
        </div>

        {!running && (
          <div className="absolute inset-0 grid place-items-center bg-ink/80 text-center text-cream">
            <div>
              <p className="font-display text-2xl font-bold">{over ? "Game over" : "Ready?"}</p>
              {over && <p className="mt-1 text-sm opacity-80">You scored {score}</p>}
              <button
                onClick={reset}
                className="mt-4 inline-flex items-center justify-center rounded-full bg-coral px-6 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
              >
                {over ? "Play again" : "Start"}
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2 sm:hidden">
        <div />
        <button onClick={() => turn({ x: 0, y: -1 })} className="rounded-xl border-2 border-ink bg-cream py-3 font-bold">↑</button>
        <div />
        <button onClick={() => turn({ x: -1, y: 0 })} className="rounded-xl border-2 border-ink bg-cream py-3 font-bold">←</button>
        <button onClick={() => turn({ x: 0, y: 1 })} className="rounded-xl border-2 border-ink bg-cream py-3 font-bold">↓</button>
        <button onClick={() => turn({ x: 1, y: 0 })} className="rounded-xl border-2 border-ink bg-cream py-3 font-bold">→</button>
      </div>

      <p className="mt-4 hidden text-center text-sm text-muted-foreground sm:block">
        Use the arrow keys (or WASD) to steer.
      </p>
    </section>
  );
}
