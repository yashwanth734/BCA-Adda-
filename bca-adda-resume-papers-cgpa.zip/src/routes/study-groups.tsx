import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Users2, Plus, Loader2, MapPin, Hash } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/study-groups")({
  head: () => ({
    meta: [
      { title: "Study Groups — BCA Adda" },
      { name: "description", content: "Schedule and join study sessions with classmates." },
    ],
  }),
  component: StudyGroupsPage,
});

type Channel = { id: string; name: string };
type Group = {
  id: string;
  title: string;
  description: string | null;
  location: string | null;
  scheduled_at: string;
  channel_id: string | null;
  created_by: string;
  channels: { name: string } | null;
};

function StudyGroupsPage() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [scheduledAt, setScheduledAt] = useState("");
  const [channelId, setChannelId] = useState("");
  const [saving, setSaving] = useState(false);

  const channelsQ = useQuery({
    queryKey: ["channels-for-study-groups"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("channels").select("id,name").order("name");
      if (error) throw error;
      return (data ?? []) as Channel[];
    },
  });

  const groupsQ = useQuery({
    queryKey: ["study_groups"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("study_groups")
        .select("id,title,description,location,scheduled_at,channel_id,created_by,channels(name)")
        .gte("scheduled_at", new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString())
        .order("scheduled_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Group[];
    },
  });

  const rsvpsQ = useQuery({
    queryKey: ["study_group_rsvps_all"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("study_group_rsvps").select("group_id,user_id");
      if (error) throw error;
      return (data ?? []) as { group_id: string; user_id: string }[];
    },
  });

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to see study groups</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !scheduledAt) {
      toast.error("Add a title and a time");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("study_groups").insert({
      created_by: user.id,
      title: title.trim(),
      description: description.trim() || null,
      location: location.trim() || null,
      scheduled_at: new Date(scheduledAt).toISOString(),
      channel_id: channelId || null,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Study group scheduled");
    setTitle("");
    setDescription("");
    setLocation("");
    setScheduledAt("");
    setChannelId("");
    setShowForm(false);
    qc.invalidateQueries({ queryKey: ["study_groups"] });
  };

  const toggleRsvp = async (groupId: string, joined: boolean) => {
    if (joined) {
      const { error } = await supabase.from("study_group_rsvps").delete().eq("group_id", groupId).eq("user_id", user.id);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("study_group_rsvps").insert({ group_id: groupId, user_id: user.id });
      if (error) return toast.error(error.message);
    }
    qc.invalidateQueries({ queryKey: ["study_group_rsvps_all"] });
  };

  const groups = groupsQ.data ?? [];
  const rsvps = rsvpsQ.data ?? [];

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
              <Users2 className="h-6 w-6" />
            </div>
            <h1 className="text-4xl">Study Groups</h1>
          </div>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
          >
            <Plus className="h-4 w-4" /> Schedule
          </button>
        </div>

        {showForm && (
          <form onSubmit={submit} className="paper mt-5 space-y-3 p-5">
            <div>
              <label className="text-sm font-medium">Title</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="DBMS revision before the mid-sem"
                className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">When</label>
                <input
                  type="datetime-local"
                  value={scheduledAt}
                  onChange={(e) => setScheduledAt(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Where (room or link)</label>
                <input
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Library room 2 / meet.google.com/…"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Link to a channel (optional)</label>
              <select
                value={channelId}
                onChange={(e) => setChannelId(e.target.value)}
                className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              >
                <option value="">No channel</option>
                {(channelsQ.data ?? []).map((c) => (
                  <option key={c.id} value={c.id}>
                    #{c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium">Details (optional)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 1000))}
                rows={3}
                placeholder="What you'll cover…"
                className="mt-1.5 w-full resize-none rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <button
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 font-semibold text-cream disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Schedule it
            </button>
          </form>
        )}

        {groupsQ.isLoading ? (
          <div className="mt-8 grid place-items-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : groups.length === 0 ? (
          <p className="mt-8 text-center text-muted-foreground">No study groups scheduled yet — start one!</p>
        ) : (
          <ul className="mt-6 space-y-3">
            {groups.map((g) => {
              const attendeeCount = rsvps.filter((r) => r.group_id === g.id).length;
              const joined = rsvps.some((r) => r.group_id === g.id && r.user_id === user.id);
              const when = new Date(g.scheduled_at);
              return (
                <li key={g.id} className="paper p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="text-lg font-bold">{g.title}</h3>
                      <p className="text-sm font-semibold text-muted-foreground">
                        {when.toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleRsvp(g.id, joined)}
                      className={`shrink-0 rounded-full px-4 py-1.5 text-sm font-bold ${
                        joined ? "border-2 border-ink bg-cream" : "bg-coral text-primary-foreground"
                      }`}
                    >
                      {joined ? "Going ✓" : "Join"}
                    </button>
                  </div>
                  {g.description && <p className="mt-2 text-sm text-muted-foreground">{g.description}</p>}
                  <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
                    {g.location && (
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5" /> {g.location}
                      </span>
                    )}
                    {g.channels && (
                      <span className="inline-flex items-center gap-1">
                        <Hash className="h-3.5 w-3.5" /> {g.channels.name}
                      </span>
                    )}
                    <span>{attendeeCount} going</span>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
