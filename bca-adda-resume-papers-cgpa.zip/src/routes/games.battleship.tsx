import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, Copy, LogIn, Plus, Loader2, Crown, Ship, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SpectateEntry } from "@/components/SpectateEntry";
import { MatchmakingButton } from "@/components/MatchmakingButton";

export const Route = createFileRoute("/games/battleship")({
  head: () => ({
    meta: [
      { title: "Battleship — Play with a Friend" },
      { name: "description", content: "Real-time multiplayer Battleship — hide your fleet, hunt theirs down." },
      { property: "og:title", content: "Battleship" },
      { property: "og:description", content: "Place your fleet, then fire until someone's sunk." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BattleshipPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const SIZE = 6;
const CELLS = SIZE * SIZE;
const SHIP_LENGTHS = [3, 2, 2];
const TOTAL_SHIP_CELLS = SHIP_LENGTHS.reduce((a, b) => a + b, 0);

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  host_shots: number[];
  guest_shots: number[];
  host_ready: boolean;
  guest_ready: boolean;
  turn: number;
  phase: "placing" | "playing" | "finished";
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

function BattleshipPage() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`battleship_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "battleship_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <section className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </section>
    );
  }

  if (!user) {
    return (
      <section className="paper p-8 text-center">
        <Ship className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play Battleship</h2>
        <p className="mt-1 text-muted-foreground">You need an account to challenge a friend.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </section>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("battleship_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("battleship_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return (
      <section>
        <Link to="/games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          ← All games
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Ship className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-4xl">Battleship</h1>
            <p className="text-muted-foreground">Hide your fleet, sink theirs first. The tougher one.</p>
          </div>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          <div className="paper p-6">
            <h3 className="text-xl">Create a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
            <button
              disabled={busy}
              onClick={createGame}
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              New room
            </button>
          </div>
          <div className="paper p-6">
            <h3 className="text-xl">Join a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
            <div className="mt-5 flex gap-2">
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                maxLength={5}
                placeholder="ABCDE"
                className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
              />
              <button
                disabled={busy || joinCode.length < 4}
                onClick={joinGame}
                className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
              >
                <LogIn className="h-4 w-4" />
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="paper mt-6 p-5 text-sm text-muted-foreground">
          <strong className="text-foreground">How to play:</strong> Each player secretly places a 3-cell ship and
          two 2-cell ships (7 squares total) on a 6×6 grid. Then take turns firing at your opponent's grid. First
          to hit every one of their ship squares wins.
        </div>

      <div className="mt-4">
        <SpectateEntry table="battleship_games" label="a Battleship" onJoin={(g) => {} } />
      </div>

      <div className="mt-4">
        <MatchmakingButton gameType="battleship" gameLabel="Battleship" onMatchFound={() => {}} />
      </div>
    </section>
    );
  }


  return <GameRoom game={game} setGame={setGame} userId={user.id} />;
}

function GameRoom({ game, setGame, userId }: { game: Game; setGame: (g: Game | null) => void; userId: string }) {
  const isHost = game.host_id === userId;
  const [selected, setSelected] = useState<number[]>([]);
  const [placing, setPlacing] = useState(false);
  const [firing, setFiring] = useState<number | null>(null);

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const myReady = isHost ? game.host_ready : game.guest_ready;
  const myTurn = game.phase === "playing" && game.turn === (isHost ? 1 : 2);
  const myShots = isHost ? game.host_shots : game.guest_shots; // shots I've fired
  const oppShots = isHost ? game.guest_shots : game.host_shots; // shots fired at me
  const youWon = game.status === "finished" && game.winner_id === userId;

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  const leave = async () => {
    if (isHost) await db.rpc("battleship_leave_game", { _game_id: game.id });
    setGame(null);
  };

  const toggleCell = (i: number) => {
    if (myReady) return;
    setSelected((prev) => {
      if (prev.includes(i)) return prev.filter((c) => c !== i);
      if (prev.length >= TOTAL_SHIP_CELLS) return prev;
      return [...prev, i];
    });
  };

  const confirmPlacement = async () => {
    if (selected.length !== TOTAL_SHIP_CELLS) return;
    setPlacing(true);
    const { data, error } = await db.rpc("battleship_place_ships", { _game_id: game.id, _cells: selected });
    setPlacing(false);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  const fire = async (cell: number) => {
    if (!myTurn || firing !== null || oppShots[cell] !== 0) return;
    setFiring(cell);
    const { data, error } = await db.rpc("battleship_fire", { _game_id: game.id, _cell: cell });
    setFiring(null);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
          <Ship className="h-5 w-5" /> {game.code} <Copy className="h-4 w-4 opacity-60" />
        </button>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent && (
        <div className="paper mt-5 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
        </div>
      )}

      {!waitingForOpponent && game.phase === "placing" && (
        <div className="mt-6">
          <p className="text-center font-semibold text-muted-foreground">
            {myReady
              ? "Fleet placed — waiting for the other player…"
              : `Tap ${TOTAL_SHIP_CELLS} cells to place your fleet (${selected.length}/${TOTAL_SHIP_CELLS})`}
          </p>
          <PlacementGrid selected={selected} onToggle={toggleCell} disabled={myReady} />
          {!myReady && (
            <button
              onClick={confirmPlacement}
              disabled={selected.length !== TOTAL_SHIP_CELLS || placing}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-40"
            >
              {placing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Ship className="h-4 w-4" />}
              Confirm fleet
            </button>
          )}
        </div>
      )}

      {(game.phase === "playing" || game.phase === "finished") && (
        <div className="mt-6">
          <p className="text-center font-semibold text-muted-foreground">
            {game.last_message ?? (myTurn ? "Your shot" : "Opponent's shot")}
          </p>
          <div className="mt-3">
            <p className="mb-1.5 text-center text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Their waters — fire here
            </p>
            <FireGrid shots={oppShots} onFire={fire} disabled={!myTurn || game.phase === "finished"} firing={firing} />
          </div>
        </div>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">{youWon ? "You sank their fleet!" : "Your fleet went down — rematch?"}</h3>
          <button
            onClick={leave}
            className="mt-4 inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2 font-semibold text-cream"
          >
            <RotateCcw className="h-4 w-4" /> Back to lobby
          </button>
        </div>
      )}
    </section>
  );
}

function PlacementGrid({
  selected,
  onToggle,
  disabled,
}: {
  selected: number[];
  onToggle: (i: number) => void;
  disabled: boolean;
}) {
  return (
    <div className="mx-auto mt-4 max-w-sm rounded-3xl border-2 border-ink bg-[#1a3fa8] p-3 shadow-soft">
      <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)` }}>
        {Array.from({ length: CELLS }).map((_, i) => (
          <button
            key={i}
            onClick={() => onToggle(i)}
            disabled={disabled}
            className={`aspect-square rounded-md border-2 border-black/20 transition-colors ${
              selected.includes(i) ? "bg-gold" : "bg-cream/80 hover:bg-white"
            } disabled:cursor-not-allowed`}
          />
        ))}
      </div>
    </div>
  );
}

function FireGrid({
  shots,
  onFire,
  disabled,
  firing,
}: {
  shots: number[]; // 0 unfired, 1 miss, 2 hit
  onFire: (i: number) => void;
  disabled: boolean;
  firing: number | null;
}) {
  return (
    <div className="mx-auto max-w-sm rounded-3xl border-2 border-ink bg-[#1a3fa8] p-3 shadow-soft">
      <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)` }}>
        {shots.map((v, i) => (
          <button
            key={i}
            onClick={() => onFire(i)}
            disabled={disabled || v !== 0}
            className={`grid aspect-square place-items-center rounded-md border-2 border-black/20 text-sm transition-colors disabled:cursor-not-allowed ${
              v === 2 ? "bg-coral" : v === 1 ? "bg-cream/50" : "bg-cream/80 hover:enabled:bg-white"
            } ${firing === i ? "animate-pulse" : ""}`}
          >
            {v === 2 ? "🔥" : v === 1 ? "•" : ""}
          </button>
        ))}
      </div>
    </div>
  );
}
