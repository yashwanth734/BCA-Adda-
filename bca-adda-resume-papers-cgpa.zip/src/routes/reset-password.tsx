import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Loader2, Eye, EyeOff, KeyRound, CheckCircle2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  // Supabase sets a temporary "recovery" session as soon as this page loads
  // from the emailed link. Until that lands, we don't know yet whether the
  // link is valid — show a loading state rather than assuming either way.
  const [ready, setReady] = useState(false);
  const [validLink, setValidLink] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let settled = false;
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || (event === "SIGNED_IN" && session)) {
        settled = true;
        setValidLink(true);
        setReady(true);
      }
    });
    // If the recovery link already resolved before this listener attached,
    // fall back to checking for an existing session.
    supabase.auth.getSession().then(({ data }) => {
      if (!settled) {
        setValidLink(Boolean(data.session));
        setReady(true);
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    if (password !== confirm) {
      toast.error("Passwords don't match");
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      // password_change is now logged automatically by a database trigger
      // reacting to auth.users.encrypted_password changing.
      setDone(true);
      toast.success("Password updated");
      setTimeout(() => navigate({ to: "/chat" }), 1200);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Couldn't update your password";
      toast.error(message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-md">
        <Link to="/auth" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to sign in
        </Link>

        <div className="paper mt-6 p-7">
          <div className="flex items-center gap-2 font-display text-xl font-bold">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-ink text-cream">B</span>
            BCA Adda
          </div>

          {!ready ? (
            <div className="mt-8 grid place-items-center py-6">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : !validLink ? (
            <div className="mt-6 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-secondary">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <h1 className="mt-4 text-2xl">Link expired or invalid</h1>
              <p className="mt-1.5 text-sm text-muted-foreground">
                Password reset links only work once and expire after a while. Request a new one from the sign-in page.
              </p>
              <Link
                to="/auth"
                className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-coral px-6 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
              >
                Back to sign in
              </Link>
            </div>
          ) : done ? (
            <div className="mt-6 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-mint">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <h1 className="mt-4 text-2xl">Password updated</h1>
              <p className="mt-1.5 text-sm text-muted-foreground">Taking you back in…</p>
            </div>
          ) : (
            <>
              <h1 className="mt-5 text-3xl">Set a new password</h1>
              <p className="mt-1 text-muted-foreground">Choose something you haven't used before.</p>

              <form onSubmit={submit} className="mt-6 space-y-4">
                <div>
                  <label className="text-sm font-medium">New password</label>
                  <div className="relative mt-1.5">
                    <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <input
                      required
                      type={showPassword ? "text" : "password"}
                      minLength={8}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="At least 8 characters"
                      autoComplete="new-password"
                      autoFocus
                      className="w-full rounded-xl border-2 border-input bg-cream py-2.5 pl-10 pr-11 outline-none focus:border-ink"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Confirm password</label>
                  <input
                    required
                    type={showPassword ? "text" : "password"}
                    minLength={8}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="Type it again"
                    autoComplete="new-password"
                    className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                  />
                </div>
                <button
                  disabled={busy}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-6 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
                >
                  {busy && <Loader2 className="h-4 w-4 animate-spin" />}
                  Update password
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
