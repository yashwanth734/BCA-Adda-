import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  Bot,
  Check,
  Copy,
  Dices,
  DoorOpen,
  Flag,
  Loader2,
  Play,
  Trash2,
  Trophy,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AuctionModal } from "@/components/board/AuctionModal";
import { BoardGrid } from "@/components/board/BoardGrid";
import { ManagePanel } from "@/components/board/ManagePanel";
import { RoomChat } from "@/components/board/RoomChat";
import { TradeDialog } from "@/components/board/TradeDialog";
import { useAuth } from "@/lib/auth";
import {
  bgAct,
  bgAddBot,
  bgLeaveRoom,
  bgRemoveBot,
  bgSetReady,
  bgStartGame,
} from "@/lib/board/board.functions";
import { gameStateOf, lobbyBotsOf, money, tileAt } from "@/lib/board/client";
import { useRoom } from "@/lib/board/useRoom";
import type { BotLevel, GameAction, GameState } from "@/lib/board/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/board/$roomId")({
  head: () => ({
    meta: [
      { title: "Trade City Match Room — Live Board Game" },
      {
        name: "description",
        content:
          "Your live Trade City table: seats, ready toggle, dice controls, auctions, trades and table chat.",
      },
      { property: "og:title", content: "Trade City Match Room" },
      { property: "og:description", content: "Roll, buy, build and trade in real time." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RoomPage,
});

const LEVELS: BotLevel[] = ["easy", "medium", "hard", "expert"];

function RoomPage() {
  const { roomId } = Route.useParams();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { room, members, loading, missing } = useRoom(roomId);

  const act = useServerFn(bgAct);
  const addBot = useServerFn(bgAddBot);
  const removeBot = useServerFn(bgRemoveBot);
  const setReady = useServerFn(bgSetReady);
  const startGame = useServerFn(bgStartGame);
  const leaveRoom = useServerFn(bgLeaveRoom);

  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const timeoutSent = useRef(0);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);

  const state = gameStateOf(room);
  const bots = lobbyBotsOf(room);
  const me = members.find((m) => m.user_id === user?.id);
  const isHost = room?.host_id === user?.id;

  const run = useCallback(
    async (fn: () => Promise<unknown>) => {
      setBusy(true);
      try {
        await fn();
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "That move is not allowed.");
      } finally {
        setBusy(false);
      }
    },
    [],
  );

  const doAct = useCallback(
    (action: GameAction) => void run(() => act({ data: { roomId, action } })),
    [act, roomId, run],
  );

  // Turn clock — the active human nudges the server when time runs out.
  useEffect(() => {
    if (!state || !user || state.phase === "over" || !state.turnEndsAt) return;
    const actorId =
      state.phase === "auction" && state.auction
        ? state.players[state.auction.turnIndex]?.id
        : state.players[state.turn]?.id;
    if (actorId !== user.id) return;
    if (now < state.turnEndsAt) return;
    if (timeoutSent.current === state.turnEndsAt) return;
    timeoutSent.current = state.turnEndsAt;
    doAct({ type: "timeout" });
  }, [now, state, user, doAct]);

  if (authLoading || loading) {
    return (
      <div className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (missing || !room) {
    return (
      <div className="paper mx-auto max-w-md rounded-2xl p-8 text-center">
        <h1 className="font-display text-2xl">This table is gone</h1>
        <Button asChild className="mt-4">
          <Link to="/board">Back to lobby</Link>
        </Button>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="paper mx-auto max-w-md rounded-2xl p-8 text-center">
        <h1 className="font-display text-2xl">Sign in to take a seat</h1>
        <Button asChild className="mt-4">
          <Link to="/auth">Sign in</Link>
        </Button>
      </div>
    );
  }

  const leave = () =>
    void run(async () => {
      await leaveRoom({ data: { roomId } });
      void navigate({ to: "/board" });
    });

  const myName = me?.display_name ?? "Trader";
  const myColor = me?.color ?? "#f0567c";

  if (room.status === "lobby" || !state) {
    const seats = [
      ...members.map((m) => ({
        key: m.id,
        name: m.display_name ?? "Trader",
        color: m.color,
        ready: m.is_ready,
        bot: false as const,
        host: m.user_id === room.host_id,
        botId: null as string | null,
      })),
      ...bots.map((b) => ({
        key: b.id,
        name: `${b.name} · ${b.level}`,
        color: b.color,
        ready: true,
        bot: true as const,
        host: false,
        botId: b.id,
      })),
    ];
    const emptySeats = Math.max(0, room.max_players - seats.length);

    return (
      <div className="grid gap-5 lg:grid-cols-[1fr_20rem]">
        <section className="paper rounded-2xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="font-display text-2xl">{room.name}</h1>
              <p className="text-sm text-muted-foreground">
                {room.is_private ? "Private table" : "Open table"} · {seats.length}/
                {room.max_players} seats
              </p>
            </div>
            <button
              type="button"
              className="chip"
              onClick={() => {
                void navigator.clipboard.writeText(room.code);
                toast.success("Room code copied");
              }}
            >
              <Copy className="mr-1 inline h-3.5 w-3.5" /> {room.code}
            </button>
          </div>

          <ul className="mt-4 grid gap-2 sm:grid-cols-2">
            {seats.map((s) => (
              <li
                key={s.key}
                className="flex items-center gap-3 rounded-xl border border-border p-3"
              >
                <span
                  className="h-8 w-8 shrink-0 rounded-full border-2 border-ink"
                  style={{ background: s.color }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">
                    {s.name} {s.host ? "· host" : ""}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {s.bot ? "Bot opponent" : s.ready ? "Ready" : "Not ready"}
                  </p>
                </div>
                {s.ready && !s.bot ? <Check className="h-4 w-4 text-emerald-600" /> : null}
                {s.bot && isHost ? (
                  <button
                    type="button"
                    aria-label="Remove bot"
                    onClick={() =>
                      void run(() => removeBot({ data: { roomId, botId: s.botId! } }))
                    }
                  >
                    <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                  </button>
                ) : null}
              </li>
            ))}
            {Array.from({ length: emptySeats }).map((_, i) => (
              <li
                key={`empty-${i}`}
                className="rounded-xl border border-dashed border-border p-3 text-sm text-muted-foreground"
              >
                Empty seat
              </li>
            ))}
          </ul>

          {isHost ? (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-sm text-muted-foreground">
                <Bot className="mr-1 inline h-4 w-4" /> Add bot
              </span>
              {LEVELS.map((lvl) => (
                <Button
                  key={lvl}
                  size="sm"
                  variant="outline"
                  disabled={busy || seats.length >= room.max_players}
                  onClick={() => void run(() => addBot({ data: { roomId, level: lvl } }))}
                >
                  {lvl}
                </Button>
              ))}
            </div>
          ) : null}

          <div className="mt-5 flex flex-wrap gap-2">
            <Button
              variant={me?.is_ready ? "outline" : "default"}
              disabled={busy || !me}
              onClick={() => void run(() => setReady({ data: { roomId, ready: !me?.is_ready } }))}
            >
              {me?.is_ready ? "Not ready" : "I'm ready"}
            </Button>
            {isHost ? (
              <Button
                disabled={busy || seats.length < 2 || members.some((m) => !m.is_ready)}
                onClick={() => void run(() => startGame({ data: { roomId } }))}
              >
                <Play className="mr-2 h-4 w-4" /> Start match
              </Button>
            ) : null}
            <Button variant="ghost" disabled={busy} onClick={leave}>
              <DoorOpen className="mr-2 h-4 w-4" /> Leave
            </Button>
          </div>
        </section>

        <RoomChat
          roomId={roomId}
          userId={user.id}
          name={myName}
          color={myColor}
          variant="inline"
        />
      </div>
    );
  }

  return (
    <GameView
      state={state}
      userId={user.id}
      name={myName}
      color={myColor}
      roomId={roomId}
      busy={busy}
      act={doAct}
      onLeave={leave}
      selected={selected}
      setSelected={setSelected}
      now={now}
    />
  );
}

function GameView({
  state,
  userId,
  name,
  color,
  roomId,
  busy,
  act,
  onLeave,
  selected,
  setSelected,
  now,
}: {
  state: GameState;
  userId: string;
  name: string;
  color: string;
  roomId: string;
  busy: boolean;
  act: (a: GameAction) => void;
  onLeave: () => void;
  selected: number | null;
  setSelected: (n: number) => void;
  now: number;
}) {
  const current = state.players[state.turn];
  const myTurn = current?.id === userId && state.phase !== "auction";
  const me = state.players.find((p) => p.id === userId);
  const secondsLeft = state.turnEndsAt
    ? Math.max(0, Math.ceil((state.turnEndsAt - now) / 1000))
    : null;
  const pending = state.pendingBuy?.playerId === userId ? state.pendingBuy : null;
  const pendingTile = pending ? tileAt(pending.tile) : null;
  const selectedTile = selected !== null ? tileAt(selected) : null;
  const selectedHolding = selected !== null ? state.holdings[String(selected)] : undefined;

  const winner = useMemo(
    () => state.players.find((p) => p.id === state.winner),
    [state.players, state.winner],
  );

  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="space-y-3">
        <BoardGrid state={state} selected={selected} onSelect={setSelected} />
        {selectedTile ? (
          <div className="paper rounded-2xl p-3 text-sm">
            <p className="font-bold">{selectedTile.name}</p>
            <p className="text-xs text-muted-foreground">
              {selectedTile.price ? `Price ${money(selectedTile.price)} · ` : ""}
              {selectedTile.rent ? `Base rent ${money(selectedTile.rent[0]!)} · ` : ""}
              {selectedHolding
                ? `owned by ${state.players.find((p) => p.id === selectedHolding.owner)?.name}`
                : "unowned"}
            </p>
          </div>
        ) : null}
      </div>

      <div className="space-y-3">
        {state.phase === "over" ? (
          <div className="rounded-2xl border-2 border-ink bg-mint/40 p-4 text-center animate-scale-in">
            <Trophy className="mx-auto h-7 w-7" />
            <p className="mt-1 font-display text-xl">{winner?.name ?? "Nobody"} wins!</p>
            <Button asChild size="sm" className="mt-3">
              <Link to="/board">Back to lobby</Link>
            </Button>
          </div>
        ) : (
          <div className="paper rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-bold">
                {myTurn ? "Your turn" : `${current?.name ?? "…"}'s turn`}
              </p>
              {secondsLeft !== null ? (
                <span
                  className={cn(
                    "chip",
                    secondsLeft <= 10 && "border-destructive text-destructive",
                  )}
                >
                  {secondsLeft}s
                </span>
              ) : null}
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                disabled={busy || !myTurn || state.phase !== "roll"}
                onClick={() => act({ type: "roll" })}
              >
                <Dices className="mr-2 h-4 w-4" /> Roll
              </Button>
              <Button
                variant="outline"
                disabled={busy || !myTurn || state.phase === "roll"}
                onClick={() => act({ type: "endTurn" })}
              >
                End turn
              </Button>
              <TradeDialog state={state} userId={userId} act={act} busy={busy} />
              <Button
                variant="ghost"
                size="sm"
                disabled={busy}
                onClick={() => act({ type: "resign" })}
              >
                <Flag className="mr-1 h-4 w-4" /> Resign
              </Button>
            </div>

            {pendingTile ? (
              <div className="mt-3 rounded-xl border-2 border-coral bg-coral/5 p-3 animate-fade-in">
                <p className="text-sm font-bold">Buy {pendingTile.name}?</p>
                <p className="text-xs text-muted-foreground">
                  {money(pendingTile.price ?? 0)} · you hold {money(me?.cash ?? 0)}
                </p>
                <div className="mt-2 flex gap-2">
                  <Button
                    size="sm"
                    disabled={busy || (me?.cash ?? 0) < (pendingTile.price ?? 0)}
                    onClick={() => act({ type: "buy" })}
                  >
                    Buy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => act({ type: "decline" })}
                  >
                    Send to auction
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        )}

        <div className="paper rounded-2xl p-3">
          <p className="text-sm font-bold">Players</p>
          <ul className="mt-2 space-y-1.5">
            {state.players.map((p, i) => (
              <li
                key={p.id}
                className={cn(
                  "flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm",
                  i === state.turn && !p.bankrupt && "bg-muted",
                  p.bankrupt && "opacity-50 line-through",
                )}
              >
                <span
                  className="h-3 w-3 rounded-full border border-ink"
                  style={{ background: p.color }}
                />
                <span className="min-w-0 flex-1 truncate">
                  {p.name}
                  {p.id === userId ? " (you)" : ""}
                  {p.jail ? " 🔒" : ""}
                </span>
                <span className="text-xs font-semibold">{money(p.cash)}</span>
              </li>
            ))}
          </ul>
        </div>

        <ManagePanel state={state} userId={userId} act={act} busy={busy} selected={selected} />

        <div className="paper max-h-56 overflow-y-auto rounded-2xl p-3">
          <p className="text-sm font-bold">Match log</p>
          <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
            {[...state.log].reverse().slice(0, 30).map((l) => (
              <li key={l.id}>{l.text}</li>
            ))}
          </ul>
        </div>

        <Button variant="ghost" size="sm" onClick={onLeave}>
          <DoorOpen className="mr-2 h-4 w-4" /> Leave table
        </Button>
      </div>

      <AuctionModal state={state} userId={userId} act={act} busy={busy} />
      <RoomChat roomId={roomId} userId={userId} name={name} color={color} />
    </div>
  );
}
