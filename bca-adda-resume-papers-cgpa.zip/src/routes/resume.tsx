import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, FileEdit, Loader2, Plus, Trash2, Printer, Mail, Phone, GraduationCap, Github, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/resume")({
  head: () => ({
    meta: [
      { title: "Resume Builder — BCA Adda" },
      { name: "description", content: "Build a resume from your profile and projects." },
    ],
  }),
  component: ResumePage,
});

type Profile = { username: string; full_name: string | null; semester: number | null; bio: string | null };
type Project = { id: string; title: string; description: string | null; tech_stack: string[]; github_url: string | null; demo_url: string | null };
type Experience = { title: string; company: string; duration: string; description: string };
type ResumeDetails = { phone: string | null; education: string | null; skills: string[]; experience: Experience[] };

function newExperience(): Experience {
  return { title: "", company: "", duration: "", description: "" };
}

function ResumePage() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const [phone, setPhone] = useState("");
  const [education, setEducation] = useState("");
  const [skills, setSkills] = useState("");
  const [experience, setExperience] = useState<Experience[]>([]);
  const [selectedProjectIds, setSelectedProjectIds] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);

  const profileQ = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("username,full_name,semester,bio").eq("id", user!.id).maybeSingle();
      if (error) throw error;
      return data as Profile | null;
    },
  });

  const detailsQ = useQuery({
    queryKey: ["resume_details", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("resume_details").select("phone,education,skills,experience").eq("user_id", user!.id).maybeSingle();
      if (error) throw error;
      return data as ResumeDetails | null;
    },
  });

  const projectsQ = useQuery({
    queryKey: ["my_projects", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("id,title,description,tech_stack,github_url,demo_url")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Project[];
    },
  });

  useEffect(() => {
    if (!detailsQ.data) return;
    setPhone(detailsQ.data.phone ?? "");
    setEducation(detailsQ.data.education ?? "");
    setSkills((detailsQ.data.skills ?? []).join(", "));
    setExperience(detailsQ.data.experience?.length ? detailsQ.data.experience : [newExperience()]);
  }, [detailsQ.data]);

  useEffect(() => {
    if (experience.length === 0) setExperience([newExperience()]);
  }, [experience.length]);

  useEffect(() => {
    if (projectsQ.data && selectedProjectIds.size === 0 && projectsQ.data.length > 0) {
      setSelectedProjectIds(new Set(projectsQ.data.slice(0, 3).map((p) => p.id)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectsQ.data]);

  const selectedProjects = useMemo(
    () => (projectsQ.data ?? []).filter((p) => selectedProjectIds.has(p.id)),
    [projectsQ.data, selectedProjectIds],
  );

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to build your resume</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  const save = async () => {
    setSaving(true);
    const cleanExperience = experience.filter((e) => e.title.trim() || e.company.trim());
    const { error } = await supabase.from("resume_details").upsert({
      user_id: user.id,
      phone: phone.trim() || null,
      education: education.trim() || null,
      skills: skills.split(",").map((s) => s.trim()).filter(Boolean).slice(0, 20),
      experience: cleanExperience,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: ["resume_details", user.id] });
  };

  const profile = profileQ.data;
  const skillsList = skills.split(",").map((s) => s.trim()).filter(Boolean);
  const displayExperience = experience.filter((e) => e.title.trim() || e.company.trim());

  return (
    <div className="min-h-screen grain-bg px-5 py-8 print:bg-white print:px-0 print:py-0">
      <div className="mx-auto max-w-2xl print:max-w-none">
        <div className="print:hidden">
          <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back to chat
          </Link>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
                <FileEdit className="h-6 w-6" />
              </div>
              <h1 className="text-4xl">Resume Builder</h1>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setMode(mode === "edit" ? "preview" : "edit")}
                className="rounded-full border-2 border-ink px-4 py-2.5 font-semibold hover:bg-secondary"
              >
                {mode === "edit" ? "Preview" : "Edit"}
              </button>
              {mode === "preview" && (
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
                >
                  <Printer className="h-4 w-4" /> Save as PDF
                </button>
              )}
            </div>
          </div>
        </div>

        {mode === "edit" ? (
          <div className="mt-5 space-y-4 print:hidden">
            <div className="paper p-5">
              <h3 className="text-lg font-bold">Contact details</h3>
              <p className="mt-1 text-xs text-muted-foreground">Name and email come from your account automatically.</p>
              <div className="mt-3">
                <label className="text-sm font-medium">Phone</label>
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 …"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            </div>

            <div className="paper p-5">
              <h3 className="text-lg font-bold">Education</h3>
              <textarea
                value={education}
                onChange={(e) => setEducation(e.target.value.slice(0, 500))}
                rows={3}
                placeholder="Bachelor of Computer Applications (BCA), [Your College], 2023–2026"
                className="mt-2 w-full resize-none rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>

            <div className="paper p-5">
              <h3 className="text-lg font-bold">Skills (comma separated)</h3>
              <input
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                placeholder="Java, React, SQL, Git"
                className="mt-2 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>

            <div className="paper p-5">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Experience / Internships</h3>
                <button
                  onClick={() => setExperience((prev) => [...prev, newExperience()])}
                  className="inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-foreground"
                >
                  <Plus className="h-3.5 w-3.5" /> Add
                </button>
              </div>
              <div className="mt-3 space-y-4">
                {experience.map((exp, i) => (
                  <div key={i} className="rounded-xl border border-border p-3">
                    <div className="grid gap-2 sm:grid-cols-2">
                      <input
                        value={exp.title}
                        onChange={(e) => setExperience((prev) => prev.map((x, idx) => (idx === i ? { ...x, title: e.target.value } : x)))}
                        placeholder="Role / Title"
                        className="rounded-lg border-2 border-input bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
                      />
                      <input
                        value={exp.company}
                        onChange={(e) => setExperience((prev) => prev.map((x, idx) => (idx === i ? { ...x, company: e.target.value } : x)))}
                        placeholder="Company / Organization"
                        className="rounded-lg border-2 border-input bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
                      />
                    </div>
                    <input
                      value={exp.duration}
                      onChange={(e) => setExperience((prev) => prev.map((x, idx) => (idx === i ? { ...x, duration: e.target.value } : x)))}
                      placeholder="Duration (e.g. Jun 2025 – Aug 2025)"
                      className="mt-2 w-full rounded-lg border-2 border-input bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
                    />
                    <textarea
                      value={exp.description}
                      onChange={(e) => setExperience((prev) => prev.map((x, idx) => (idx === i ? { ...x, description: e.target.value } : x)))}
                      rows={2}
                      placeholder="What you did…"
                      className="mt-2 w-full resize-none rounded-lg border-2 border-input bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
                    />
                    {experience.length > 1 && (
                      <button
                        onClick={() => setExperience((prev) => prev.filter((_, idx) => idx !== i))}
                        className="mt-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-coral"
                      >
                        <Trash2 className="h-3 w-3" /> Remove
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="paper p-5">
              <h3 className="text-lg font-bold">Projects to include</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                From your <Link to="/projects" className="underline">Projects</Link> page. Pick which ones to show.
              </p>
              {(projectsQ.data ?? []).length === 0 ? (
                <p className="mt-2 text-sm text-muted-foreground">No projects added yet.</p>
              ) : (
                <div className="mt-3 space-y-2">
                  {(projectsQ.data ?? []).map((p) => (
                    <label key={p.id} className="flex items-center gap-2 rounded-lg border border-border p-2.5">
                      <input
                        type="checkbox"
                        checked={selectedProjectIds.has(p.id)}
                        onChange={(e) =>
                          setSelectedProjectIds((prev) => {
                            const next = new Set(prev);
                            if (e.target.checked) next.add(p.id);
                            else next.delete(p.id);
                            return next;
                          })
                        }
                      />
                      <span className="text-sm font-semibold">{p.title}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={save}
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 font-semibold text-cream disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Save details
            </button>
          </div>
        ) : (
          <div className="resume-preview mt-5 rounded-2xl border-2 border-ink bg-white p-8 text-ink print:mt-0 print:rounded-none print:border-0 print:p-10">
            <h1 className="text-3xl font-bold">{profile?.full_name ?? profile?.username ?? "Your Name"}</h1>
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-600">
              <span className="inline-flex items-center gap-1"><Mail className="h-3.5 w-3.5" /> {user.email}</span>
              {phone && <span className="inline-flex items-center gap-1"><Phone className="h-3.5 w-3.5" /> {phone}</span>}
            </div>

            {(education || profile?.semester) && (
              <div className="mt-5">
                <h2 className="border-b-2 border-gray-300 pb-1 text-sm font-bold uppercase tracking-wider">Education</h2>
                <p className="mt-2 inline-flex items-center gap-1.5 text-sm">
                  <GraduationCap className="h-4 w-4" />
                  {education || `Bachelor of Computer Applications, Semester ${profile?.semester}`}
                </p>
              </div>
            )}

            {profile?.bio && (
              <div className="mt-5">
                <h2 className="border-b-2 border-gray-300 pb-1 text-sm font-bold uppercase tracking-wider">Summary</h2>
                <p className="mt-2 text-sm">{profile.bio}</p>
              </div>
            )}

            {skillsList.length > 0 && (
              <div className="mt-5">
                <h2 className="border-b-2 border-gray-300 pb-1 text-sm font-bold uppercase tracking-wider">Skills</h2>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {skillsList.map((s) => (
                    <span key={s} className="rounded-full border border-gray-300 px-2.5 py-0.5 text-xs">{s}</span>
                  ))}
                </div>
              </div>
            )}

            {displayExperience.length > 0 && (
              <div className="mt-5">
                <h2 className="border-b-2 border-gray-300 pb-1 text-sm font-bold uppercase tracking-wider">Experience</h2>
                <div className="mt-2 space-y-3">
                  {displayExperience.map((exp, i) => (
                    <div key={i}>
                      <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                        <p className="text-sm font-bold">{exp.title} {exp.company && `— ${exp.company}`}</p>
                        {exp.duration && <p className="text-xs text-gray-500">{exp.duration}</p>}
                      </div>
                      {exp.description && <p className="mt-0.5 text-sm text-gray-700">{exp.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {selectedProjects.length > 0 && (
              <div className="mt-5">
                <h2 className="border-b-2 border-gray-300 pb-1 text-sm font-bold uppercase tracking-wider">Projects</h2>
                <div className="mt-2 space-y-3">
                  {selectedProjects.map((p) => (
                    <div key={p.id}>
                      <div className="flex flex-wrap items-baseline justify-between gap-x-2">
                        <p className="text-sm font-bold">{p.title}</p>
                        <div className="flex gap-2 text-xs text-gray-500">
                          {p.github_url && <span className="inline-flex items-center gap-1"><Github className="h-3 w-3" /> Code</span>}
                          {p.demo_url && <span className="inline-flex items-center gap-1"><ExternalLink className="h-3 w-3" /> Demo</span>}
                        </div>
                      </div>
                      {p.description && <p className="mt-0.5 text-sm text-gray-700">{p.description}</p>}
                      {p.tech_stack.length > 0 && <p className="mt-0.5 text-xs text-gray-500">{p.tech_stack.join(", ")}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
