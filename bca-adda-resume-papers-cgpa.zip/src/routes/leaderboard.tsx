import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Trophy, Medal, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/leaderboard")({
  head: () => ({
    meta: [
      { title: "Leaderboard — Arcade" },
      { name: "description", content: "Top players across every multiplayer game." },
    ],
  }),
  component: LeaderboardPage,
});

type Row = {
  user_id: string;
  wins: number;
  losses: number;
  draws: number;
  profiles: { username: string; full_name: string | null; avatar_url: string | null } | null;
};

const MEDALS = ["🥇", "🥈", "🥉"];

function LeaderboardPage() {
  const { user } = useAuth();

  const q = useQuery({
    queryKey: ["leaderboard"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("game_stats")
        .select("user_id,wins,losses,draws,profiles(username,full_name,avatar_url)")
        .order("wins", { ascending: false })
        .limit(50);
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  const rows = q.data ?? [];
  const myRank = rows.findIndex((r) => r.user_id === user?.id);

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-xl">
        <Link to="/games" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> All games
        </Link>

        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Trophy className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-4xl">Leaderboard</h1>
            <p className="text-muted-foreground">Wins across every multiplayer game in the arcade.</p>
          </div>
        </div>

        {q.isLoading ? (
          <div className="mt-10 grid place-items-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : rows.length === 0 ? (
          <div className="paper mt-6 p-8 text-center text-muted-foreground">
            No games finished yet — be the first to win one!
          </div>
        ) : (
          <div className="paper mt-6 divide-y divide-border">
            {rows.map((r, i) => {
              const isMe = r.user_id === user?.id;
              const total = r.wins + r.losses + r.draws;
              const winRate = total > 0 ? Math.round((r.wins / total) * 100) : 0;
              return (
                <div key={r.user_id} className={`flex items-center gap-3 p-3.5 ${isMe ? "bg-mint/40" : ""}`}>
                  <div className="w-7 shrink-0 text-center font-display text-lg">
                    {i < 3 ? MEDALS[i] : i + 1}
                  </div>
                  <Link
                    to="/profile/$userId"
                    params={{ userId: r.user_id }}
                    className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full bg-coral text-sm font-bold text-primary-foreground"
                  >
                    {r.profiles?.avatar_url ? (
                      <img src={r.profiles.avatar_url} alt="" className="h-full w-full object-cover" />
                    ) : (
                      (r.profiles?.full_name ?? r.profiles?.username ?? "?").charAt(0).toUpperCase()
                    )}
                  </Link>
                  <Link to="/profile/$userId" params={{ userId: r.user_id }} className="min-w-0 flex-1 font-semibold hover:underline">
                    {r.profiles?.full_name ?? r.profiles?.username ?? "Student"} {isMe && <span className="text-muted-foreground">(You)</span>}
                  </Link>
                  <div className="shrink-0 text-right text-sm">
                    <div className="font-bold">{r.wins}W {r.losses}L {r.draws}D</div>
                    <div className="text-xs text-muted-foreground">{winRate}% win rate</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {user && myRank === -1 && rows.length > 0 && (
          <p className="mt-4 text-center text-sm text-muted-foreground">
            <Medal className="mr-1 inline h-4 w-4" /> Win a multiplayer game to get on the board.
          </p>
        )}
      </div>
    </div>
  );
}
