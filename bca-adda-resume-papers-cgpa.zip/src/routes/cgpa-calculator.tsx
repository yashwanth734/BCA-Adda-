import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, Calculator, Plus, Trash2, Info } from "lucide-react";

export const Route = createFileRoute("/cgpa-calculator")({
  head: () => ({
    meta: [
      { title: "CGPA Calculator — BCA Adda" },
      { name: "description", content: "Calculate your semester GPA and cumulative CGPA." },
    ],
  }),
  component: CgpaCalculatorPage,
});

type Subject = { id: string; name: string; credits: string; grade: string };
type Semester = { id: string; label: string; subjects: Subject[] };

// Standard 10-point scale used by most Indian universities. If your
// college uses a different scale, adjust the numbers on the right —
// everything else recalculates automatically.
const GRADE_POINTS: Record<string, number> = {
  O: 10,
  "A+": 9,
  A: 8,
  "B+": 7,
  B: 6,
  C: 5,
  P: 4,
  F: 0,
};

function newSubject(): Subject {
  return { id: crypto.randomUUID(), name: "", credits: "", grade: "O" };
}

function newSemester(n: number): Semester {
  return { id: crypto.randomUUID(), label: `Semester ${n}`, subjects: [newSubject()] };
}

function calcSGPA(subjects: Subject[]): number | null {
  let totalPoints = 0;
  let totalCredits = 0;
  for (const s of subjects) {
    const credits = parseFloat(s.credits);
    if (!s.name.trim() || isNaN(credits) || credits <= 0) continue;
    totalPoints += credits * (GRADE_POINTS[s.grade] ?? 0);
    totalCredits += credits;
  }
  if (totalCredits === 0) return null;
  return totalPoints / totalCredits;
}

function CgpaCalculatorPage() {
  const [semesters, setSemesters] = useState<Semester[]>([newSemester(1)]);

  const sgpas = useMemo(() => semesters.map((s) => calcSGPA(s.subjects)), [semesters]);

  const cgpa = useMemo(() => {
    let totalPoints = 0;
    let totalCredits = 0;
    for (const sem of semesters) {
      for (const s of sem.subjects) {
        const credits = parseFloat(s.credits);
        if (!s.name.trim() || isNaN(credits) || credits <= 0) continue;
        totalPoints += credits * (GRADE_POINTS[s.grade] ?? 0);
        totalCredits += credits;
      }
    }
    return totalCredits === 0 ? null : totalPoints / totalCredits;
  }, [semesters]);

  const addSemester = () => setSemesters((prev) => [...prev, newSemester(prev.length + 1)]);
  const removeSemester = (id: string) => setSemesters((prev) => prev.filter((s) => s.id !== id));

  const addSubject = (semId: string) =>
    setSemesters((prev) => prev.map((s) => (s.id === semId ? { ...s, subjects: [...s.subjects, newSubject()] } : s)));

  const removeSubject = (semId: string, subId: string) =>
    setSemesters((prev) =>
      prev.map((s) => (s.id === semId ? { ...s, subjects: s.subjects.filter((sub) => sub.id !== subId) } : s)),
    );

  const updateSubject = (semId: string, subId: string, patch: Partial<Subject>) =>
    setSemesters((prev) =>
      prev.map((s) =>
        s.id === semId
          ? { ...s, subjects: s.subjects.map((sub) => (sub.id === subId ? { ...sub, ...patch } : sub)) }
          : s,
      ),
    );

  const updateLabel = (semId: string, label: string) =>
    setSemesters((prev) => prev.map((s) => (s.id === semId ? { ...s, label } : s)));

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-3xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Calculator className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-4xl">CGPA Calculator</h1>
            <p className="text-muted-foreground">Nothing here is saved — it's all calculated on your device.</p>
          </div>
        </div>

        <div className="paper mt-5 flex items-start gap-2 p-4 text-sm text-muted-foreground">
          <Info className="mt-0.5 h-4 w-4 shrink-0" />
          Uses the standard 10-point scale (O=10, A+=9, A=8, B+=7, B=6, C=5, P=4, F=0). If your college uses a
          different grading scale, the math still works the same way — just mentally remap which letter means what.
        </div>

        {cgpa !== null && (
          <div className="paper mt-5 bg-mint p-6 text-center">
            <p className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Cumulative CGPA</p>
            <p className="mt-1 font-display text-5xl font-bold">{cgpa.toFixed(2)}</p>
          </div>
        )}

        <div className="mt-6 space-y-5">
          {semesters.map((sem, semIdx) => (
            <div key={sem.id} className="paper p-5">
              <div className="flex items-center justify-between gap-2">
                <input
                  value={sem.label}
                  onChange={(e) => updateLabel(sem.id, e.target.value)}
                  className="rounded-lg border-b-2 border-transparent bg-transparent text-lg font-bold outline-none focus:border-ink"
                />
                <div className="flex items-center gap-3">
                  {sgpas[semIdx] !== null && (
                    <span className="chip bg-gold">SGPA {sgpas[semIdx]!.toFixed(2)}</span>
                  )}
                  {semesters.length > 1 && (
                    <button onClick={() => removeSemester(sem.id)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-coral" aria-label="Remove semester">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-3 space-y-2">
                {sem.subjects.map((sub) => (
                  <div key={sub.id} className="flex items-center gap-2">
                    <input
                      value={sub.name}
                      onChange={(e) => updateSubject(sem.id, sub.id, { name: e.target.value })}
                      placeholder="Subject name"
                      className="min-w-0 flex-1 rounded-lg border-2 border-input bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
                    />
                    <input
                      value={sub.credits}
                      onChange={(e) => updateSubject(sem.id, sub.id, { credits: e.target.value.replace(/[^0-9.]/g, "") })}
                      placeholder="Credits"
                      inputMode="decimal"
                      className="w-20 shrink-0 rounded-lg border-2 border-input bg-cream px-3 py-2 text-center text-sm outline-none focus:border-ink"
                    />
                    <select
                      value={sub.grade}
                      onChange={(e) => updateSubject(sem.id, sub.id, { grade: e.target.value })}
                      className="w-20 shrink-0 rounded-lg border-2 border-input bg-cream px-2 py-2 text-sm outline-none focus:border-ink"
                    >
                      {Object.keys(GRADE_POINTS).map((g) => (
                        <option key={g} value={g}>{g}</option>
                      ))}
                    </select>
                    <button
                      onClick={() => removeSubject(sem.id, sub.id)}
                      disabled={sem.subjects.length === 1}
                      className="shrink-0 rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-coral disabled:opacity-30"
                      aria-label="Remove subject"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <button
                onClick={() => addSubject(sem.id)}
                className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground"
              >
                <Plus className="h-3.5 w-3.5" /> Add subject
              </button>
            </div>
          ))}
        </div>

        <button
          onClick={addSemester}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
        >
          <Plus className="h-4 w-4" /> Add semester
        </button>
      </div>
    </div>
  );
}
