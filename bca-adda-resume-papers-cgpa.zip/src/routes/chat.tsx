import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";

import { ArrowLeft, LogOut, Send, Loader2, Hash, Menu, X, PartyPopper, Trash2, MoreHorizontal, Pencil, Flag, Check, SmilePlus, Reply } from "lucide-react";
import { toast } from "sonner";
import { NicknamePrompt } from "@/components/NicknamePrompt";
import { ReportDialog, type ReportTarget } from "@/components/ReportDialog";
import { NotificationBell } from "@/components/NotificationBell";
import { ThemeToggle } from "@/components/ThemeToggle";
import { usePresence } from "@/lib/usePresence";



const chatSearchSchema = z.object({
  welcome: z.coerce.number().optional(),
  channel: z.string().optional(),
});

export const Route = createFileRoute("/chat")({
  validateSearch: chatSearchSchema,
  component: ChatPage,
});


type Channel = {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  emoji: string | null;
};

const PAGE_SIZE = 50;

type Message = {
  id: string;
  channel_id: string;
  user_id: string;
  content: string;
  created_at: string;
  edited_at?: string | null;
  reply_to_id?: string | null;
};


type Profile = {
  id: string;
  username: string;
  full_name: string | null;
};

function ChatPage() {
  const { user, loading, signOut } = useAuth();
  const { isTeacher } = useRole();
  const { isOnline } = usePresence(user?.id);

  const navigate = useNavigate();
  const search = Route.useSearch();
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [sending, setSending] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);
  const [reportTarget, setReportTarget] = useState<ReportTarget | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const prependAnchorRef = useRef<{ scrollHeight: number; scrollTop: number } | null>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [user, loading, navigate]);

  const channelsQuery = useQuery({
    queryKey: ["channels"],
    enabled: !!user,
    queryFn: async (): Promise<Channel[]> => {
      const { data, error } = await supabase.from("channels").select("*").order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  // Pick the requested channel from the search param, otherwise the first one.
  useEffect(() => {
    if (activeChannelId || !channelsQuery.data?.length) return;
    const wanted = search.channel
      ? channelsQuery.data.find((c) => c.slug === search.channel)
      : null;
    setActiveChannelId((wanted ?? channelsQuery.data[0]).id);
  }, [channelsQuery.data, activeChannelId, search.channel]);

  // Trigger the welcome banner + toast for fresh signups, then strip the params.
  useEffect(() => {
    if (search.welcome !== 1 || !user) return;
    setShowWelcome(true);
    toast.success("Welcome to BCA Adda! 🎉");
    navigate({
      to: "/chat",
      search: {},
      replace: true,
    });
    const t = setTimeout(() => setShowWelcome(false), 8000);
    return () => clearTimeout(t);
  }, [search.welcome, user, navigate]);

  const messagesQuery = useQuery({
    queryKey: ["messages", activeChannelId],
    enabled: !!activeChannelId,
    queryFn: async (): Promise<Message[]> => {
      // Fetch the most RECENT page, then reverse to ascending order for
      // display. The previous version ordered ascending with a flat
      // limit, which returns the OLDEST messages in the channel — once
      // any channel passed 200 total messages ever sent, every fresh
      // load (including the reconnect-recovery refetch) would show
      // ancient history instead of anything current.
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("channel_id", activeChannelId!)
        .is("removed_at", null)
        .order("created_at", { ascending: false })
        .limit(PAGE_SIZE);
      if (error) throw error;
      return (data ?? []).reverse();
    },
  });

  const [loadingOlder, setLoadingOlder] = useState(false);
  const [hasMoreOlder, setHasMoreOlder] = useState(true);

  // Pagination state is per-channel — switching channels should offer to
  // load older messages again rather than remembering "no more" from a
  // previous, different channel.
  useEffect(() => {
    setHasMoreOlder(true);
  }, [activeChannelId]);

  const loadOlderMessages = async () => {
    const current = messagesQuery.data;
    if (!activeChannelId || !current || current.length === 0 || loadingOlder || !hasMoreOlder) return;
    setLoadingOlder(true);
    const oldest = current[0];
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("channel_id", activeChannelId)
      .is("removed_at", null)
      .lt("created_at", oldest.created_at)
      .order("created_at", { ascending: false })
      .limit(PAGE_SIZE);
    setLoadingOlder(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    const older = (data ?? []).reverse();
    if (older.length < PAGE_SIZE) setHasMoreOlder(false);
    if (older.length === 0) return;
    if (scrollRef.current) {
      prependAnchorRef.current = {
        scrollHeight: scrollRef.current.scrollHeight,
        scrollTop: scrollRef.current.scrollTop,
      };
    }
    queryClient.setQueryData<Message[]>(["messages", activeChannelId], (existing) => {
      const seen = new Set((existing ?? []).map((m) => m.id));
      return [...older.filter((m) => !seen.has(m.id)), ...(existing ?? [])];
    });
  };


  const userIds = useMemo(
    () => Array.from(new Set(messagesQuery.data?.map((m) => m.user_id) ?? [])),
    [messagesQuery.data],
  );

  const profilesQuery = useQuery({
    queryKey: ["profiles", userIds.sort().join(",")],
    enabled: userIds.length > 0,
    queryFn: async (): Promise<Record<string, Profile>> => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, full_name")
        .in("id", userIds);
      if (error) throw error;
      return Object.fromEntries((data ?? []).map((p) => [p.id, p as Profile]));
    },
  });

  const messageIds = useMemo(() => (messagesQuery.data ?? []).map((m) => m.id), [messagesQuery.data]);

  const reactionsQuery = useQuery({
    queryKey: ["reactions", activeChannelId, messageIds.length],
    enabled: messageIds.length > 0,
    queryFn: async (): Promise<Record<string, { emoji: string; user_id: string }[]>> => {
      const { data, error } = await supabase
        .from("message_reactions")
        .select("message_id,emoji,user_id")
        .in("message_id", messageIds);
      if (error) throw error;
      const grouped: Record<string, { emoji: string; user_id: string }[]> = {};
      for (const r of data ?? []) {
        (grouped[r.message_id] ??= []).push({ emoji: r.emoji, user_id: r.user_id });
      }
      return grouped;
    },
  });

  useEffect(() => {
    if (!activeChannelId) return;
    const ch = supabase
      .channel(`reactions:${activeChannelId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "message_reactions" },
        () => queryClient.invalidateQueries({ queryKey: ["reactions", activeChannelId] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [activeChannelId, queryClient]);

  const toggleReaction = async (messageId: string, emoji: string) => {
    if (!user) return;
    const existing = reactionsQuery.data?.[messageId]?.find((r) => r.emoji === emoji && r.user_id === user.id);
    if (existing) {
      const { error } = await supabase
        .from("message_reactions")
        .delete()
        .eq("message_id", messageId)
        .eq("user_id", user.id)
        .eq("emoji", emoji);
      if (error) toast.error(error.message);
    } else {
      const { error } = await supabase
        .from("message_reactions")
        .insert({ message_id: messageId, user_id: user.id, emoji });
      if (error) toast.error(error.message);
    }
    queryClient.invalidateQueries({ queryKey: ["reactions", activeChannelId] });
  };

  // Realtime
  useEffect(() => {
    if (!activeChannelId) return;
    const channel = supabase
      .channel(`messages:${activeChannelId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `channel_id=eq.${activeChannelId}`,
        },
        (payload) => {
          const newMsg = payload.new as Message;
          queryClient.setQueryData<Message[]>(["messages", activeChannelId], (old) => {
            if (!old) return [newMsg];
            if (old.some((m) => m.id === newMsg.id)) return old;
            return [...old, newMsg];
          });
        },
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "messages",
          filter: `channel_id=eq.${activeChannelId}`,
        },
        (payload) => {
          const oldMsg = payload.old as { id?: string };
          if (!oldMsg?.id) return;
          queryClient.setQueryData<Message[]>(["messages", activeChannelId], (old) =>
            (old ?? []).filter((m) => m.id !== oldMsg.id),
          );
        },
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "messages",
          filter: `channel_id=eq.${activeChannelId}`,
        },
        (payload) => {
          const updated = payload.new as Message;
          queryClient.setQueryData<Message[]>(["messages", activeChannelId], (old) =>
            (old ?? []).map((m) => (m.id === updated.id ? { ...m, ...updated } : m)),
          );
        },
      )

      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeChannelId, queryClient]);

  // Autoscroll to bottom for new/initial messages — but when older
  // messages were just prepended (loadOlderMessages), jump-to-bottom
  // would immediately undo the whole point of the button. Anchor the
  // scroll position to whatever the user was looking at instead.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (prependAnchorRef.current) {
      const { scrollHeight: prevHeight, scrollTop: prevTop } = prependAnchorRef.current;
      prependAnchorRef.current = null;
      el.scrollTop = el.scrollHeight - prevHeight + prevTop;
      return;
    }
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messagesQuery.data]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!draft.trim() || !activeChannelId || !user) return;
    setSending(true);
    const content = draft.trim();
    setDraft("");
    const replyToId = replyingTo?.id ?? null;
    setReplyingTo(null);
    const { error } = await supabase
      .from("messages")
      .insert({ channel_id: activeChannelId, user_id: user.id, content, reply_to_id: replyToId });
    if (error) {
      toast.error(error.message);
      setDraft(content);
    }
    setSending(false);
  };

  const unsend = async (messageId: string) => {
    if (!confirm("Unsend this message? This cannot be undone.")) return;
    // Optimistic remove
    queryClient.setQueryData<Message[]>(["messages", activeChannelId], (old) =>
      (old ?? []).filter((m) => m.id !== messageId),
    );
    const { error } = await supabase.from("messages").delete().eq("id", messageId);
    if (error) {
      toast.error(error.message);
      queryClient.invalidateQueries({ queryKey: ["messages", activeChannelId] });
    } else {
      toast.success("Message unsent");
    }
  };

  const startEdit = (m: Message) => {
    setEditingId(m.id);
    setEditDraft(m.content);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditDraft("");
  };

  const saveEdit = async (messageId: string) => {
    const content = editDraft.trim();
    if (!content) {
      toast.error("Message can't be empty. Use unsend to remove it.");
      return;
    }
    if (content.length > 2000) {
      toast.error("Message is too long (max 2000 characters).");
      return;
    }
    setSavingEdit(true);
    const editedAt = new Date().toISOString();
    const { error } = await supabase
      .from("messages")
      .update({ content, edited_at: editedAt })
      .eq("id", messageId);
    setSavingEdit(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    queryClient.setQueryData<Message[]>(["messages", activeChannelId], (old) =>
      (old ?? []).map((m) => (m.id === messageId ? { ...m, content, edited_at: editedAt } : m)),
    );
    cancelEdit();
    toast.success("Message updated");
  };


  if (loading || !user) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const channels = channelsQuery.data ?? [];
  const activeChannel = channels.find((c) => c.id === activeChannelId);
  const messages = messagesQuery.data ?? [];
  const profiles = profilesQuery.data ?? {};

  return (
    <>
    <NicknamePrompt user={user} />
    {reportTarget && (
      <ReportDialog
        target={reportTarget}
        reporterId={user.id}
        onClose={() => setReportTarget(null)}
      />
    )}

    <div className="flex h-[100dvh] flex-col bg-background md:flex-row">

      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? "flex" : "hidden"
        } absolute inset-0 z-20 flex-col bg-cream md:static md:flex md:w-72 md:border-r md:border-border`}
      >
        <div className="flex items-center justify-between px-5 py-4">
          <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-ink text-cream text-sm">B</span>
            BCA Adda
          </Link>
          <button
            className="md:hidden rounded-full p-2 hover:bg-secondary"
            onClick={() => setSidebarOpen(false)}
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Channels
        </div>
        <nav className="flex-1 overflow-y-auto px-2">
          {channels.map((c) => {
            const isActive = c.id === activeChannelId;
            return (
              <button
                key={c.id}
                onClick={() => {
                  setActiveChannelId(c.id);
                  setSidebarOpen(false);
                }}
                className={`flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-left text-sm font-medium transition-colors ${
                  isActive ? "bg-ink text-cream" : "hover:bg-secondary"
                }`}
              >
                <span className="text-base">{c.emoji ?? "#"}</span>
                <span>{c.name}</span>
              </button>
            );
          })}
        </nav>

        {isTeacher && (
          <Link
            to="/moderation"
            className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl bg-coral px-3 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90"
          >
            <span className="flex items-center gap-2">🛡️ Moderation inbox</span>
            <span className="text-xs opacity-70">→</span>
          </Link>
        )}

        <Link
          to="/attendance"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl bg-mint px-3 py-2.5 text-sm font-semibold hover:opacity-90"
        >
          <span className="flex items-center gap-2">📅 Attendance tracker</span>
          <span className="text-xs opacity-70">→</span>
        </Link>



        <Link
          to="/games"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl bg-accent px-3 py-2.5 text-sm font-semibold hover:opacity-90"
        >
          <span className="flex items-center gap-2">🎮 The Arcade</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/friends"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl bg-secondary px-3 py-2.5 text-sm font-semibold hover:opacity-90"
        >
          <span className="flex items-center gap-2">👥 Friends & DMs</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/study-groups"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">🗓️ Study Groups</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/assignments"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">📝 Assignments</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/notes"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">📚 Notes & Resources</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/projects"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">💼 Projects</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/assistant"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">🤖 AI Assistant</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/question-papers"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">📄 Question Papers</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/cgpa-calculator"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">🧮 CGPA Calculator</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/resume"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">📝 Resume Builder</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <Link
          to="/settings/security"
          className="mx-3 mb-2 inline-flex items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <span className="flex items-center gap-2">🔒 Security</span>
          <span className="text-xs opacity-70">→</span>
        </Link>

        <div className="mx-3 mb-2 flex items-center justify-between gap-2 rounded-xl px-3 py-2">
          <span className="text-sm font-semibold text-muted-foreground">Theme</span>
          <ThemeToggle />
        </div>

        <div className="border-t border-border p-3">
          <Link to="/profile/$userId" params={{ userId: user.id }} className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-secondary">
            <div className="relative">
              <div className="grid h-9 w-9 place-items-center rounded-full bg-coral text-cream text-sm font-bold">
                {(user.email ?? "?").charAt(0).toUpperCase()}
              </div>
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-neon" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold">{user.email}</div>
              <div className="text-xs text-muted-foreground">View profile</div>
            </div>
            <button
              onClick={(e) => {
                e.preventDefault();
                signOut();
              }}
              className="rounded-lg p-2 text-muted-foreground hover:bg-background hover:text-foreground"
              aria-label="Sign out"
              title="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </Link>
        </div>
      </aside>

      {/* Main */}
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-border px-4 py-3">
          <button
            className="md:hidden rounded-full p-2 hover:bg-secondary"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <Hash className="h-4 w-4 text-muted-foreground" />
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-lg font-bold leading-tight">
              {activeChannel?.name ?? "Loading…"}
            </div>
            {activeChannel?.description && (
              <div className="truncate text-xs text-muted-foreground">{activeChannel.description}</div>
            )}
          </div>
          <NotificationBell />
        </header>

        {showWelcome && (
          <div className="border-b border-border bg-accent px-4 py-3">
            <div className="mx-auto flex max-w-3xl items-start gap-3">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-ink text-cream">
                <PartyPopper className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <p className="font-display text-lg font-bold leading-tight">
                  Welcome to BCA Adda{user.user_metadata?.full_name ? `, ${(user.user_metadata.full_name as string).split(" ")[0]}` : ""}!
                </p>
                <p className="mt-0.5 text-sm text-foreground/80">
                  You're in <span className="font-semibold">#{activeChannel?.slug ?? "general"}</span> — say hi, ask a doubt, or hop into another channel from the sidebar.
                </p>
              </div>
              <button
                onClick={() => setShowWelcome(false)}
                className="rounded-full p-1.5 text-foreground/70 hover:bg-cream"
                aria-label="Dismiss welcome"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">

          {messagesQuery.isLoading ? (
            <div className="grid h-full place-items-center">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : messages.length === 0 ? (
            <div className="grid h-full place-items-center text-center">
              <div className="max-w-sm">
                <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-accent text-2xl">
                  {activeChannel?.emoji ?? "💬"}
                </div>
                <h3 className="mt-4 text-2xl">Be the first to say hi</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  No messages in #{activeChannel?.slug} yet. Drop a line below!
                </p>
              </div>
            </div>
          ) : (
            <ul className="mx-auto flex max-w-3xl flex-col gap-4">
              {hasMoreOlder && (
                <li className="flex justify-center pb-2">
                  <button
                    onClick={loadOlderMessages}
                    disabled={loadingOlder}
                    className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-secondary disabled:opacity-60"
                  >
                    {loadingOlder ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
                    {loadingOlder ? "Loading…" : "Load older messages"}
                  </button>
                </li>
              )}
              {messages.map((m, i) => {
                const author = profiles[m.user_id];
                const isMe = m.user_id === user.id;
                const prev = messages[i - 1];
                const showHeader = !prev || prev.user_id !== m.user_id;
                return (
                  <li key={m.id} id={`msg-${m.id}`} className={`group flex gap-3 ${isMe ? "flex-row-reverse" : ""}`}>
                    <div className="w-9 shrink-0">
                      {showHeader && (
                        <div className="relative">
                          <Link
                            to="/profile/$userId"
                            params={{ userId: m.user_id }}
                            className={`grid h-9 w-9 place-items-center rounded-full text-sm font-bold ${
                              isMe ? "bg-coral text-cream" : "bg-accent text-foreground"
                            }`}
                          >
                            {(author?.username ?? author?.full_name ?? "?").charAt(0).toUpperCase()}
                          </Link>
                          {isOnline(m.user_id) && (
                            <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-neon" />
                          )}
                        </div>
                      )}
                    </div>
                    <div className={`min-w-0 max-w-[80%] ${isMe ? "items-end text-right" : ""} flex flex-col`}>
                      {showHeader && (
                        <div className="mb-1 flex items-baseline gap-2 text-xs text-muted-foreground">
                          <Link to="/profile/$userId" params={{ userId: m.user_id }} className="font-semibold text-foreground hover:underline">
                            {isMe ? "You" : author?.full_name ?? author?.username ?? "Student"}
                          </Link>
                          <span>{formatTime(m.created_at)}</span>
                        </div>
                      )}
                      {editingId === m.id ? (
                        <div className="w-full min-w-[220px] text-left">
                          <textarea
                            value={editDraft}
                            onChange={(e) => setEditDraft(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                saveEdit(m.id);
                              }
                              if (e.key === "Escape") cancelEdit();
                            }}
                            rows={2}
                            maxLength={2000}
                            autoFocus
                            className="w-full resize-none rounded-2xl border-2 border-input bg-cream px-3 py-2 text-[15px] outline-none focus:border-ink"
                          />
                          <div className="mt-1 flex items-center gap-2">
                            <button
                              onClick={() => saveEdit(m.id)}
                              disabled={savingEdit || !editDraft.trim()}
                              className="inline-flex items-center gap-1 rounded-full bg-ink px-3 py-1 text-xs font-semibold text-cream disabled:opacity-50"
                            >
                              {savingEdit ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                              Save
                            </button>
                            <button
                              onClick={cancelEdit}
                              className="rounded-full px-3 py-1 text-xs font-semibold text-muted-foreground hover:bg-secondary"
                            >
                              Cancel
                            </button>
                            <span className="text-[11px] text-muted-foreground">Esc to cancel</span>
                          </div>
                        </div>
                      ) : (
                        <div className={`flex items-center gap-1.5 ${isMe ? "flex-row-reverse" : ""}`}>
                          <div
                            className={`inline-block whitespace-pre-wrap break-words rounded-2xl px-4 py-2.5 text-[15px] leading-relaxed ${
                              isMe
                                ? "bg-ink text-cream rounded-tr-sm"
                                : "bg-card border border-border rounded-tl-sm"
                            }`}
                          >
                            {m.reply_to_id && (() => {
                              const original = messages.find((om) => om.id === m.reply_to_id);
                              const originalAuthor = original ? profiles[original.user_id] : null;
                              return (
                                <button
                                  onClick={() => {
                                    const el = document.getElementById(`msg-${m.reply_to_id}`);
                                    el?.scrollIntoView({ behavior: "smooth", block: "center" });
                                  }}
                                  className={`mb-1.5 block w-full rounded-lg border-l-2 px-2.5 py-1 text-left text-[13px] ${
                                    isMe ? "border-cream/40 bg-cream/10 text-cream/80" : "border-ink/30 bg-secondary/60 text-muted-foreground"
                                  }`}
                                >
                                  <span className="block font-semibold">
                                    {original ? (originalAuthor?.full_name ?? originalAuthor?.username ?? "Student") : "Original message"}
                                  </span>
                                  <span className="line-clamp-1">{original ? original.content : "unavailable"}</span>
                                </button>
                              );
                            })()}
                            {m.content}
                            {m.edited_at && (
                              <span className={`ml-2 text-[11px] ${isMe ? "text-cream/60" : "text-muted-foreground"}`}>
                                (edited)
                              </span>
                            )}
                          </div>
                          <button
                            onClick={() => setReplyingTo(m)}
                            className="rounded-full p-1.5 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-foreground group-hover:opacity-100 focus:opacity-100"
                            aria-label="Reply"
                            title="Reply"
                          >
                            <Reply className="h-3.5 w-3.5" />
                          </button>
                          {isMe ? (
                            <>
                              <button
                                onClick={() => startEdit(m)}
                                className="rounded-full p-1.5 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-foreground group-hover:opacity-100 focus:opacity-100"
                                aria-label="Edit message"
                                title="Edit"
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </button>
                              <button
                                onClick={() => unsend(m.id)}
                                className="rounded-full p-1.5 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-coral group-hover:opacity-100 focus:opacity-100"
                                aria-label="Unsend message"
                                title="Unsend"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </>
                          ) : (
                            <button
                              onClick={() =>
                                setReportTarget({
                                  type: "message",
                                  messageId: m.id,
                                  reportedUserId: m.user_id,
                                  snapshot: m.content,
                                  authorLabel: author?.full_name ?? author?.username ?? "Student",
                                })
                              }
                              className="rounded-full p-1.5 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-coral group-hover:opacity-100 focus:opacity-100"
                              aria-label="Report message"
                              title="Report message or user"
                            >
                              <Flag className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      )}

                      <ReactionBar
                        messageId={m.id}
                        reactions={reactionsQuery.data?.[m.id] ?? []}
                        myId={user.id}
                        isMe={isMe}
                        onToggle={toggleReaction}
                      />
                    </div>

                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <form onSubmit={send} className="border-t border-border p-3">
          {replyingTo && (
            <div className="mx-auto mb-2 flex max-w-3xl items-center gap-2 rounded-xl bg-secondary px-3 py-2 text-sm">
              <Reply className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <span className="min-w-0 flex-1 truncate">
                Replying to <span className="font-semibold">{profiles[replyingTo.user_id]?.full_name ?? profiles[replyingTo.user_id]?.username ?? "Student"}</span>
                <span className="text-muted-foreground"> — {replyingTo.content}</span>
              </span>
              <button
                type="button"
                onClick={() => setReplyingTo(null)}
                className="shrink-0 rounded-full p-1 hover:bg-background"
                aria-label="Cancel reply"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
          <div className="mx-auto flex max-w-3xl items-end gap-2">
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(e as unknown as React.FormEvent);
                }
              }}
              rows={1}
              placeholder={`Message #${activeChannel?.slug ?? "channel"}`}
              className="max-h-40 min-h-[44px] flex-1 resize-none rounded-2xl border-2 border-input bg-cream px-4 py-2.5 outline-none focus:border-ink"
            />
            <button
              type="submit"
              disabled={sending || !draft.trim()}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-coral text-primary-foreground shadow-[var(--shadow-pop)] transition-transform hover:translate-y-[-1px] disabled:opacity-50 disabled:translate-y-0"
              aria-label="Send"
            >
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </div>
        </form>
      </main>
    </div>
    </>
  );
}


function formatTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

const REACTION_EMOJIS = ["👍", "❤️", "😂", "🔥", "👀", "🎉"];

function ReactionBar({
  messageId,
  reactions,
  myId,
  isMe,
  onToggle,
}: {
  messageId: string;
  reactions: { emoji: string; user_id: string }[];
  myId: string;
  isMe: boolean;
  onToggle: (messageId: string, emoji: string) => void;
}) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const grouped = useMemo(() => {
    const m = new Map<string, string[]>();
    for (const r of reactions) {
      const list = m.get(r.emoji) ?? [];
      list.push(r.user_id);
      m.set(r.emoji, list);
    }
    return Array.from(m.entries());
  }, [reactions]);

  if (grouped.length === 0 && !pickerOpen) {
    return (
      <div className={`mt-1 flex ${isMe ? "justify-end" : "justify-start"}`}>
        <button
          onClick={() => setPickerOpen(true)}
          className="rounded-full p-1 text-muted-foreground opacity-0 transition-opacity hover:bg-secondary group-hover:opacity-100 focus:opacity-100"
          aria-label="Add reaction"
        >
          <SmilePlus className="h-3.5 w-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className={`mt-1 flex flex-wrap items-center gap-1 ${isMe ? "justify-end" : "justify-start"}`}>
      {grouped.map(([emoji, userIds]) => (
        <button
          key={emoji}
          onClick={() => onToggle(messageId, emoji)}
          className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-semibold transition-colors ${
            userIds.includes(myId) ? "border-ink bg-mint" : "border-border bg-secondary hover:bg-secondary/70"
          }`}
        >
          <span>{emoji}</span>
          <span>{userIds.length}</span>
        </button>
      ))}
      <div className="relative">
        <button
          onClick={() => setPickerOpen((v) => !v)}
          className="rounded-full p-1 text-muted-foreground hover:bg-secondary"
          aria-label="Add reaction"
        >
          <SmilePlus className="h-3.5 w-3.5" />
        </button>
        {pickerOpen && (
          <div className="absolute bottom-full z-10 mb-1 flex gap-1 rounded-full border-2 border-ink bg-card px-2 py-1 shadow-pop">
            {REACTION_EMOJIS.map((e) => (
              <button
                key={e}
                onClick={() => {
                  onToggle(messageId, e);
                  setPickerOpen(false);
                }}
                className="rounded-full p-1 text-lg hover:bg-secondary"
              >
                {e}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
