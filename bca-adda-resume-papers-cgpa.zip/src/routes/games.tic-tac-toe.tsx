import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Eye, RotateCcw, Hash, Copy, LogIn, Plus, Loader2, Crown, Bot, Users } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SpectateEntry } from "@/components/SpectateEntry";
import { MatchmakingButton } from "@/components/MatchmakingButton";

export const Route = createFileRoute("/games/tic-tac-toe")({
  head: () => ({
    meta: [
      { title: "Tic Tac Toe — Arcade" },
      { name: "description", content: "Three in a row — practice against the bot or challenge a friend in real time." },
      { property: "og:title", content: "Tic Tac Toe" },
      { property: "og:description", content: "Quick three-in-a-row duels, solo or head-to-head." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TicTacToePage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

function TicTacToePage() {
  const [mode, setMode] = useState<"bot" | "multiplayer">("bot");
  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl sm:text-5xl">
        Tic Tac <span className="text-coral">Toe</span>
      </h1>
      <div className="mt-4 grid grid-cols-2 gap-2 rounded-2xl border-2 border-input bg-cream p-1.5">
        <button
          onClick={() => setMode("bot")}
          className={`inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
            mode === "bot" ? "bg-ink text-cream" : "hover:bg-secondary"
          }`}
        >
          <Bot className="h-4 w-4" /> Practice
        </button>
        <button
          onClick={() => setMode("multiplayer")}
          className={`inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
            mode === "multiplayer" ? "bg-ink text-cream" : "hover:bg-secondary"
          }`}
        >
          <Users className="h-4 w-4" /> Play a friend
        </button>
      </div>
      {mode === "bot" ? <BotMode /> : <MultiplayerMode />}
    </section>
  );
}

/* ---------- Practice vs bot ---------- */

type Cell = "X" | "O" | null;
const lines = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

function winner(b: Cell[]): { who: Cell; line: number[] | null } {
  for (const l of lines) {
    const [a, c, d] = l;
    if (b[a] && b[a] === b[c] && b[a] === b[d]) return { who: b[a], line: l };
  }
  return { who: null, line: null };
}

function botMove(b: Cell[]): number {
  const empty = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
  for (const i of empty) {
    const copy = [...b]; copy[i] = "O";
    if (winner(copy).who === "O") return i;
  }
  for (const i of empty) {
    const copy = [...b]; copy[i] = "X";
    if (winner(copy).who === "X") return i;
  }
  if (b[4] === null) return 4;
  const corners = [0, 2, 6, 8].filter((i) => b[i] === null);
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  return empty[Math.floor(Math.random() * empty.length)];
}

function BotMode() {
  const [board, setBoard] = useState<Cell[]>(Array(9).fill(null));
  const [turn, setTurn] = useState<"X" | "O">("X");
  const [score, setScore] = useState({ you: 0, bot: 0, draw: 0 });

  const result = useMemo(() => winner(board), [board]);
  const full = board.every(Boolean);
  const done = result.who || full;

  const play = (i: number) => {
    if (board[i] || done || turn !== "X") return;
    const next = [...board]; next[i] = "X";
    setBoard(next);
    const w = winner(next);
    if (w.who) { setScore((s) => ({ ...s, you: s.you + 1 })); return; }
    if (next.every(Boolean)) { setScore((s) => ({ ...s, draw: s.draw + 1 })); return; }
    setTurn("O");
    setTimeout(() => {
      const m = botMove(next);
      const after = [...next]; after[m] = "O";
      setBoard(after);
      const w2 = winner(after);
      if (w2.who) setScore((s) => ({ ...s, bot: s.bot + 1 }));
      else if (after.every(Boolean)) setScore((s) => ({ ...s, draw: s.draw + 1 }));
      setTurn("X");
    }, 400);
  };

  const reset = () => { setBoard(Array(9).fill(null)); setTurn("X"); };

  const status = result.who === "X" ? "You win! 🎉"
    : result.who === "O" ? "Bot wins 🤖"
    : full ? "Draw 🤝"
    : turn === "X" ? "Your turn (X)" : "Bot thinking…";

  return (
    <>
      <p className="mt-4 font-semibold text-muted-foreground">{status}</p>

      <div className="mt-3 rounded-3xl border-2 border-ink arcade-grid p-4 shadow-soft">
        <div className="grid grid-cols-3 gap-2.5">
          {board.map((c, i) => (
            <button
              key={i}
              onClick={() => play(i)}
              className={`grid aspect-square place-items-center rounded-2xl border-2 border-ink font-display text-5xl shadow-pop transition-transform enabled:hover:-translate-y-0.5 ${
                result.line?.includes(i) ? "animate-glow bg-mint" : "bg-cream"
              } ${c === "X" ? "text-coral" : "text-violet"}`}
              disabled={!!c || !!done || turn !== "X"}
            >
              <span className={c ? "block animate-pop-in" : undefined}>{c}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <div className="flex gap-3 text-sm">
          <span className="chip">You {score.you}</span>
          <span className="chip">Bot {score.bot}</span>
          <span className="chip">Draw {score.draw}</span>
        </div>
        <button
          onClick={reset}
          className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-cream px-4 py-2 text-sm font-bold shadow-pop transition-transform hover:-translate-y-0.5"
        >
          <RotateCcw className="h-4 w-4" /> New round
        </button>
      </div>
    </>
  );
}

/* ---------- Real multiplayer rooms ---------- */

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  board: number[]; // 9 cells, 0 empty, 1 host (X), 2 guest (O)
  turn: number;
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

function MultiplayerMode() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [spectating, setSpectating] = useState(false);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`tic_tac_toe_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "tic_tac_toe_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <div className="grid place-items-center py-16">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="paper mt-6 p-8 text-center">
        <Hash className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play a friend</h2>
        <p className="mt-1 text-muted-foreground">You need an account to open a room.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </div>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("tic_tac_toe_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("tic_tac_toe_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return (
      <div className="mt-6 grid gap-4">
        <div className="paper p-6">
          <h3 className="text-xl">Create a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
          <button
            disabled={busy}
            onClick={createGame}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            New room
          </button>
        </div>
        <div className="paper p-6">
          <h3 className="text-xl">Join a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
          <div className="mt-5 flex gap-2">
            <input
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              maxLength={5}
              placeholder="ABCDE"
              className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
            />
            <button
              disabled={busy || joinCode.length < 4}
              onClick={joinGame}
              className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
            >
              <LogIn className="h-4 w-4" />
              Join
            </button>
          </div>
        </div>
        <SpectateEntry table="tic_tac_toe_games" label="a Tic Tac Toe" onJoin={(g) => { setGame(g); setSpectating(true); }} />

      <MatchmakingButton gameType="tic_tac_toe" gameLabel="Tic Tac Toe" onMatchFound={(code) => { setJoinCode(code); joinGame(); }} />
      </div>
    );
  }

  return <MultiplayerBoard game={game} setGame={setGame} userId={user.id} spectating={spectating} />;
}

function MultiplayerBoard({ game, setGame, userId, spectating = false }: { game: Game; setGame: (g: Game | null) => void; userId: string; spectating?: boolean }) {
  const isHost = game.host_id === userId;
  const me = isHost ? 1 : 2;
  const [playing, setPlaying] = useState<number | null>(null);
  const myTurn = !spectating && game.status === "playing" && game.turn === me;

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const youWon = game.status === "finished" && game.winner_id === userId;
  const draw = game.status === "finished" && !game.winner_id;

  const play = async (cell: number) => {
    if (!myTurn || playing !== null || game.board[cell] !== 0) return;
    setPlaying(cell);
    const { data, error } = await db.rpc("tic_tac_toe_play", { _game_id: game.id, _cell: cell });
    setPlaying(null);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  const leave = async () => {
    if (isHost) await db.rpc("tic_tac_toe_leave_game", { _game_id: game.id });
    setGame(null);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  return (
    <div className="mt-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
          {game.code} <Copy className="h-4 w-4 opacity-60" />
        </button>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent ? (
        <div className="paper mt-4 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
        </div>
      ) : (
        <p className="mt-3 text-center font-semibold text-muted-foreground">
          {game.last_message ?? (myTurn ? "Your move" : "Opponent's move")}
        </p>
      )}

      <div className="mt-4 rounded-3xl border-2 border-ink arcade-grid p-4 shadow-soft">
        <div className="grid grid-cols-3 gap-2.5">
          {game.board.map((c, i) => (
            <button
              key={i}
              onClick={() => play(i)}
              disabled={!myTurn || c !== 0 || game.status !== "playing"}
              className={`grid aspect-square place-items-center rounded-2xl border-2 border-ink font-display text-5xl shadow-pop transition-transform enabled:hover:-translate-y-0.5 bg-cream ${
                c === 1 ? "text-coral" : c === 2 ? "text-violet" : ""
              }`}
            >
              {c === 1 ? "X" : c === 2 ? "O" : ""}
            </button>
          ))}
        </div>
      </div>

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">
            {youWon ? "You won!" : draw ? "It's a draw!" : "You lost — rematch?"}
          </h3>
          <button onClick={leave} className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream">
            Back to lobby
          </button>
        </div>
      )}
    </div>
  );
}
