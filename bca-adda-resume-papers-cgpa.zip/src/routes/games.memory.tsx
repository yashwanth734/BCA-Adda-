import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { RotateCcw, Sparkles } from "lucide-react";

export const Route = createFileRoute("/games/memory")({
  head: () => ({
    meta: [
      { title: "Memory Match — Arcade" },
      { name: "description", content: "Flip cards and find every pair in as few moves as you can." },
      { property: "og:title", content: "Memory Match" },
      { property: "og:description", content: "A quick card-flipping memory game." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Memory,
});

const EMOJIS = ["💻", "🚀", "📚", "🎧", "☕", "🐱", "🌮", "⚽"];

type Card = { id: number; emoji: string; flipped: boolean; matched: boolean };

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function makeDeck(): Card[] {
  const pairs = [...EMOJIS, ...EMOJIS];
  return shuffle(pairs).map((emoji, id) => ({ id, emoji, flipped: false, matched: false }));
}

function Memory() {
  const [cards, setCards] = useState<Card[]>(() => makeDeck());
  const [pick, setPick] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [lock, setLock] = useState(false);

  const won = useMemo(() => cards.every((c) => c.matched), [cards]);
  const found = cards.filter((c) => c.matched).length / 2;

  useEffect(() => {
    if (pick.length !== 2) return;
    setLock(true);
    const [a, b] = pick;
    const match = cards[a].emoji === cards[b].emoji;
    const t = setTimeout(() => {
      setCards((prev) =>
        prev.map((c, i) =>
          i === a || i === b
            ? match
              ? { ...c, matched: true, flipped: true }
              : { ...c, flipped: false }
            : c,
        ),
      );
      setPick([]);
      setMoves((m) => m + 1);
      setLock(false);
    }, 700);
    return () => clearTimeout(t);
  }, [pick, cards]);

  const flip = (i: number) => {
    if (lock || cards[i].flipped || cards[i].matched) return;
    setCards((prev) => prev.map((c, idx) => (idx === i ? { ...c, flipped: true } : c)));
    setPick((p) => [...p, i]);
  };

  const reset = () => {
    setCards(makeDeck());
    setPick([]);
    setMoves(0);
    setLock(false);
  };

  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl sm:text-5xl">
        Memory <span className="text-coral">Match</span>
      </h1>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <span className="chip">Moves {moves}</span>
        <span className="chip">Pairs {found}/8</span>
        {won ? (
          <span className="chip animate-pop-in bg-gold">
            <Sparkles className="h-3.5 w-3.5" /> Cleared!
          </span>
        ) : null}
      </div>

      <div className="mt-6 rounded-3xl border-2 border-ink arcade-grid p-3 shadow-soft">
        <div className="grid grid-cols-4 gap-2.5">
          {cards.map((c, i) => {
            const open = c.flipped || c.matched;
            return (
              <button
                key={c.id}
                onClick={() => flip(i)}
                aria-label={open ? c.emoji : "Hidden card"}
                className="relative aspect-square [perspective:800px]"
              >
                <div
                  className="tile-3d absolute inset-0"
                  style={{ transform: open ? "rotateY(180deg)" : "rotateY(0deg)" }}
                >
                  <div className="face border-2 border-ink bg-gradient-to-br from-violet to-ink text-2xl text-cream shadow-pop">
                    ✦
                  </div>
                  <div
                    className={`face border-2 border-ink text-3xl shadow-pop [transform:rotateY(180deg)] ${
                      c.matched ? "animate-glow bg-mint" : "bg-cream"
                    }`}
                  >
                    {c.emoji}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <button
        onClick={reset}
        className="mt-6 inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-cream px-4 py-2 text-sm font-bold shadow-pop transition-transform hover:-translate-y-0.5"
      >
        <RotateCcw className="h-4 w-4" /> Shuffle
      </button>
    </section>
  );
}
