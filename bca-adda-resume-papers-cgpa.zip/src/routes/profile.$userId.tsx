import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Loader2, Pencil, Check, X, GraduationCap, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { sanitizeHttpsUrl } from "@/lib/urlSafety";
import { uploadFile } from "@/lib/uploadFile";

export const Route = createFileRoute("/profile/$userId")({
  component: ProfilePage,
});

type Profile = {
  id: string;
  username: string;
  full_name: string | null;
  semester: number | null;
  avatar_url: string | null;
  bio: string | null;
  status: string | null;
};

function ProfilePage() {
  const { userId } = Route.useParams();
  const { user } = useAuth();
  const qc = useQueryClient();
  const isMe = user?.id === userId;

  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState("");
  const [status, setStatus] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [saving, setSaving] = useState(false);

  const profileQ = useQuery({
    queryKey: ["profile", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id,username,full_name,semester,avatar_url,bio,status")
        .eq("id", userId)
        .maybeSingle();
      if (error) throw error;
      return data as Profile | null;
    },
  });

  const profile = profileQ.data;

  const achievementsQ = useQuery({
    queryKey: ["achievements", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_achievements")
        .select("achievement_id,earned_at,achievements(title,description,emoji)")
        .eq("user_id", userId)
        .order("earned_at");
      if (error) throw error;
      return (data ?? []) as unknown as {
        achievement_id: string;
        achievements: { title: string; description: string; emoji: string } | null;
      }[];
    },
  });
  const statsQ = useQuery({
    queryKey: ["game_stats", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("game_stats")
        .select("wins,losses,draws")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) throw error;
      return data as { wins: number; losses: number; draws: number } | null;
    },
  });

  useEffect(() => {
    if (!profile) return;
    setFullName(profile.full_name ?? "");
    setStatus(profile.status ?? "");
    setBio(profile.bio ?? "");
    setAvatarUrl(profile.avatar_url ?? "");
  }, [profile]);

  const save = async () => {
    const sanitized = sanitizeHttpsUrl(avatarUrl);
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName.trim() || null,
        status: status.trim() || null,
        bio: bio.trim() || null,
        avatar_url: sanitized,
      })
      .eq("id", userId);
    setSaving(false);
    if (error) return toast.error(error.message);
    if (avatarUrl.trim() && !sanitized) toast.warning("Avatar URL must be a valid https:// link — other formats were blocked");
    toast.success("Profile updated");
    setEditing(false);
    qc.invalidateQueries({ queryKey: ["profile", userId] });
    qc.invalidateQueries({ queryKey: ["profiles"] }); // chat's author lookup cache
  };

  if (profileQ.isLoading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Profile not found</h1>
          <Link to="/chat" className="mt-3 inline-block font-semibold hover:underline">
            Back to chat
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-lg">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="paper mt-6 p-7">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-4">
              <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-full bg-coral text-2xl font-bold text-primary-foreground">
                {profile.avatar_url ? (
                  <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
                ) : (
                  (profile.full_name ?? profile.username).charAt(0).toUpperCase()
                )}
              </div>
              <div>
                <h1 className="text-2xl">{profile.full_name ?? profile.username}</h1>
                <p className="text-sm text-muted-foreground">@{profile.username}</p>
              </div>
            </div>
            {isMe && !editing && (
              <button
                onClick={() => setEditing(true)}
                className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink px-3.5 py-1.5 text-sm font-semibold hover:bg-secondary"
              >
                <Pencil className="h-3.5 w-3.5" /> Edit
              </button>
            )}
          </div>

          {profile.semester && (
            <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs font-semibold">
              <GraduationCap className="h-3.5 w-3.5" /> Semester {profile.semester}
            </div>
          )}

          {editing ? (
            <div className="mt-6 space-y-4">
              <div>
                <label className="text-sm font-medium">Full name</label>
                <input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Your name"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Status</label>
                <input
                  value={status}
                  onChange={(e) => setStatus(e.target.value.slice(0, 60))}
                  placeholder="Currently studying DBMS 📚"
                  maxLength={60}
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Bio</label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value.slice(0, 280))}
                  placeholder="A couple lines about you"
                  maxLength={280}
                  rows={3}
                  className="mt-1.5 w-full resize-none rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
                <p className="mt-1 text-right text-xs text-muted-foreground">{bio.length}/280</p>
              </div>
              <div>
                <label className="text-sm font-medium">Avatar</label>
                <div className="mt-1.5 flex items-center gap-3">
                  <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border-2 border-ink bg-cream px-3.5 py-2.5 text-sm font-semibold hover:bg-secondary">
                    {uploadingAvatar ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                    {uploadingAvatar ? "Uploading…" : "Upload image"}
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      className="hidden"
                      disabled={uploadingAvatar}
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = "";
                        if (!file) return;
                        setUploadingAvatar(true);
                        try {
                          const url = await uploadFile("avatars", file, userId);
                          setAvatarUrl(url);
                        } catch (err) {
                          toast.error(err instanceof Error ? err.message : "Upload failed");
                        } finally {
                          setUploadingAvatar(false);
                        }
                      }}
                    />
                  </label>
                  <span className="text-xs text-muted-foreground">or paste a link below</span>
                </div>
                <input
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="https://…"
                  className="mt-2 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div className="flex gap-2">
                <button
                  disabled={saving}
                  onClick={save}
                  className="inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                  Save
                </button>
                <button
                  onClick={() => setEditing(false)}
                  className="inline-flex items-center gap-2 rounded-full border-2 border-ink px-5 py-2.5 font-semibold hover:bg-secondary"
                >
                  <X className="h-4 w-4" /> Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-5">
              {profile.status && <p className="font-semibold">{profile.status}</p>}
              {profile.bio ? (
                <p className="mt-2 whitespace-pre-wrap text-muted-foreground">{profile.bio}</p>
              ) : (
                isMe && <p className="mt-2 text-sm text-muted-foreground">Add a bio so people know a bit about you.</p>
              )}
            </div>
          )}

          {(statsQ.data && (statsQ.data.wins + statsQ.data.losses + statsQ.data.draws) > 0) && (
            <div className="mt-6 flex items-center gap-4 rounded-2xl bg-secondary px-4 py-3 text-sm font-semibold">
              <span>🏆 {statsQ.data.wins}W</span>
              <span>{statsQ.data.losses}L</span>
              <span>{statsQ.data.draws}D</span>
              <Link to="/leaderboard" className="ml-auto text-xs text-muted-foreground hover:underline">
                View leaderboard →
              </Link>
            </div>
          )}

          <Link to="/projects" className="mt-4 flex items-center justify-between rounded-2xl border-2 border-input px-4 py-3 text-sm font-semibold hover:bg-secondary">
            💼 View projects & portfolio
            <span className="text-xs opacity-70">→</span>
          </Link>

          {isMe && (
            <Link to="/resume" className="mt-3 flex items-center justify-between rounded-2xl border-2 border-input px-4 py-3 text-sm font-semibold hover:bg-secondary">
              📝 Build my resume
              <span className="text-xs opacity-70">→</span>
            </Link>
          )}

          {achievementsQ.data && achievementsQ.data.length > 0 && (
            <div className="mt-5">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Badges</h3>
              <div className="mt-2 flex flex-wrap gap-2">
                {achievementsQ.data.map((a) => (
                  <div
                    key={a.achievement_id}
                    title={a.achievements?.description}
                    className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-gold px-3 py-1.5 text-sm font-semibold"
                  >
                    <span>{a.achievements?.emoji}</span> {a.achievements?.title}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
