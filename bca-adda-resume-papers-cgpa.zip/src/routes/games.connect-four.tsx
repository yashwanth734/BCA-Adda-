import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Circle, Copy, LogIn, Plus, Loader2, Crown, ArrowLeft, Eye } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SpectateEntry } from "@/components/SpectateEntry";
import { MatchmakingButton } from "@/components/MatchmakingButton";

export const Route = createFileRoute("/games/connect-four")({
  head: () => ({
    meta: [
      { title: "Connect Four — Play with a Friend" },
      { name: "description", content: "Real-time multiplayer Connect Four — drop discs, get four in a row, win." },
    ],
  }),
  component: ConnectFourPage,
});

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  board: number[]; // 42 cells, row-major, 7 cols x 6 rows. 0 empty, 1 host, 2 guest
  turn: number; // 1 = host, 2 = guest
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

// Untyped client helper: the generated Database types don't yet know about
// these tables/RPCs — cast through `any` at the boundary and keep our own type.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const COLS = 7;
const ROWS = 6;

function ConnectFourPage() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`connect_four_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "connect_four_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <section className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </section>
    );
  }

  if (!user) {
    return (
      <section className="paper p-8 text-center">
        <Circle className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play Connect Four</h2>
        <p className="mt-1 text-muted-foreground">You need an account to challenge a friend.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </section>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("connect_four_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("connect_four_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  const [spectating, setSpectating] = useState(false);

  if (!game) {
    return (
      <Lobby
        onCreate={createGame}
        onJoin={joinGame}
        joinCode={joinCode}
        setJoinCode={setJoinCode}
        busy={busy}
        onSpectate={(g) => { setGame(g); setSpectating(true); }}
        onMatchFound={(code) => { setJoinCode(code); joinGame(); }}
      />
    );
  }

  return <Board game={game} setGame={setGame} userId={user.id} spectating={spectating} />;
}

function Lobby({
  onCreate,
  onJoin,
  onSpectate,
  onMatchFound,
  joinCode,
  setJoinCode,
  busy,
}: {
  onCreate: () => void;
  onJoin: () => void;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onSpectate: (game: any) => void;
  onMatchFound: (code: string) => void;
  joinCode: string;
  setJoinCode: (s: string) => void;
  busy: boolean;
}) {
  return (
    <section>
      <Link to="/games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All games
      </Link>
      <div className="mt-3 flex items-center gap-3">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
          <Circle className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-4xl">Connect Four</h1>
          <p className="text-muted-foreground">Drop discs, get four in a row before your opponent does.</p>
        </div>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        <div className="paper p-6">
          <h3 className="text-xl">Create a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
          <button
            disabled={busy}
            onClick={onCreate}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            New room
          </button>
        </div>
        <div className="paper p-6">
          <h3 className="text-xl">Join a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
          <div className="mt-5 flex gap-2">
            <input
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              maxLength={5}
              placeholder="ABCDE"
              className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
            />
            <button
              disabled={busy || joinCode.length < 4}
              onClick={onJoin}
              className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
            >
              <LogIn className="h-4 w-4" />
              Join
            </button>
          </div>
        </div>
      </div>

      <div className="paper mt-6 p-5 text-sm text-muted-foreground">
        <strong className="text-foreground">How to play:</strong> Players take turns dropping a disc
        into any column. Discs fall to the lowest open spot. First to line up four discs in a row —
        horizontally, vertically, or diagonally — wins. Full board with no winner is a draw.
      </div>

      <div className="mt-4">
        <SpectateEntry table="connect_four_games" label="a Connect Four" onJoin={onSpectate} />
      </div>

      <div className="mt-4">
        <MatchmakingButton gameType="connect_four" gameLabel="Connect Four" onMatchFound={onMatchFound} />
      </div>
    </section>
  );
}

function Board({ game, setGame, userId, spectating = false }: { game: Game; setGame: (g: Game | null) => void; userId: string; spectating?: boolean }) {
  const isHost = game.host_id === userId;
  const me = isHost ? 1 : 2;
  const [dropping, setDropping] = useState<number | null>(null);
  const myTurn = !spectating && game.status === "playing" && game.turn === me;

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const youWon = game.status === "finished" && game.winner_id === userId;
  const draw = game.status === "finished" && !game.winner_id;

  const drop = async (col: number) => {
    if (!myTurn || dropping !== null) return;
    setDropping(col);
    const { data, error } = await db.rpc("connect_four_drop", { _game_id: game.id, _col: col });
    setDropping(null);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  const leave = async () => {
    if (isHost) await db.rpc("connect_four_leave_game", { _game_id: game.id });
    setGame(null);
    window.location.reload();
  };

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  const columnHeights = useMemo(() => {
    // how many filled cells sit in each column, for the drop-preview hover state
    const heights = new Array(COLS).fill(0);
    for (let c = 0; c < COLS; c++) {
      let filled = 0;
      for (let r = 0; r < ROWS; r++) if (game.board[r * COLS + c] !== 0) filled++;
      heights[c] = filled;
    }
    return heights;
  }, [game.board]);

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-ink text-cream">
            <Circle className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Room</div>
            <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
              {game.code} <Copy className="h-4 w-4 opacity-60" />
            </button>
          </div>
        </div>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {spectating && (
        <div className="mt-4 inline-flex items-center gap-2 rounded-full border-2 border-input bg-secondary px-4 py-1.5 text-sm font-semibold text-muted-foreground">
          <Eye className="h-4 w-4" /> Spectating — read only
        </div>
      )}

      {waitingForOpponent && (
        <div className="paper mt-5 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
          <p className="text-sm text-muted-foreground">They can join from Games → Connect Four → Join a room.</p>
        </div>
      )}

      <div className="mt-6 flex items-center justify-between paper p-4">
        <PlayerTag label="Host" active={game.turn === 1 && game.status === "playing"} color="coral" you={isHost} />
        <div className="text-sm font-semibold text-muted-foreground">
          {game.status === "playing" ? (myTurn ? "Your move" : "Opponent's move") : ""}
        </div>
        <PlayerTag label="Guest" active={game.turn === 2 && game.status === "playing"} color="ink" you={!isHost} />
      </div>

      <div className="mt-4 rounded-3xl border-2 border-ink bg-[#1a3fa8] p-3 shadow-soft sm:p-4">
        <div className="grid gap-1.5 sm:gap-2" style={{ gridTemplateColumns: `repeat(${COLS}, 1fr)` }}>
          {Array.from({ length: COLS }).map((_, c) => (
            <button
              key={c}
              onClick={() => drop(c)}
              disabled={!myTurn || dropping !== null || columnHeights[c] >= ROWS}
              className="group flex flex-col items-center gap-1.5 sm:gap-2 disabled:cursor-not-allowed"
            >
              {Array.from({ length: ROWS }).map((__, r) => {
                const cell = game.board[r * COLS + c];
                return (
                  <div
                    key={r}
                    className={`aspect-square w-full max-w-10 rounded-full border-2 border-black/20 transition-transform sm:max-w-12 ${
                      cell === 1
                        ? "bg-coral"
                        : cell === 2
                          ? "bg-gold"
                          : "bg-cream group-enabled:group-hover:bg-white/70"
                    } ${dropping === c ? "animate-pulse" : ""}`}
                  />
                );
              })}
            </button>
          ))}
        </div>
      </div>

      {game.last_message && (
        <div className="mt-5 paper p-4 text-center font-semibold">{game.last_message}</div>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">
            {youWon ? "You won!" : draw ? "It's a draw!" : "You lost — rematch?"}
          </h3>
          <button onClick={leave} className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream">
            Back to lobby
          </button>
        </div>
      )}
    </section>
  );
}

function PlayerTag({ label, active, color, you }: { label: string; active: boolean; color: "coral" | "ink"; you: boolean }) {
  return (
    <div className={`flex items-center gap-2 rounded-full border-2 px-3 py-1.5 text-sm font-semibold ${active ? "border-ink" : "border-transparent opacity-60"}`}>
      <span className={`h-3.5 w-3.5 rounded-full ${color === "coral" ? "bg-coral" : "bg-gold"}`} />
      {label} {you && "(You)"}
    </div>
  );
}
