import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Dice5, RotateCcw, Coins } from "lucide-react";

export const Route = createFileRoute("/games/bankroll")({
  head: () => ({
    meta: [
      { title: "Bankroll Dice — Arcade" },
      { name: "description", content: "Bet virtual coins on dice: over or under 7." },
    ],
  }),
  component: BankrollGame,
});

type Bet = "under" | "seven" | "over";

const STARTING = 500;

function BankrollGame() {
  const [bankroll, setBankroll] = useState(STARTING);
  const [wager, setWager] = useState(50);
  const [bet, setBet] = useState<Bet>("under");
  const [rolling, setRolling] = useState(false);
  const [dice, setDice] = useState<[number, number]>([1, 1]);
  const [history, setHistory] = useState<{ sum: number; delta: number }[]>([]);
  const [message, setMessage] = useState("Place your bet and roll the dice.");

  const bust = bankroll <= 0;

  function roll() {
    if (rolling || bust) return;
    if (wager <= 0 || wager > bankroll) {
      setMessage("Adjust your wager — it must be between 1 and your bankroll.");
      return;
    }
    setRolling(true);
    let ticks = 0;
    const iv = setInterval(() => {
      setDice([1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)] as [number, number]);
      ticks++;
      if (ticks > 8) {
        clearInterval(iv);
        const d1 = 1 + Math.floor(Math.random() * 6);
        const d2 = 1 + Math.floor(Math.random() * 6);
        const sum = d1 + d2;
        setDice([d1, d2]);
        let delta = -wager;
        let msg = `Rolled ${sum}. You lost ${wager}.`;
        if (bet === "under" && sum < 7) {
          delta = wager;
          msg = `Rolled ${sum} — under 7! You won ${wager}.`;
        } else if (bet === "over" && sum > 7) {
          delta = wager;
          msg = `Rolled ${sum} — over 7! You won ${wager}.`;
        } else if (bet === "seven" && sum === 7) {
          delta = wager * 4;
          msg = `Lucky 7! You won ${delta} (4×).`;
        }
        setBankroll((b) => b + delta);
        setHistory((h) => [{ sum, delta }, ...h].slice(0, 8));
        setMessage(msg);
        setRolling(false);
      }
    }, 70);
  }

  function reset() {
    setBankroll(STARTING);
    setWager(50);
    setBet("under");
    setDice([1, 1]);
    setHistory([]);
    setMessage("Fresh bankroll. Good luck!");
  }

  return (
    <section>
      <span className="chip"><Coins className="h-3.5 w-3.5" /> Virtual coins only</span>
      <h1 className="mt-3 text-4xl sm:text-5xl">Bankroll Dice</h1>
      <p className="mt-2 max-w-xl text-muted-foreground">
        Bet on the sum of two dice. Under 7 or Over 7 pays 1×. Hitting exactly 7 pays 4×.
      </p>

      <div className="mt-6 grid gap-5 md:grid-cols-[1fr_320px]">
        <div className="paper p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Bankroll</div>
              <div className="font-display text-4xl">{bankroll} 🪙</div>
            </div>
            <button
              onClick={reset}
              className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink px-3 py-1.5 text-sm font-semibold hover:bg-secondary"
            >
              <RotateCcw className="h-4 w-4" /> Reset
            </button>
          </div>

          <div className="mt-6 flex items-center justify-center gap-4">
            {dice.map((d, i) => (
              <div
                key={i}
                className={`grid h-24 w-24 place-items-center rounded-2xl bg-cream border-2 border-ink font-display text-5xl shadow-[var(--shadow-pop)] ${rolling ? "animate-pulse" : ""}`}
              >
                {d}
              </div>
            ))}
          </div>

          <p className="mt-5 text-center text-sm text-muted-foreground min-h-[1.25rem]">{message}</p>

          {bust && (
            <div className="mt-4 rounded-xl bg-coral/15 p-3 text-center text-sm font-semibold text-coral">
              You're broke! Tap Reset to start over.
            </div>
          )}
        </div>

        <div className="paper p-6">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Your bet</div>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {(["under", "seven", "over"] as Bet[]).map((b) => (
              <button
                key={b}
                onClick={() => setBet(b)}
                className={`rounded-xl border-2 px-2 py-2 text-sm font-semibold ${
                  bet === b ? "border-ink bg-ink text-cream" : "border-ink/20 bg-cream hover:bg-secondary"
                }`}
              >
                {b === "under" ? "< 7" : b === "over" ? "> 7" : "= 7"}
              </button>
            ))}
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            {bet === "seven" ? "Pays 4×" : "Pays 1×"}
          </div>

          <div className="mt-5 text-xs uppercase tracking-wider text-muted-foreground">Wager</div>
          <div className="mt-2 flex items-center gap-2">
            <input
              type="number"
              min={1}
              max={bankroll}
              value={wager}
              onChange={(e) => setWager(Math.max(1, Math.min(bankroll, Number(e.target.value) || 0)))}
              className="w-24 rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 font-semibold focus:border-ink focus:outline-none"
            />
            <div className="flex gap-1">
              {[10, 50, 100].map((n) => (
                <button
                  key={n}
                  onClick={() => setWager(Math.min(bankroll, n))}
                  className="rounded-full border-2 border-ink/20 px-2 py-1 text-xs font-semibold hover:bg-secondary"
                >
                  +{n}
                </button>
              ))}
              <button
                onClick={() => setWager(bankroll)}
                className="rounded-full border-2 border-ink/20 px-2 py-1 text-xs font-semibold hover:bg-secondary"
              >
                All
              </button>
            </div>
          </div>

          <button
            onClick={roll}
            disabled={rolling || bust}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-4 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-50"
          >
            <Dice5 className="h-5 w-5" /> {rolling ? "Rolling…" : "Roll dice"}
          </button>

          {history.length > 0 && (
            <div className="mt-5">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Last rolls</div>
              <ul className="mt-2 space-y-1 text-sm">
                {history.map((h, i) => (
                  <li key={i} className="flex justify-between">
                    <span>Sum {h.sum}</span>
                    <span className={h.delta > 0 ? "text-mint font-semibold" : "text-coral font-semibold"}>
                      {h.delta > 0 ? `+${h.delta}` : h.delta}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
