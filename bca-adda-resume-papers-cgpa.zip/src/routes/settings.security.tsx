import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ShieldCheck, Loader2, Trash2, Check, AlertTriangle, Clock } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/settings/security")({
  component: SecuritySettingsPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type Factor = { id: string; friendly_name: string | null; factor_type: string; status: string };
type SecurityEvent = { id: number; event_type: string; detail: string | null; created_at: string };

const EVENT_LABELS: Record<string, string> = {
  login_success: "Signed in",
  login_failure: "Failed sign-in attempt",
  password_change: "Password changed",
  mfa_enabled: "Two-factor authentication enabled",
  mfa_disabled: "Two-factor authentication removed",
  logout: "Signed out",
  role_granted: "Role granted",
  role_revoked: "Role revoked",
};

function SecuritySettingsPage() {
  const { user, loading, signOut } = useAuth();
  const qc = useQueryClient();
  const [factors, setFactors] = useState<Factor[]>([]);
  const [loadingFactors, setLoadingFactors] = useState(true);
  const [enrolling, setEnrolling] = useState(false);
  const [qrSvg, setQrSvg] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [factorId, setFactorId] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletePassword, setDeletePassword] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [signingOutAll, setSigningOutAll] = useState(false);

  const eventsQ = useQuery({
    queryKey: ["security_events", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("security_events")
        .select("id,event_type,detail,created_at")
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return (data ?? []) as SecurityEvent[];
    },
  });

  const loadFactors = async () => {
    setLoadingFactors(true);
    const { data, error } = await supabase.auth.mfa.listFactors();
    setLoadingFactors(false);
    if (error) return toast.error(error.message);
    setFactors((data?.totp ?? []) as Factor[]);
  };

  useEffect(() => {
    if (user) loadFactors();
  }, [user]);

  const startEnroll = async () => {
    setEnrolling(true);
    const { data, error } = await supabase.auth.mfa.enroll({ factorType: "totp" });
    setEnrolling(false);
    if (error) return toast.error(error.message);
    setQrSvg(data.totp.qr_code);
    setSecret(data.totp.secret);
    setFactorId(data.id);
  };

  const cancelEnroll = async () => {
    if (factorId) await supabase.auth.mfa.unenroll({ factorId });
    setQrSvg(null); setSecret(null); setFactorId(null); setCode("");
  };

  // logout is the one security event with no corresponding auth-schema
  // state change to react to automatically, so it goes through a narrow,
  // rate-limited, parameterless RPC instead of a direct table insert —
  // login/password/MFA events are now logged server-side by triggers and
  // need no client call at all.
  const logLogout = async () => {
    if (!user) return;
    await db.rpc("log_logout_event");
    qc.invalidateQueries({ queryKey: ["security_events", user.id] });
  };

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!factorId) return;
    setVerifying(true);
    try {
      const { data: challenge, error: challengeError } = await supabase.auth.mfa.challenge({ factorId });
      if (challengeError) throw challengeError;
      const { error: verifyError } = await supabase.auth.mfa.verify({ factorId, challengeId: challenge.id, code: code.trim() });
      if (verifyError) throw verifyError;
      // mfa_enabled is now logged automatically by a database trigger
      // reacting to the factor's status becoming 'verified'.
      toast.success("Two-factor authentication enabled");
      setQrSvg(null); setSecret(null); setFactorId(null); setCode("");
      loadFactors();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't verify that code");
    } finally {
      setVerifying(false);
    }
  };

  const removeFactor = async (id: string) => {
    const { error } = await supabase.auth.mfa.unenroll({ factorId: id });
    if (error) return toast.error(error.message);
    // mfa_disabled is now logged automatically by a database trigger
    // reacting to the factor row being deleted.
    toast.success("Two-factor authentication removed");
    loadFactors();
  };

  const deleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.email || !deletePassword) return;
    setDeleting(true);
    try {
      // re-authenticate first to confirm it's the real user
      const { error: authErr } = await supabase.auth.signInWithPassword({ email: user.email, password: deletePassword });
      if (authErr) {
        // wrong password on a destructive-action re-auth is exactly the
        // kind of thing worth a security-event record — same detection
        // path as the main sign-in form.
        if (typeof (authErr as { status?: number }).status === "number") {
          void db.rpc("log_login_failure", { _email: user.email });
        }
        throw new Error("Incorrect password — account not deleted");
      }
      // then call the SECURITY DEFINER RPC which cascades the deletion
      const { error } = await db.rpc("delete_own_account");
      if (error) throw error;
      toast.success("Your account has been deleted");
      await signOut();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't delete your account");
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in first</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">Sign in</Link>
        </div>
      </div>
    );
  }

  const verifiedFactors = factors.filter((f) => f.status === "verified");

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-lg space-y-6">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-4xl">Security</h1>
        </div>

        {/* Two-factor authentication */}
        <div className="paper p-6">
          <h3 className="text-xl">Two-factor authentication</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Add an authenticator app as a second step at sign-in.
          </p>
          {loadingFactors ? (
            <Loader2 className="mx-auto mt-5 h-5 w-5 animate-spin" />
          ) : qrSvg ? (
            <div className="mt-5">
              <div className="mx-auto w-48 rounded-2xl border-2 border-ink bg-white p-3" dangerouslySetInnerHTML={{ __html: qrSvg }} />
              {secret && (
                <p className="mt-2 text-center text-xs text-muted-foreground">
                  Can't scan? Enter this code manually: <span className="font-mono">{secret}</span>
                </p>
              )}
              <form onSubmit={verify} className="mt-4 flex gap-2">
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="6-digit code"
                  inputMode="numeric"
                  maxLength={6}
                  className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 text-center font-mono text-lg tracking-widest outline-none focus:border-ink"
                />
                <button
                  disabled={verifying || code.length < 6}
                  className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-coral px-4 font-semibold text-primary-foreground disabled:opacity-60"
                >
                  {verifying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                  Verify
                </button>
              </form>
              <button onClick={cancelEnroll} className="mt-3 text-sm text-muted-foreground hover:underline">Cancel</button>
            </div>
          ) : verifiedFactors.length > 0 ? (
            <div className="mt-5 space-y-2">
              {verifiedFactors.map((f) => (
                <div key={f.id} className="flex items-center justify-between rounded-xl bg-mint px-4 py-3">
                  <span className="inline-flex items-center gap-2 font-semibold">
                    <ShieldCheck className="h-4 w-4" /> {f.friendly_name ?? "Authenticator app"} — active
                  </span>
                  <button onClick={() => removeFactor(f.id)} className="rounded-lg p-1.5 hover:bg-background" aria-label="Remove">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <button
              disabled={enrolling}
              onClick={startEnroll}
              className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
            >
              {enrolling ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              Set up two-factor authentication
            </button>
          )}
        </div>

        {/* Recent security events */}
        <div className="paper p-6">
          <h3 className="text-xl">Recent security events</h3>
          <p className="mt-1 text-sm text-muted-foreground">The last 20 security-related actions on your account.</p>
          {eventsQ.isLoading ? (
            <Loader2 className="mx-auto mt-4 h-5 w-5 animate-spin" />
          ) : (eventsQ.data ?? []).length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">No events recorded yet.</p>
          ) : (
            <ul className="mt-4 divide-y divide-border">
              {(eventsQ.data ?? []).map((e) => (
                <li key={e.id} className="flex items-start gap-3 py-2.5">
                  <Clock className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-semibold">{EVENT_LABELS[e.event_type] ?? e.event_type}</p>
                    {e.detail && <p className="text-xs text-muted-foreground">{e.detail}</p>}
                    <p className="text-xs text-muted-foreground">
                      {new Date(e.created_at).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Sign out */}
        <div className="paper p-6">
          <h3 className="text-xl">Sessions</h3>
          <p className="mt-1 text-sm text-muted-foreground">Sign out of this device, or everywhere you're currently signed in.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={async () => {
                // log while the session is still valid, THEN sign out —
                // doing it in the other order races against the session
                // being invalidated before the log write lands.
                await logLogout();
                await signOut();
              }}
              className="inline-flex items-center gap-2 rounded-full border-2 border-ink px-5 py-2.5 font-semibold hover:bg-secondary"
            >
              Sign out here
            </button>
            <button
              onClick={async () => {
                setSigningOutAll(true);
                await logLogout();
                const { error } = await supabase.auth.signOut({ scope: "global" });
                setSigningOutAll(false);
                if (error) return toast.error(error.message);
                toast.success("Signed out everywhere");
              }}
              disabled={signingOutAll}
              className="inline-flex items-center gap-2 rounded-full border-2 border-coral px-5 py-2.5 font-semibold text-coral hover:bg-coral/10 disabled:opacity-60"
            >
              {signingOutAll && <Loader2 className="h-4 w-4 animate-spin" />}
              Sign out of all devices
            </button>
          </div>
        </div>

        {/* Account deletion */}
        <div className="paper border-coral/40 p-6">
          <h3 className="flex items-center gap-2 text-xl text-coral">
            <AlertTriangle className="h-5 w-5" /> Delete account
          </h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Permanently deletes your account and all associated data. This cannot be undone.
          </p>
          {!showDeleteConfirm ? (
            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="mt-4 inline-flex items-center gap-2 rounded-full border-2 border-coral px-5 py-2.5 text-sm font-semibold text-coral hover:bg-coral/10"
            >
              Delete my account
            </button>
          ) : (
            <form onSubmit={deleteAccount} className="mt-4 space-y-3">
              <p className="text-sm font-semibold">Enter your password to confirm:</p>
              <input
                type="password"
                value={deletePassword}
                onChange={(e) => setDeletePassword(e.target.value)}
                placeholder="Your current password"
                autoComplete="current-password"
                className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-coral"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={deleting || !deletePassword}
                  className="inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground disabled:opacity-60"
                >
                  {deleting && <Loader2 className="h-4 w-4 animate-spin" />}
                  Confirm deletion
                </button>
                <button type="button" onClick={() => { setShowDeleteConfirm(false); setDeletePassword(""); }} className="rounded-full border-2 border-ink px-5 py-2.5 font-semibold hover:bg-secondary">
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
