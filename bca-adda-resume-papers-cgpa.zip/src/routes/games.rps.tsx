import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RotateCcw, Hash, Copy, LogIn, Plus, Loader2, Bot, Users } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/games/rps")({
  head: () => ({
    meta: [
      { title: "Rock Paper Scissors — Arcade" },
      { name: "description", content: "Best-of-five rock paper scissors — vs a bot or a friend in real time." },
      { property: "og:title", content: "Rock Paper Scissors" },
      { property: "og:description", content: "Classic standoff, instant results." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RPSPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type Move = "rock" | "paper" | "scissors";
const ICONS: Record<Move, string> = { rock: "🪨", paper: "📄", scissors: "✂️" };
const MOVES: Move[] = ["rock", "paper", "scissors"];

function RPSPage() {
  const [mode, setMode] = useState<"bot" | "multiplayer">("bot");
  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl sm:text-5xl">
        Rock · Paper · <span className="text-coral">Scissors</span>
      </h1>
      <div className="mt-4 grid grid-cols-2 gap-2 rounded-2xl border-2 border-input bg-cream p-1.5">
        <button
          onClick={() => setMode("bot")}
          className={`inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
            mode === "bot" ? "bg-ink text-cream" : "hover:bg-secondary"
          }`}
        >
          <Bot className="h-4 w-4" /> Practice
        </button>
        <button
          onClick={() => setMode("multiplayer")}
          className={`inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
            mode === "multiplayer" ? "bg-ink text-cream" : "hover:bg-secondary"
          }`}
        >
          <Users className="h-4 w-4" /> Play a friend
        </button>
      </div>
      {mode === "bot" ? <BotMode /> : <MultiplayerMode />}
    </section>
  );
}

/* ---------- Practice vs bot ---------- */

function judge(a: Move, b: Move): "win" | "lose" | "draw" {
  if (a === b) return "draw";
  if (
    (a === "rock" && b === "scissors") ||
    (a === "paper" && b === "rock") ||
    (a === "scissors" && b === "paper")
  )
    return "win";
  return "lose";
}

function BotMode() {
  const [you, setYou] = useState<Move | null>(null);
  const [bot, setBot] = useState<Move | null>(null);
  const [score, setScore] = useState({ you: 0, bot: 0 });
  const [last, setLast] = useState<string>("Pick your move");
  const [outcome, setOutcome] = useState<"win" | "lose" | "draw" | null>(null);
  const [round, setRound] = useState(0);

  const play = (m: Move) => {
    const b = MOVES[Math.floor(Math.random() * 3)];
    setYou(m);
    setBot(b);
    setRound((r) => r + 1);
    const r = judge(m, b);
    setOutcome(r);
    if (r === "win") {
      setScore((s) => ({ ...s, you: s.you + 1 }));
      setLast("You win this round!");
    } else if (r === "lose") {
      setScore((s) => ({ ...s, bot: s.bot + 1 }));
      setLast("Bot takes it.");
    } else setLast("Draw — go again.");
  };

  const reset = () => {
    setScore({ you: 0, bot: 0 });
    setYou(null);
    setBot(null);
    setOutcome(null);
    setLast("Pick your move");
  };

  const banner =
    outcome === "win"
      ? "bg-mint"
      : outcome === "lose"
        ? "bg-coral/30"
        : outcome === "draw"
          ? "bg-secondary"
          : "bg-background/60";

  return (
    <>
      <p className="mt-1 text-muted-foreground">First to 5 wins.</p>

      <div className="mt-6 overflow-hidden rounded-3xl border-2 border-ink arcade-grid shadow-soft">
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 p-6 text-center">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">You</div>
            <div
              key={`y${round}`}
              className="mt-2 grid h-24 place-items-center rounded-2xl border-2 border-ink bg-cream text-6xl shadow-pop animate-pop-in"
            >
              {you ? ICONS[you] : "❓"}
            </div>
            <div className="mt-2 font-display text-3xl">{score.you}</div>
          </div>
          <div className="font-display text-2xl text-muted-foreground">vs</div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Bot</div>
            <div
              key={`b${round}`}
              className="mt-2 grid h-24 place-items-center rounded-2xl border-2 border-ink bg-ink text-6xl text-cream shadow-pop animate-pop-in"
            >
              {bot ? ICONS[bot] : "❓"}
            </div>
            <div className="mt-2 font-display text-3xl">{score.bot}</div>
          </div>
        </div>
        <p className={`border-t-2 border-ink py-2 text-center text-sm font-bold ${banner}`}>{last}</p>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-3">
        {MOVES.map((m) => (
          <button key={m} onClick={() => play(m)} className="game-card sheen py-5 text-4xl" aria-label={m}>
            {ICONS[m]}
          </button>
        ))}
      </div>

      <button
        onClick={reset}
        className="mt-5 inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold text-muted-foreground hover:bg-secondary"
      >
        <RotateCcw className="h-4 w-4" /> Reset score
      </button>
    </>
  );
}

/* ---------- Real multiplayer rooms ---------- */

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  round: number;
  host_score: number;
  guest_score: number;
  host_picked: boolean;
  guest_picked: boolean;
  last_host_choice: Move | null;
  last_guest_choice: Move | null;
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

function MultiplayerMode() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [picked, setPicked] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`rps_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "rps_games", filter: `id=eq.${game.id}` },
        (payload) => {
          const next = payload.new as unknown as Game;
          setGame(next);
          setPicked(false); // a fresh round has started (or match ended)
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <div className="grid place-items-center py-16">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="paper mt-6 p-8 text-center">
        <Hash className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play a friend</h2>
        <p className="mt-1 text-muted-foreground">You need an account to open a room.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </div>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("rps_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("rps_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return (
      <div className="mt-6 grid gap-4">
        <div className="paper p-6">
          <h3 className="text-xl">Create a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
          <button
            disabled={busy}
            onClick={createGame}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            New room
          </button>
        </div>
        <div className="paper p-6">
          <h3 className="text-xl">Join a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
          <div className="mt-5 flex gap-2">
            <input
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              maxLength={5}
              placeholder="ABCDE"
              className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
            />
            <button
              disabled={busy || joinCode.length < 4}
              onClick={joinGame}
              className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
            >
              <LogIn className="h-4 w-4" />
              Join
            </button>
          </div>
        </div>
      </div>
    );
  }

  return <MultiplayerBoard game={game} setGame={setGame} userId={user.id} picked={picked} setPicked={setPicked} />;
}

function MultiplayerBoard({
  game,
  setGame,
  userId,
  picked,
  setPicked,
}: {
  game: Game;
  setGame: (g: Game | null) => void;
  userId: string;
  picked: boolean;
  setPicked: (b: boolean) => void;
}) {
  const isHost = game.host_id === userId;
  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const myPicked = isHost ? game.host_picked : game.guest_picked;
  const oppPicked = isHost ? game.guest_picked : game.host_picked;
  const youWon = game.status === "finished" && game.winner_id === userId;

  const choose = async (m: Move) => {
    if (game.status !== "playing" || myPicked || picked) return;
    setPicked(true);
    const { data, error } = await db.rpc("rps_choose", { _game_id: game.id, _choice: m });
    if (error) {
      setPicked(false);
      return toast.error(error.message);
    }
    if (data) setGame(data as Game);
  };

  const leave = async () => {
    if (isHost) await db.rpc("rps_leave_game", { _game_id: game.id });
    setGame(null);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  return (
    <div className="mt-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
          {game.code} <Copy className="h-4 w-4 opacity-60" />
        </button>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent ? (
        <div className="paper mt-4 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
        </div>
      ) : (
        <div className="mt-4 overflow-hidden rounded-3xl border-2 border-ink arcade-grid shadow-soft">
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 p-6 text-center">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">You</div>
              <div className="mt-2 grid h-24 place-items-center rounded-2xl border-2 border-ink bg-cream text-6xl shadow-pop">
                {game.status === "finished"
                  ? ICONS[(isHost ? game.last_host_choice : game.last_guest_choice) ?? "rock"]
                  : myPicked
                    ? "✅"
                    : "❓"}
              </div>
              <div className="mt-2 font-display text-3xl">{isHost ? game.host_score : game.guest_score}</div>
            </div>
            <div className="font-display text-2xl text-muted-foreground">vs</div>
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Opponent</div>
              <div className="mt-2 grid h-24 place-items-center rounded-2xl border-2 border-ink bg-ink text-6xl text-cream shadow-pop">
                {game.status === "finished"
                  ? ICONS[(isHost ? game.last_guest_choice : game.last_host_choice) ?? "rock"]
                  : oppPicked
                    ? "✅"
                    : "❓"}
              </div>
              <div className="mt-2 font-display text-3xl">{isHost ? game.guest_score : game.host_score}</div>
            </div>
          </div>
          <p className="border-t-2 border-ink bg-background/60 py-2 text-center text-sm font-bold">
            {game.last_message ?? "First to 3 wins"}
          </p>
        </div>
      )}

      {game.status === "playing" && (
        <div className="mt-5 grid grid-cols-3 gap-3">
          {MOVES.map((m) => (
            <button
              key={m}
              onClick={() => choose(m)}
              disabled={myPicked}
              className="game-card sheen py-5 text-4xl disabled:opacity-40"
              aria-label={m}
            >
              {ICONS[m]}
            </button>
          ))}
        </div>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          <h3 className="text-2xl">{youWon ? "You won the match! 🎉" : "You lost — rematch?"}</h3>
          <button onClick={leave} className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream">
            Back to lobby
          </button>
        </div>
      )}
    </div>
  );
}
