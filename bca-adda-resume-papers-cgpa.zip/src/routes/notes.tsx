import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, BookOpen, Plus, Loader2, ExternalLink, Trash2, Search, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";
import { sanitizeHttpsUrl } from "@/lib/urlSafety";
import { uploadFile } from "@/lib/uploadFile";

export const Route = createFileRoute("/notes")({
  head: () => ({
    meta: [
      { title: "Notes & Resources — BCA Adda" },
      { name: "description", content: "Shared notes and resource links, organized by subject." },
    ],
  }),
  component: NotesPage,
});

type Note = {
  id: string;
  user_id: string;
  subject_name: string;
  title: string;
  url: string | null;
  content: string | null;
  created_at: string;
  profiles: { username: string; full_name: string | null } | null;
};

function NotesPage() {
  const { user, loading } = useAuth();
  const { isTeacher } = useRole();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [subjectName, setSubjectName] = useState("");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);

  const notesQ = useQuery({
    queryKey: ["subject_notes"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("subject_notes")
        .select("id,user_id,subject_name,title,url,content,created_at,profiles(username,full_name)")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return (data ?? []) as unknown as Note[];
    },
  });

  const notes = notesQ.data ?? [];

  const subjects = useMemo(() => {
    const set = new Set(notes.map((n) => n.subject_name));
    return Array.from(set).sort();
  }, [notes]);

  const [activeSubject, setActiveSubject] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return notes.filter((n) => {
      if (activeSubject && n.subject_name !== activeSubject) return false;
      if (search.trim() && !`${n.title} ${n.subject_name} ${n.content ?? ""}`.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [notes, activeSubject, search]);

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to see shared notes</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  // Same https-only allowlist used for profile avatars — blocks
  // javascript:/data:/vbscript:/file:/about: and everything else that
  // isn't a plain https link. This note's url is rendered as a clickable
  // <a href>, so an unsafe scheme here is directly exploitable (unlike
  // an <img src>, which doesn't execute javascript: URIs).
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectName.trim() || !title.trim() || (!url.trim() && !content.trim())) {
      toast.error("Add a subject, title, and either a link or some notes");
      return;
    }
    const sanitizedUrl = url.trim() ? sanitizeHttpsUrl(url) : null;
    if (url.trim() && !sanitizedUrl) {
      toast.error("Link must be a valid https:// URL");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("subject_notes").insert({
      user_id: user.id,
      subject_name: subjectName.trim(),
      title: title.trim(),
      url: sanitizedUrl,
      content: content.trim() || null,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Shared with everyone");
    setSubjectName("");
    setTitle("");
    setUrl("");
    setContent("");
    setShowForm(false);
    qc.invalidateQueries({ queryKey: ["subject_notes"] });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this note?")) return;
    const { error } = await supabase.from("subject_notes").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["subject_notes"] });
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-2xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
              <BookOpen className="h-6 w-6" />
            </div>
            <h1 className="text-4xl">Notes & Resources</h1>
          </div>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
          >
            <Plus className="h-4 w-4" /> Share something
          </button>
        </div>

        {showForm && (
          <form onSubmit={submit} className="paper mt-5 space-y-3 p-5">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">Subject</label>
                <input
                  value={subjectName}
                  onChange={(e) => setSubjectName(e.target.value)}
                  placeholder="e.g. DBMS"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Title</label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Unit 3 summary"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Link or file (optional)</label>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://drive.google.com/…"
                  className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
                <label className="inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-xl border-2 border-ink bg-cream px-3 py-2.5 text-sm font-semibold hover:bg-secondary">
                  {uploadingFile ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif,application/pdf"
                    className="hidden"
                    disabled={uploadingFile}
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      e.target.value = "";
                      if (!file || !user) return;
                      setUploadingFile(true);
                      try {
                        const uploadedUrl = await uploadFile("note-attachments", file, user.id);
                        setUrl(uploadedUrl);
                        toast.success("File attached");
                      } catch (err) {
                        toast.error(err instanceof Error ? err.message : "Upload failed");
                      } finally {
                        setUploadingFile(false);
                      }
                    }}
                  />
                </label>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">Paste a link, or upload an image/PDF (max 10MB) — uploading fills in the link field above.</p>
            </div>
            <div>
              <label className="text-sm font-medium">Or type notes directly</label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value.slice(0, 5000))}
                rows={4}
                placeholder="Paste or write your notes…"
                className="mt-1.5 w-full resize-none rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <button
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 font-semibold text-cream disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Share with everyone
            </button>
          </form>
        )}

        <div className="paper mt-5 p-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search notes…"
              className="w-full rounded-xl border-2 border-input bg-cream py-2.5 pl-10 pr-3.5 outline-none focus:border-ink"
            />
          </div>
          {subjects.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              <button
                onClick={() => setActiveSubject(null)}
                className={`rounded-full px-3 py-1 text-xs font-semibold ${!activeSubject ? "bg-ink text-cream" : "bg-secondary hover:bg-secondary/70"}`}
              >
                All
              </button>
              {subjects.map((s) => (
                <button
                  key={s}
                  onClick={() => setActiveSubject(s)}
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${activeSubject === s ? "bg-ink text-cream" : "bg-secondary hover:bg-secondary/70"}`}
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {notesQ.isLoading ? (
          <div className="mt-8 grid place-items-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <p className="mt-8 text-center text-muted-foreground">
            {notes.length === 0 ? "No notes shared yet — be the first!" : "Nothing matches that search."}
          </p>
        ) : (
          <ul className="mt-5 space-y-3">
            {filtered.map((n) => {
              const canDelete = n.user_id === user.id || isTeacher;
              return (
                <li key={n.id} className="paper p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <span className="chip">{n.subject_name}</span>
                      <h3 className="mt-1.5 text-lg font-bold">{n.title}</h3>
                    </div>
                    {canDelete && (
                      <button onClick={() => remove(n.id)} className="shrink-0 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-coral" aria-label="Delete">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  {n.content && <p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{n.content}</p>}
                  {n.url && (
                    <a
                      href={n.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold text-coral hover:underline"
                    >
                      Open resource <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  )}
                  <p className="mt-2 text-xs text-muted-foreground">
                    Shared by {n.profiles?.full_name ?? n.profiles?.username ?? "a student"}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
