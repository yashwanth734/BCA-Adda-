import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, FileText, Plus, Loader2, ExternalLink, Trash2, Search, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";
import { uploadFile } from "@/lib/uploadFile";

export const Route = createFileRoute("/question-papers")({
  head: () => ({
    meta: [
      { title: "Question Papers — BCA Adda" },
      { name: "description", content: "Previous year question papers, organized by subject and semester." },
    ],
  }),
  component: QuestionPapersPage,
});

const EXAM_TYPES: Record<string, string> = {
  mid_sem: "Mid Sem",
  end_sem: "End Sem",
  internal: "Internal",
  other: "Other",
};

type Paper = {
  id: string;
  user_id: string;
  subject_name: string;
  semester: number | null;
  year: number | null;
  exam_type: string | null;
  title: string;
  url: string;
  created_at: string;
  profiles: { username: string; full_name: string | null } | null;
};

function QuestionPapersPage() {
  const { user, loading } = useAuth();
  const { isTeacher } = useRole();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [semesterFilter, setSemesterFilter] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [subjectName, setSubjectName] = useState("");
  const [title, setTitle] = useState("");
  const [semester, setSemester] = useState("");
  const [year, setYear] = useState("");
  const [examType, setExamType] = useState("end_sem");
  const [url, setUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const papersQ = useQuery({
    queryKey: ["question_papers"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("question_papers")
        .select("id,user_id,subject_name,semester,year,exam_type,title,url,created_at,profiles(username,full_name)")
        .order("year", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      return (data ?? []) as unknown as Paper[];
    },
  });

  const papers = papersQ.data ?? [];

  const subjects = useMemo(() => Array.from(new Set(papers.map((p) => p.subject_name))).sort(), [papers]);
  const [activeSubject, setActiveSubject] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return papers.filter((p) => {
      if (activeSubject && p.subject_name !== activeSubject) return false;
      if (semesterFilter && p.semester !== semesterFilter) return false;
      if (search.trim() && !`${p.title} ${p.subject_name}`.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [papers, activeSubject, semesterFilter, search]);

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to see question papers</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectName.trim() || !title.trim() || !url) {
      toast.error("Add a subject, title, and upload the paper");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("question_papers").insert({
      user_id: user.id,
      subject_name: subjectName.trim(),
      title: title.trim(),
      semester: semester ? parseInt(semester, 10) : null,
      year: year ? parseInt(year, 10) : null,
      exam_type: examType || null,
      url,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Question paper shared");
    setSubjectName("");
    setTitle("");
    setSemester("");
    setYear("");
    setUrl("");
    setShowForm(false);
    qc.invalidateQueries({ queryKey: ["question_papers"] });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this question paper?")) return;
    const { error } = await supabase.from("question_papers").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["question_papers"] });
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-2xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
              <FileText className="h-6 w-6" />
            </div>
            <h1 className="text-4xl">Question Papers</h1>
          </div>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
          >
            <Plus className="h-4 w-4" /> Upload
          </button>
        </div>

        {showForm && (
          <form onSubmit={submit} className="paper mt-5 space-y-3 p-5">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">Subject</label>
                <input
                  value={subjectName}
                  onChange={(e) => setSubjectName(e.target.value)}
                  placeholder="e.g. DBMS"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Title</label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="End Sem 2025"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <div>
                <label className="text-sm font-medium">Semester</label>
                <input
                  value={semester}
                  onChange={(e) => setSemester(e.target.value.replace(/\D/g, "").slice(0, 1))}
                  placeholder="1-8"
                  inputMode="numeric"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Year</label>
                <input
                  value={year}
                  onChange={(e) => setYear(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  placeholder="2025"
                  inputMode="numeric"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Exam type</label>
                <select
                  value={examType}
                  onChange={(e) => setExamType(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                >
                  {Object.entries(EXAM_TYPES).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Paper file (PDF or image)</label>
              <div className="mt-1.5 flex items-center gap-3">
                <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border-2 border-ink bg-cream px-3.5 py-2.5 text-sm font-semibold hover:bg-secondary">
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  {uploading ? "Uploading…" : url ? "Replace file" : "Upload file"}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif,application/pdf"
                    className="hidden"
                    disabled={uploading}
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      e.target.value = "";
                      if (!file) return;
                      setUploading(true);
                      try {
                        const uploadedUrl = await uploadFile("note-attachments", file, user.id);
                        setUrl(uploadedUrl);
                        toast.success("File uploaded");
                      } catch (err) {
                        toast.error(err instanceof Error ? err.message : "Upload failed");
                      } finally {
                        setUploading(false);
                      }
                    }}
                  />
                </label>
                {url && <span className="text-xs text-mint">✓ File attached</span>}
              </div>
            </div>
            <button
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 font-semibold text-cream disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Share with everyone
            </button>
          </form>
        )}

        <div className="paper mt-5 p-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search papers…"
              className="w-full rounded-xl border-2 border-input bg-cream py-2.5 pl-10 pr-3.5 outline-none focus:border-ink"
            />
          </div>
          {subjects.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              <button
                onClick={() => setActiveSubject(null)}
                className={`rounded-full px-3 py-1 text-xs font-semibold ${!activeSubject ? "bg-ink text-cream" : "bg-secondary hover:bg-secondary/70"}`}
              >
                All subjects
              </button>
              {subjects.map((s) => (
                <button
                  key={s}
                  onClick={() => setActiveSubject(s)}
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${activeSubject === s ? "bg-ink text-cream" : "bg-secondary hover:bg-secondary/70"}`}
                >
                  {s}
                </button>
              ))}
            </div>
          )}
          <div className="mt-2 flex flex-wrap gap-1.5">
            <button
              onClick={() => setSemesterFilter(null)}
              className={`rounded-full px-3 py-1 text-xs font-semibold ${!semesterFilter ? "bg-ink text-cream" : "bg-secondary hover:bg-secondary/70"}`}
            >
              All semesters
            </button>
            {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
              <button
                key={s}
                onClick={() => setSemesterFilter(s)}
                className={`rounded-full px-3 py-1 text-xs font-semibold ${semesterFilter === s ? "bg-ink text-cream" : "bg-secondary hover:bg-secondary/70"}`}
              >
                Sem {s}
              </button>
            ))}
          </div>
        </div>

        {papersQ.isLoading ? (
          <div className="mt-8 grid place-items-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <p className="mt-8 text-center text-muted-foreground">
            {papers.length === 0 ? "No question papers uploaded yet — be the first!" : "Nothing matches those filters."}
          </p>
        ) : (
          <ul className="mt-5 space-y-3">
            {filtered.map((p) => {
              const canDelete = p.user_id === user.id || isTeacher;
              return (
                <li key={p.id} className="paper p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="chip">{p.subject_name}</span>
                        {p.semester && <span className="chip">Sem {p.semester}</span>}
                        {p.year && <span className="chip">{p.year}</span>}
                        {p.exam_type && <span className="chip bg-gold">{EXAM_TYPES[p.exam_type] ?? p.exam_type}</span>}
                      </div>
                      <h3 className="mt-1.5 text-lg font-bold">{p.title}</h3>
                    </div>
                    {canDelete && (
                      <button onClick={() => remove(p.id)} className="shrink-0 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-coral" aria-label="Delete">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold text-coral hover:underline"
                  >
                    Open paper <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Shared by {p.profiles?.full_name ?? p.profiles?.username ?? "a student"}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
