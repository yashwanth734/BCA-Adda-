import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Loader2 } from "lucide-react";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";
import { ConnectionWatchdog } from "@/components/ConnectionWatchdog";

// apply saved theme before first render to avoid flash
if (typeof window !== "undefined") {
  const saved = localStorage.getItem("theme");
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  if (saved === "dark" || (!saved && prefersDark)) document.documentElement.classList.add("dark");
}

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:opacity-90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  const [autoRetrying, setAutoRetrying] = useState(true);

  useEffect(() => {
    console.error("Root route error boundary caught:", error);

    // Auto-recovery: many crashes here are transient (a network blip
    // mid-request, a realtime channel that dropped) rather than a real
    // bug, so try once automatically before asking the person to do
    // anything. Guarded against retry loops via sessionStorage: only
    // auto-retry once per 10-second window, so a genuinely broken route
    // still falls through to the manual "Try again" / "Go home" buttons
    // instead of silently flashing forever.
    const key = "bca-adda-last-auto-retry";
    const last = Number(sessionStorage.getItem(key) ?? 0);
    const now = Date.now();
    if (now - last > 10_000) {
      sessionStorage.setItem(key, String(now));
      const timer = setTimeout(() => {
        router.invalidate();
        reset();
      }, 1200);
      return () => clearTimeout(timer);
    } else {
      setAutoRetrying(false);
    }
  }, [error, reset, router]);

  if (autoRetrying) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="max-w-md text-center">
          <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">Something hiccupped — retrying…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:opacity-90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "BCA Adda — Chat for BCA students" },
      { name: "description", content: "A friendly chat hangout built for BCA students — talk code, assignments, placements and college life." },
      { property: "og:title", content: "BCA Adda — Chat for BCA students" },
      { property: "og:description", content: "Friendly chat rooms for BCA students. Talk code, assignments, placements and more." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      {
        // Defense-in-depth only — a <meta> CSP can't set frame-ancestors or
        // report-uri (those need a real HTTP header from your host/CDN).
        // 'unsafe-inline' is kept on script/style because this is an SSR
        // app and inline hydration/style attributes are used throughout;
        // tightening further needs a nonce-based setup wired at the server,
        // which isn't testable from this sandbox — verify before removing it.
        "http-equiv": "Content-Security-Policy",
        content:
          "default-src 'self'; " +
          "script-src 'self' 'unsafe-inline'; " +
          "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
          "font-src 'self' https://fonts.gstatic.com; " +
          "img-src 'self' data: https:; " +
          "connect-src 'self' https://*.supabase.co wss://*.supabase.co; " +
          "object-src 'none'; " +
          "base-uri 'self'",
      },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap",
      },
      { rel: "stylesheet", href: appCss },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Outlet />
        <Toaster />
        <ConnectionWatchdog />
      </AuthProvider>
    </QueryClientProvider>
  );
}
