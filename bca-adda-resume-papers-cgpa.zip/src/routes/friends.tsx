import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, UserPlus, Check, X, Loader2, MessageCircle, Search, Users } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/friends")({
  component: FriendsPage,
});

type Profile = { id: string; username: string; full_name: string | null; avatar_url: string | null };
type Request = {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: string;
  requester: Profile | null;
  addressee: Profile | null;
};

function FriendsPage() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<Profile[]>([]);
  const [startingDm, setStartingDm] = useState<string | null>(null);

  const requestsQ = useQuery({
    queryKey: ["friend_requests", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("friend_requests")
        .select("id,requester_id,addressee_id,status,requester:requester_id(id,username,full_name,avatar_url),addressee:addressee_id(id,username,full_name,avatar_url)")
        .or(`requester_id.eq.${user!.id},addressee_id.eq.${user!.id}`)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Request[];
    },
  });

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to see friends</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  const requests = requestsQ.data ?? [];
  const incoming = requests.filter((r) => r.status === "pending" && r.addressee_id === user.id);
  const outgoing = requests.filter((r) => r.status === "pending" && r.requester_id === user.id);
  const friends = requests.filter((r) => r.status === "accepted");

  const runSearch = async (q: string) => {
    setSearch(q);
    if (q.trim().length < 2) {
      setResults([]);
      return;
    }
    setSearching(true);
    const { data, error } = await supabase
      .from("profiles")
      .select("id,username,full_name,avatar_url")
      .neq("id", user.id)
      .ilike("username", `%${q.trim()}%`)
      .limit(10);
    setSearching(false);
    if (error) return toast.error(error.message);
    setResults((data ?? []) as Profile[]);
  };

  const sendRequest = async (addresseeId: string) => {
    const { error } = await supabase.from("friend_requests").insert({ requester_id: user.id, addressee_id: addresseeId });
    if (error) return toast.error(error.message);
    toast.success("Friend request sent");
    qc.invalidateQueries({ queryKey: ["friend_requests", user.id] });
  };

  const accept = async (requestId: string) => {
    const { error } = await (supabase as any).rpc("accept_friend_request", { _request_id: requestId });
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["friend_requests", user.id] });
  };

  const decline = async (requestId: string) => {
    const { error } = await supabase.from("friend_requests").update({ status: "declined", responded_at: new Date().toISOString() }).eq("id", requestId);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["friend_requests", user.id] });
  };

  const messageFriend = async (otherUserId: string) => {
    setStartingDm(otherUserId);
    const { data, error } = await (supabase as any).rpc("start_dm_thread", { _other_user: otherUserId });
    setStartingDm(null);
    if (error) return toast.error(error.message);
    navigate({ to: "/dm/$threadId", params: { threadId: data.id } });
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-lg">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Users className="h-6 w-6" />
          </div>
          <h1 className="text-4xl">Friends</h1>
        </div>

        <div className="paper mt-6 p-5">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => runSearch(e.target.value)}
              placeholder="Search by username"
              className="w-full rounded-xl border-2 border-input bg-cream py-2.5 pl-10 pr-3.5 outline-none focus:border-ink"
            />
          </div>
          {searching && <Loader2 className="mx-auto mt-3 h-4 w-4 animate-spin" />}
          {results.length > 0 && (
            <ul className="mt-3 divide-y divide-border">
              {results.map((p) => (
                <li key={p.id} className="flex items-center gap-3 py-2.5">
                  <Avatar profile={p} />
                  <span className="min-w-0 flex-1 truncate font-semibold">{p.full_name ?? p.username}</span>
                  <button
                    onClick={() => sendRequest(p.id)}
                    className="inline-flex items-center gap-1.5 rounded-full bg-coral px-3 py-1.5 text-xs font-semibold text-primary-foreground"
                  >
                    <UserPlus className="h-3.5 w-3.5" /> Add
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {incoming.length > 0 && (
          <div className="paper mt-5 p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Requests</h3>
            <ul className="mt-2 divide-y divide-border">
              {incoming.map((r) => (
                <li key={r.id} className="flex items-center gap-3 py-2.5">
                  <Avatar profile={r.requester} />
                  <span className="min-w-0 flex-1 truncate font-semibold">{r.requester?.full_name ?? r.requester?.username}</span>
                  <button onClick={() => accept(r.id)} className="rounded-full bg-mint p-1.5" aria-label="Accept">
                    <Check className="h-4 w-4" />
                  </button>
                  <button onClick={() => decline(r.id)} className="rounded-full bg-secondary p-1.5" aria-label="Decline">
                    <X className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="paper mt-5 p-5">
          <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
            Your friends {friends.length > 0 && `(${friends.length})`}
          </h3>
          {friends.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">No friends yet — search above to add some.</p>
          ) : (
            <ul className="mt-2 divide-y divide-border">
              {friends.map((r) => {
                const other = r.requester_id === user.id ? r.addressee : r.requester;
                if (!other) return null;
                return (
                  <li key={r.id} className="flex items-center gap-3 py-2.5">
                    <Avatar profile={other} />
                    <Link to="/profile/$userId" params={{ userId: other.id }} className="min-w-0 flex-1 truncate font-semibold hover:underline">
                      {other.full_name ?? other.username}
                    </Link>
                    <button
                      onClick={() => messageFriend(other.id)}
                      disabled={startingDm === other.id}
                      className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink px-3 py-1.5 text-xs font-semibold hover:bg-secondary disabled:opacity-60"
                    >
                      {startingDm === other.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <MessageCircle className="h-3.5 w-3.5" />}
                      Message
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {outgoing.length > 0 && (
          <p className="mt-4 text-center text-xs text-muted-foreground">
            {outgoing.length} pending request{outgoing.length > 1 ? "s" : ""} sent, waiting on a reply.
          </p>
        )}
      </div>
    </div>
  );
}

function Avatar({ profile }: { profile: Profile | null }) {
  if (!profile) return <div className="h-9 w-9 shrink-0 rounded-full bg-secondary" />;
  return (
    <div className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full bg-coral text-sm font-bold text-primary-foreground">
      {profile.avatar_url ? (
        <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
      ) : (
        (profile.full_name ?? profile.username).charAt(0).toUpperCase()
      )}
    </div>
  );
}
