import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Swords, Copy, LogIn, Plus, Loader2, Crown, ArrowLeft, MessageCircle, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { GameRoomChat } from "@/components/GameRoomChat";

export const Route = createFileRoute("/games/war")({
  head: () => ({
    meta: [
      { title: "War — Play with a Friend" },
      { name: "description", content: "Real-time multiplayer War card game — play with any friend." },
    ],
  }),
  component: WarPage,
});

// Public, safe game row (sensitive deck/pending card data lives in war_games_private,
// only accessible through SECURITY DEFINER RPCs).
type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  host_deck_count: number;
  guest_deck_count: number;
  pot_count: number;
  host_played: boolean;
  guest_played: boolean;
  last_host_card: number | null;
  last_guest_card: number | null;
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

type MyState = { deck_size: number; pending_card: number | null };

const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
const cardLabel = (n: number) => `${RANKS[n % 13]}${SUITS[Math.floor(n / 13)]}`;
const isRed = (n: number) => Math.floor(n / 13) === 1 || Math.floor(n / 13) === 2;

// Untyped client helper: the generated Database types don't yet know about the new
// columns and RPCs — we cast through `any` at the boundary and keep our own Game type.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

function WarPage() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  // Subscribe to current game (safe columns only)
  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`war_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "war_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <section className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </section>
    );
  }

  if (!user) {
    return (
      <section className="paper p-8 text-center">
        <Swords className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play War</h2>
        <p className="mt-1 text-muted-foreground">You need an account to challenge a friend.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </section>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("war_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("war_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return <Lobby onCreate={createGame} onJoin={joinGame} joinCode={joinCode} setJoinCode={setJoinCode} busy={busy} />;
  }

  return <Table game={game} setGame={setGame} userId={user.id} />;
}

function Lobby({
  onCreate,
  onJoin,
  joinCode,
  setJoinCode,
  busy,
}: {
  onCreate: () => void;
  onJoin: () => void;
  joinCode: string;
  setJoinCode: (s: string) => void;
  busy: boolean;
}) {
  return (
    <section>
      <Link to="/games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All games
      </Link>
      <div className="mt-3 flex items-center gap-3">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
          <Swords className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-4xl">War</h1>
          <p className="text-muted-foreground">Highest card takes the pot. First to take all 52 wins.</p>
        </div>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        <div className="paper p-6">
          <h3 className="text-xl">Create a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
          <button
            disabled={busy}
            onClick={onCreate}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            New room
          </button>
        </div>
        <div className="paper p-6">
          <h3 className="text-xl">Join a room</h3>
          <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
          <div className="mt-5 flex gap-2">
            <input
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              maxLength={5}
              placeholder="ABCDE"
              className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
            />
            <button
              disabled={busy || joinCode.length < 4}
              onClick={onJoin}
              className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
            >
              <LogIn className="h-4 w-4" />
              Join
            </button>
          </div>
        </div>
      </div>

      <div className="paper mt-6 p-5 text-sm text-muted-foreground">
        <strong className="text-foreground">How to play:</strong> Each player flips their top card.
        Higher rank wins both cards (added to the bottom of their deck). On a tie, both cards stay
        in the pot and the next round's winner sweeps it all. Run out of cards → you lose.
      </div>
    </section>
  );
}

function Card({ n, hidden, big }: { n: number | null; hidden?: boolean; big?: boolean }) {
  const size = big ? "h-40 w-28 text-3xl" : "h-24 w-16 text-xl";
  if (hidden || n === null) {
    return (
      <div className={`${size} grid place-items-center rounded-2xl border-2 border-ink bg-ink text-cream shadow-[4px_4px_0_var(--shadow-color)]`}>
        <span className="font-display text-2xl">🂠</span>
      </div>
    );
  }
  return (
    <div className={`${size} grid place-items-center rounded-2xl border-2 border-ink bg-cream shadow-[4px_4px_0_var(--shadow-color)]`}>
      <span className={`font-display font-bold ${isRed(n) ? "text-coral" : "text-ink"}`}>{cardLabel(n)}</span>
    </div>
  );
}

function Table({ game, setGame, userId }: { game: Game; setGame: (g: Game | null) => void; userId: string }) {
  const isHost = game.host_id === userId;
  const [mine, setMine] = useState<MyState>({ deck_size: isHost ? game.host_deck_count : game.guest_deck_count, pending_card: null });
  const [drawing, setDrawing] = useState(false);

  const refetchMine = useCallback(async () => {
    const { data, error } = await db.rpc("war_my_state", { _game_id: game.id });
    if (error) return;
    const row = Array.isArray(data) ? data[0] : data;
    if (row) setMine({ deck_size: row.deck_size ?? 0, pending_card: row.pending_card ?? null });
  }, [game.id]);

  // Refetch my private hand whenever the public game state changes.
  useEffect(() => {
    refetchMine();
  }, [refetchMine, game.host_played, game.guest_played, game.last_host_card, game.last_guest_card, game.status]);

  const draw = async () => {
    if (drawing) return;
    setDrawing(true);
    const { data, error } = await db.rpc("war_play_card", { _game_id: game.id });
    setDrawing(false);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
    refetchMine();
  };

  const leave = async () => {
    if (isHost) await db.rpc("war_leave_game", { _game_id: game.id });
    setGame(null);
    window.location.reload();
  };

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const youWon = game.status === "finished" && game.winner_id === userId;
  const youLost = game.status === "finished" && game.winner_id && game.winner_id !== userId;

  // Card visibility model:
  // - Opponent's pending card stays HIDDEN until the round resolves (server clears
  //   both pending cards and sets last_*_card atomically).
  // - Your own pending card shows face-up to you from war_my_state.
  // - last_*_card shows the most recently resolved round to both players.
  const oppDeckCount = isHost ? game.guest_deck_count : game.host_deck_count;
  const oppPlayed = isHost ? game.guest_played : game.host_played;
  const myLastCard = isHost ? game.last_host_card : game.last_guest_card;
  const oppLastCard = isHost ? game.last_guest_card : game.last_host_card;
  const showLastRound = game.last_host_card !== null && game.last_guest_card !== null && !game.host_played && !game.guest_played;

  const myDisplayCard = mine.pending_card !== null ? mine.pending_card : showLastRound ? myLastCard : null;
  const oppDisplayCard = showLastRound ? oppLastCard : null;
  const oppCardHidden = !showLastRound; // hide while opponent's card is pending

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-ink text-cream">
            <Swords className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Room</div>
            <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
              {game.code} <Copy className="h-4 w-4 opacity-60" />
            </button>
          </div>
        </div>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent && (
        <div className="paper mt-5 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
          <p className="text-sm text-muted-foreground">They can join from Games → War → Join a room.</p>
        </div>
      )}

      <div className="mt-6 grid gap-6 sm:grid-cols-2">
        {/* Opponent */}
        <div className="paper p-5">
          <div className="flex items-center justify-between">
            <div className="font-semibold">
              {isHost ? "Guest" : "Host"} {oppPlayed && !showLastRound && <span className="ml-1 text-xs text-coral">• card down</span>}
            </div>
            <div className="text-sm text-muted-foreground">{oppDeckCount} cards</div>
          </div>
          <div className="mt-4 flex items-center gap-4">
            <Card n={null} hidden />
            <div className="text-2xl text-muted-foreground">→</div>
            <Card n={oppDisplayCard} hidden={oppCardHidden} big />
          </div>
        </div>

        {/* You */}
        <div className="paper p-5">
          <div className="flex items-center justify-between">
            <div className="font-semibold">You {isHost ? "(Host)" : "(Guest)"}</div>
            <div className="text-sm text-muted-foreground">{mine.deck_size} cards</div>
          </div>
          <div className="mt-4 flex items-center gap-4">
            <Card n={null} hidden />
            <div className="text-2xl text-muted-foreground">→</div>
            <Card n={myDisplayCard} hidden={myDisplayCard === null} big />
          </div>
          <button
            onClick={draw}
            disabled={waitingForOpponent || game.status !== "playing" || mine.pending_card !== null || mine.deck_size === 0 || drawing}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-50"
          >
            {drawing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Swords className="h-4 w-4" />}
            {mine.pending_card !== null ? "Card down — waiting…" : "Draw card"}
          </button>
        </div>
      </div>

      {game.pot_count > 0 && (
        <div className="mt-4 text-center text-sm text-muted-foreground">
          ⚔ Pot on the table: <strong className="text-foreground">{game.pot_count} cards</strong>
        </div>
      )}

      {game.last_message && (
        <div className="mt-5 paper p-4 text-center font-semibold">{game.last_message}</div>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">{youWon ? "You won!" : youLost ? "You lost — rematch?" : "Game over"}</h3>
          <button
            onClick={leave}
            className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream"
          >
            Back to lobby
          </button>
        </div>
      )}

      <ChatPanel gameId={game.id} userId={userId} isHost={isHost} />
    </section>
  );
}

function ChatPanel({ gameId, userId, isHost }: { gameId: string; userId: string; isHost: boolean }) {
  const [open, setOpen] = useState(false);
  const QUICK = useMemo(
    () => ["gg", "nice!", "one sec", "your turn", "lucky 🍀", "💀"],
    [],
  );

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Toggle chat"
        className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-ink text-cream shadow-[var(--shadow-pop)]"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>

      {open && (
        <div className="fixed bottom-24 right-5 z-40 flex h-[26rem] w-[20rem] max-w-[calc(100vw-2.5rem)] flex-col paper p-0 overflow-hidden">
          <div className="flex items-center justify-between border-b-2 border-ink/10 px-4 py-2.5">
            <div className="flex items-center gap-2 font-semibold">
              <MessageCircle className="h-4 w-4" /> Match chat
            </div>
          </div>
          <div className="flex-1 overflow-hidden p-2">
            <GameRoomChat roomId={gameId} />
          </div>
          <div className="flex flex-wrap gap-1.5 border-t-2 border-ink/10 px-3 pb-2 pt-1.5">
            {QUICK.map((q) => (
              <QuickSend key={q} label={q} gameId={gameId} userId={userId} />
            ))}
          </div>
        </div>
      )}
    </>
  );
}

function QuickSend({ label, gameId, userId }: { label: string; gameId: string; userId: string }) {
  const send = async () => {
    const { data: profile } = await supabase.from("profiles").select("username,full_name").eq("id", userId).maybeSingle();
    const display_name = (profile as any)?.full_name ?? (profile as any)?.username ?? "Player";
    await supabase.from("room_chat_messages").insert({ room_id: gameId, user_id: userId, display_name, content: label });
  };
  return (
    <button onClick={send} className="rounded-full border border-ink/20 px-2.5 py-0.5 text-xs hover:bg-accent">
      {label}
    </button>
  );
}
