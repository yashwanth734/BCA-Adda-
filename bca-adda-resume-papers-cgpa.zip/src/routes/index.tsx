import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MessageCircle, Users, Sparkles } from "lucide-react";
import heroImage from "@/assets/hero-chat.jpg";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  const { user } = useAuth();
  return (
    <div className="min-h-screen grain-bg">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold tracking-tight">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-ink text-cream">B</span>
          BCA Adda
        </Link>
        <nav className="flex items-center gap-1 text-sm">
          <Link to="/games" className="hidden sm:inline-flex rounded-full px-3 py-2 font-semibold hover:bg-secondary">
            Games
          </Link>
          <Link to="/attendance" className="hidden sm:inline-flex rounded-full px-3 py-2 font-semibold hover:bg-secondary">
            Attendance
          </Link>


          {user ? (
            <Link
              to="/chat"
              className="inline-flex items-center gap-1.5 rounded-full bg-ink px-4 py-2 font-semibold text-cream hover:opacity-90"
            >
              Open chat <ArrowRight className="h-4 w-4" />
            </Link>
          ) : (
            <>
              <Link to="/auth" className="rounded-full px-4 py-2 font-semibold hover:bg-secondary">
                Sign in
              </Link>
              <Link
                to="/auth"
                search={{ mode: "signup" }}
                className="inline-flex items-center gap-1.5 rounded-full bg-ink px-4 py-2 font-semibold text-cream hover:opacity-90"
              >
                Join free <ArrowRight className="h-4 w-4" />
              </Link>
            </>
          )}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-20 pt-6 md:pt-12">
        <section className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <span className="chip">
              <Sparkles className="h-3.5 w-3.5" /> Made for BCA students
            </span>
            <h1 className="mt-4 text-5xl leading-[1.05] md:text-6xl">
              The chill chat room for your <em className="text-coral not-italic">BCA squad</em>.
            </h1>
            <p className="mt-5 max-w-md text-lg text-muted-foreground">
              Hop into topic rooms with classmates from across the country. Trade notes, debug
              code, share placement tips — all in one cozy place.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/auth"
                search={{ mode: "signup" }}
                className="inline-flex items-center gap-2 rounded-full bg-coral px-6 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] hover:translate-y-[-1px] transition-transform"
              >
                Create your free account <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/auth"
                className="inline-flex items-center gap-2 rounded-full border-2 border-ink bg-cream px-6 py-3 font-semibold hover:bg-secondary"
              >
                I already have one
              </Link>
            </div>
            <div className="mt-8 flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex -space-x-2">
                {["#f8b195", "#a0d8b3", "#f6d186", "#c6a8e1"].map((c) => (
                  <span
                    key={c}
                    className="h-7 w-7 rounded-full border-2 border-cream"
                    style={{ background: c }}
                  />
                ))}
              </div>
              Already 100+ students online this week
            </div>
          </div>

          <div className="relative">
            <div className="paper overflow-hidden">
              <img
                src={heroImage}
                alt="BCA students chatting together"
                width={1280}
                height={960}
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-5 -left-4 paper px-4 py-3 text-sm font-medium md:-left-8">
              <span className="chip mb-1">#programming</span>
              <p>"how do you reverse a linked list in O(1) space?" 👀</p>
            </div>
          </div>
        </section>

        <section className="mt-24 grid gap-5 md:grid-cols-3">
          {[
            {
              icon: MessageCircle,
              title: "Topic rooms",
              body: "Jump into General, Assignments, Programming, Memes and more.",
            },
            {
              icon: Users,
              title: "Real-time vibes",
              body: "Messages appear the second your friends hit send. No refresh needed.",
            },
            {
              icon: Sparkles,
              title: "Built for students",
              body: "Lightweight, friendly, and free. Sign up with your email in seconds.",
            },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="paper p-6">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-accent">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-xl">{title}</h3>
              <p className="mt-2 text-muted-foreground">{body}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="mx-auto max-w-6xl px-5 pb-10 text-sm text-muted-foreground">
        Built with ❤️ for BCA students.
      </footer>
    </div>
  );
}
