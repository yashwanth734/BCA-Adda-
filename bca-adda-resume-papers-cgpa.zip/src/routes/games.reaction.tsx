import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Timer } from "lucide-react";

export const Route = createFileRoute("/games/reaction")({
  head: () => ({
    meta: [
      { title: "Reaction Test — Arcade" },
      { name: "description", content: "Tap the exact second the screen turns green and beat your best time." },
      { property: "og:title", content: "Reaction Test" },
      { property: "og:description", content: "How fast are your reflexes?" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Reaction,
});

type Phase = "idle" | "waiting" | "go" | "result" | "early";

function Reaction() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [ms, setMs] = useState<number | null>(null);
  const [best, setBest] = useState<number | null>(null);
  const startRef = useRef<number>(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(
    () => () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    },
    [],
  );

  const start = () => {
    setPhase("waiting");
    setMs(null);
    const delay = 1200 + Math.random() * 2500;
    timerRef.current = setTimeout(() => {
      startRef.current = performance.now();
      setPhase("go");
    }, delay);
  };

  const click = () => {
    if (phase === "idle" || phase === "result" || phase === "early") return start();
    if (phase === "waiting") {
      if (timerRef.current) clearTimeout(timerRef.current);
      setPhase("early");
      return;
    }
    if (phase === "go") {
      const t = Math.round(performance.now() - startRef.current);
      setMs(t);
      setBest((b) => (b === null || t < b ? t : b));
      setPhase("result");
    }
  };

  const surface =
    phase === "go"
      ? "bg-gradient-to-br from-neon to-mint text-ink animate-glow"
      : phase === "waiting"
        ? "bg-gradient-to-br from-coral to-gold text-ink"
        : phase === "early"
          ? "bg-destructive text-cream animate-shake"
          : "bg-gradient-to-br from-ink to-violet text-cream";

  const headline =
    phase === "idle"
      ? "Tap to start"
      : phase === "waiting"
        ? "Wait for green…"
        : phase === "go"
          ? "TAP NOW!"
          : phase === "early"
            ? "Too soon!"
            : `${ms} ms`;

  const sub =
    phase === "result"
      ? ms !== null && ms < 250
        ? "Lightning reflexes — tap to go again"
        : "Tap to try again"
      : phase === "early"
        ? "Tap to retry"
        : phase === "waiting"
          ? "Hold steady"
          : phase === "go"
            ? "Go go go"
            : "Three, two, one…";

  return (
    <section className="mx-auto max-w-md">
      <h1 className="text-4xl sm:text-5xl">
        Reaction <span className="text-coral">Test</span>
      </h1>
      <div className="mt-3 flex items-center gap-2">
        <span className="chip">
          <Timer className="h-3.5 w-3.5" /> Best {best !== null ? `${best} ms` : "—"}
        </span>
        {ms !== null ? <span className="chip bg-gold">Last {ms} ms</span> : null}
      </div>

      <button
        onClick={click}
        className={`mt-6 grid h-80 w-full place-items-center rounded-3xl border-2 border-ink shadow-pop transition-all ${surface}`}
      >
        <span className="px-6 text-center">
          <span className="block font-display text-4xl sm:text-5xl">{headline}</span>
          <span className="mt-2 block text-sm font-semibold opacity-80">{sub}</span>
        </span>
      </button>

      <p className="mt-4 text-center text-sm text-muted-foreground">
        Wait for the panel to turn <span className="font-semibold text-foreground">green</span>, then
        tap as fast as you can.
      </p>
    </section>
  );
}
