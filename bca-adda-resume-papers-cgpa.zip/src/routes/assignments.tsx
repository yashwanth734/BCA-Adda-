import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ClipboardList, Plus, Loader2, Check, Trash2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/assignments")({
  head: () => ({
    meta: [
      { title: "Assignments — BCA Adda" },
      { name: "description", content: "Track deadlines across all your subjects." },
    ],
  }),
  component: AssignmentsPage,
});

type Assignment = {
  id: string;
  title: string;
  subject_name: string | null;
  description: string | null;
  due_at: string;
  completed: boolean;
};

function AssignmentsPage() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [subjectName, setSubjectName] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [saving, setSaving] = useState(false);
  const [showCompleted, setShowCompleted] = useState(false);

  const assignmentsQ = useQuery({
    queryKey: ["assignments", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("assignments")
        .select("id,title,subject_name,description,due_at,completed")
        .order("due_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Assignment[];
    },
  });

  const assignments = assignmentsQ.data ?? [];
  const now = Date.now();

  const { overdue, upcoming, completed } = useMemo(() => {
    const overdue: Assignment[] = [];
    const upcoming: Assignment[] = [];
    const completed: Assignment[] = [];
    for (const a of assignments) {
      if (a.completed) completed.push(a);
      else if (new Date(a.due_at).getTime() < now) overdue.push(a);
      else upcoming.push(a);
    }
    return { overdue, upcoming, completed };
  }, [assignments, now]);

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-5 text-center">
        <div>
          <h1 className="text-2xl">Sign in to track assignments</h1>
          <Link to="/auth" className="mt-4 inline-block rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !dueDate) {
      toast.error("Add a title and a due date");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("assignments").insert({
      user_id: user.id,
      title: title.trim(),
      subject_name: subjectName.trim() || null,
      description: description.trim() || null,
      due_at: new Date(dueDate).toISOString(),
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Added");
    setTitle("");
    setSubjectName("");
    setDescription("");
    setDueDate("");
    setShowForm(false);
    qc.invalidateQueries({ queryKey: ["assignments", user.id] });
  };

  const toggleComplete = async (a: Assignment) => {
    const { error } = await supabase.from("assignments").update({ completed: !a.completed }).eq("id", a.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["assignments", user.id] });
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("assignments").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["assignments", user.id] });
  };

  return (
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
              <ClipboardList className="h-6 w-6" />
            </div>
            <h1 className="text-4xl">Assignments</h1>
          </div>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2.5 font-semibold text-primary-foreground shadow-[var(--shadow-pop)]"
          >
            <Plus className="h-4 w-4" /> Add
          </button>
        </div>

        {showForm && (
          <form onSubmit={submit} className="paper mt-5 space-y-3 p-5">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">Title</label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="DBMS assignment 2"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Subject (optional)</label>
                <input
                  value={subjectName}
                  onChange={(e) => setSubjectName(e.target.value)}
                  placeholder="DBMS"
                  className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Due date & time</label>
              <input
                type="datetime-local"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="mt-1.5 w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Notes (optional)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 1000))}
                rows={3}
                placeholder="What needs to get done…"
                className="mt-1.5 w-full resize-none rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 outline-none focus:border-ink"
              />
            </div>
            <button
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 font-semibold text-cream disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Add assignment
            </button>
          </form>
        )}

        {assignmentsQ.isLoading ? (
          <div className="mt-8 grid place-items-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : assignments.length === 0 ? (
          <p className="mt-8 text-center text-muted-foreground">No assignments tracked yet.</p>
        ) : (
          <div className="mt-6 space-y-6">
            {overdue.length > 0 && (
              <Section title="Overdue" items={overdue} icon={<AlertCircle className="h-4 w-4 text-coral" />} onToggle={toggleComplete} onDelete={remove} tint="text-coral" />
            )}
            {upcoming.length > 0 && (
              <Section title="Upcoming" items={upcoming} onToggle={toggleComplete} onDelete={remove} />
            )}
            {completed.length > 0 && (
              <div>
                <button
                  onClick={() => setShowCompleted((v) => !v)}
                  className="text-sm font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground"
                >
                  Completed ({completed.length}) {showCompleted ? "▲" : "▼"}
                </button>
                {showCompleted && (
                  <ul className="mt-2 space-y-2">
                    {completed.map((a) => (
                      <AssignmentRow key={a.id} a={a} onToggle={toggleComplete} onDelete={remove} />
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function Section({
  title,
  items,
  icon,
  tint,
  onToggle,
  onDelete,
}: {
  title: string;
  items: Assignment[];
  icon?: React.ReactNode;
  tint?: string;
  onToggle: (a: Assignment) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div>
      <h3 className={`flex items-center gap-1.5 text-sm font-bold uppercase tracking-wider ${tint ?? "text-muted-foreground"}`}>
        {icon} {title}
      </h3>
      <ul className="mt-2 space-y-2">
        {items.map((a) => (
          <AssignmentRow key={a.id} a={a} onToggle={onToggle} onDelete={onDelete} />
        ))}
      </ul>
    </div>
  );
}

function AssignmentRow({ a, onToggle, onDelete }: { a: Assignment; onToggle: (a: Assignment) => void; onDelete: (id: string) => void }) {
  const overdue = !a.completed && new Date(a.due_at).getTime() < Date.now();
  return (
    <li className={`paper flex items-start gap-3 p-4 ${a.completed ? "opacity-60" : ""}`}>
      <button
        onClick={() => onToggle(a)}
        className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 ${
          a.completed ? "border-mint bg-mint" : "border-ink"
        }`}
        aria-label={a.completed ? "Mark incomplete" : "Mark complete"}
      >
        {a.completed && <Check className="h-3 w-3" />}
      </button>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          {a.subject_name && <span className="chip">{a.subject_name}</span>}
          <span className={`font-bold ${a.completed ? "line-through" : ""}`}>{a.title}</span>
        </div>
        {a.description && <p className="mt-1 text-sm text-muted-foreground">{a.description}</p>}
        <p className={`mt-1 text-xs font-semibold ${overdue ? "text-coral" : "text-muted-foreground"}`}>
          Due {new Date(a.due_at).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
        </p>
      </div>
      <button onClick={() => onDelete(a.id)} className="shrink-0 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-coral" aria-label="Delete">
        <Trash2 className="h-4 w-4" />
      </button>
    </li>
  );
}
