import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { ArrowLeft, Landmark } from "lucide-react";

export const Route = createFileRoute("/board")({
  head: () => ({
    meta: [
      { title: "Trade City — Multiplayer Board Game" },
      {
        name: "description",
        content:
          "Play Trade City, a live multiplayer property-trading board game with friends, bots, auctions and trades.",
      },
      { property: "og:title", content: "Trade City — Multiplayer Board Game" },
      {
        property: "og:description",
        content: "Buy estates, run auctions, strike trades and bankrupt your friends.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BoardLayout,
});

function BoardLayout() {
  return (
    <div className="min-h-screen grain-bg">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link
          to="/games"
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Games
        </Link>
        <Link to="/board" className="flex items-center gap-2 font-display text-lg font-bold">
          <Landmark className="h-5 w-5" /> Trade City
        </Link>
        <Link to="/chat" className="text-sm font-semibold hover:underline">
          Chat
        </Link>
      </header>
      <main className="mx-auto max-w-6xl px-4 pb-20 sm:px-5">
        <Outlet />
      </main>
    </div>
  );
}
