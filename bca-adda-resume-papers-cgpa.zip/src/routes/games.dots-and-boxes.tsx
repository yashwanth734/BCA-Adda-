import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, Copy, LogIn, Plus, Loader2, Crown, Square } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SpectateEntry } from "@/components/SpectateEntry";
import { MatchmakingButton } from "@/components/MatchmakingButton";
import { MatchmakingButton } from "@/components/MatchmakingButton";

export const Route = createFileRoute("/games/dots-and-boxes")({
  head: () => ({
    meta: [
      { title: "Dots and Boxes — Play with a Friend" },
      { name: "description", content: "Real-time multiplayer Dots and Boxes — claim a box, go again." },
      { property: "og:title", content: "Dots and Boxes" },
      { property: "og:description", content: "Draw lines, claim boxes, chase the extra turn." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DotsBoxesPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const DOTS = 5; // 5x5 dots -> 4x4 boxes
const BOX_GRID = 4;

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  edges: number[]; // 40, 0 empty / 1 host / 2 guest
  boxes: number[]; // 16, 0 unclaimed / 1 host / 2 guest
  host_score: number;
  guest_score: number;
  turn: number;
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

function hEdge(row: number, col: number) {
  return row * 4 + col; // row 0..4, col 0..3
}
function vEdge(row: number, col: number) {
  return 20 + row * 5 + col; // row 0..3, col 0..4
}

function DotsBoxesPage() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`dots_boxes_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "dots_boxes_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <section className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </section>
    );
  }

  if (!user) {
    return (
      <section className="paper p-8 text-center">
        <Square className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play Dots and Boxes</h2>
        <p className="mt-1 text-muted-foreground">You need an account to challenge a friend.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </section>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("dots_boxes_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("dots_boxes_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return (
      <section>
        <Link to="/games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          ← All games
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Square className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-4xl">Dots and Boxes</h1>
            <p className="text-muted-foreground">4×4 boxes. Complete one and you go again.</p>
          </div>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          <div className="paper p-6">
            <h3 className="text-xl">Create a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
            <button
              disabled={busy}
              onClick={createGame}
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              New room
            </button>
          </div>
          <div className="paper p-6">
            <h3 className="text-xl">Join a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
            <div className="mt-5 flex gap-2">
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                maxLength={5}
                placeholder="ABCDE"
                className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
              />
              <button
                disabled={busy || joinCode.length < 4}
                onClick={joinGame}
                className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
              >
                <LogIn className="h-4 w-4" />
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="paper mt-6 p-5 text-sm text-muted-foreground">
          <strong className="text-foreground">How to play:</strong> Take turns drawing one line between two
          neighboring dots. Complete the 4th side of a box and you claim it — and get an extra turn. Most boxes
          when the grid is full wins.
        </div>

      <div className="mt-4">
        <SpectateEntry table="dots_boxes_games" label="a Dots and Boxes" onJoin={(g) => {} } />

      <div className="mt-4">
        <MatchmakingButton gameType="dots_and_boxes" gameLabel="Dots and Boxes" onMatchFound={() => {}} />
      </div>
      </div>
    </section>
    );
  }


  return <Board game={game} setGame={setGame} userId={user.id} />;
}

function Board({ game, setGame, userId }: { game: Game; setGame: (g: Game | null) => void; userId: string }) {
  const isHost = game.host_id === userId;
  const me = isHost ? 1 : 2;
  const [drawing, setDrawing] = useState<number | null>(null);

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const myTurn = game.status === "playing" && game.turn === me;
  const youWon = game.status === "finished" && game.winner_id === userId;
  const draw = game.status === "finished" && !game.winner_id;

  const drawEdge = async (edge: number) => {
    if (!myTurn || drawing !== null || game.edges[edge] !== 0) return;
    setDrawing(edge);
    const { data, error } = await db.rpc("dots_boxes_draw", { _game_id: game.id, _edge: edge });
    setDrawing(null);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  const leave = async () => {
    if (isHost) await db.rpc("dots_boxes_leave_game", { _game_id: game.id });
    setGame(null);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  const canPlay = myTurn && game.status === "playing" && drawing === null;

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
          <Square className="h-5 w-5" /> {game.code} <Copy className="h-4 w-4 opacity-60" />
        </button>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent && (
        <div className="paper mt-5 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
        </div>
      )}

      {!waitingForOpponent && (
        <>
          <div className="mt-6 flex items-center justify-between paper p-4">
            <span className={`rounded-full border-2 px-3 py-1.5 text-sm font-semibold ${game.turn === 1 && game.status === "playing" ? "border-ink" : "border-transparent opacity-60"}`}>
              Host {isHost && "(You)"} · {game.host_score}
            </span>
            <div className="text-sm font-semibold text-muted-foreground">
              {game.last_message ?? (myTurn ? "Your move" : "Opponent's move")}
            </div>
            <span className={`rounded-full border-2 px-3 py-1.5 text-sm font-semibold ${game.turn === 2 && game.status === "playing" ? "border-ink" : "border-transparent opacity-60"}`}>
              Guest {!isHost && "(You)"} · {game.guest_score}
            </span>
          </div>

          <div className="mt-4 overflow-x-auto rounded-3xl border-2 border-ink bg-cream p-4 shadow-soft">
            <div
              className="mx-auto grid"
              style={{
                gridTemplateColumns: `repeat(${DOTS}, auto)`,
                gridTemplateRows: `repeat(${DOTS}, auto)`,
                width: "min(420px, 80vw)",
              }}
            >
              {Array.from({ length: DOTS }).map((_, row) =>
                Array.from({ length: DOTS }).map((__, col) => (
                  <div key={`dot-${row}-${col}`} className="relative" style={{ gridRow: row * 2 + 1, gridColumn: col * 2 + 1 }}>
                    <div className="h-2 w-2 rounded-full bg-ink" />
                    {col < BOX_GRID && (
                      <button
                        onClick={() => drawEdge(hEdge(row, col))}
                        disabled={!canPlay || game.edges[hEdge(row, col)] !== 0}
                        className="absolute left-2 top-1/2 h-1.5 -translate-y-1/2 rounded-full disabled:cursor-default"
                        style={{
                          width: "calc(min(420px, 80vw) / 4 - 8px)",
                          backgroundColor:
                            game.edges[hEdge(row, col)] === 1 ? "var(--coral)" : game.edges[hEdge(row, col)] === 2 ? "var(--violet)" : "rgba(0,0,0,0.12)",
                        }}
                      />
                    )}
                    {row < BOX_GRID && (
                      <button
                        onClick={() => drawEdge(vEdge(row, col))}
                        disabled={!canPlay || game.edges[vEdge(row, col)] !== 0}
                        className="absolute left-1/2 top-2 w-1.5 -translate-x-1/2 rounded-full disabled:cursor-default"
                        style={{
                          height: "calc(min(420px, 80vw) / 4 - 8px)",
                          backgroundColor:
                            game.edges[vEdge(row, col)] === 1 ? "var(--coral)" : game.edges[vEdge(row, col)] === 2 ? "var(--violet)" : "rgba(0,0,0,0.12)",
                        }}
                      />
                    )}
                    {row < BOX_GRID && col < BOX_GRID && game.boxes[row * 4 + col] !== 0 && (
                      <div
                        className="absolute flex items-center justify-center text-xs font-bold"
                        style={{
                          left: 8,
                          top: 8,
                          width: "calc(min(420px, 80vw) / 4 - 8px)",
                          height: "calc(min(420px, 80vw) / 4 - 8px)",
                          backgroundColor: game.boxes[row * 4 + col] === 1 ? "color-mix(in srgb, var(--coral) 35%, transparent)" : "color-mix(in srgb, var(--violet) 35%, transparent)",
                          color: "var(--ink)",
                        }}
                      >
                        {game.boxes[row * 4 + col] === 1 ? "H" : "G"}
                      </div>
                    )}
                  </div>
                )),
              )}
            </div>
          </div>
        </>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">
            {youWon ? "You won!" : draw ? "It's a tie!" : "You lost — rematch?"}
          </h3>
          <button onClick={leave} className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream">
            Back to lobby
          </button>
        </div>
      )}
    </section>
  );
}
