import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Eye, Copy, LogIn, Plus, Loader2, Crown, Disc } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SpectateEntry } from "@/components/SpectateEntry";
import { MatchmakingButton } from "@/components/MatchmakingButton";

export const Route = createFileRoute("/games/othello")({
  head: () => ({
    meta: [
      { title: "Othello — Play with a Friend" },
      { name: "description", content: "Real-time multiplayer Othello/Reversi — standard 8x8 board, standard rules." },
      { property: "og:title", content: "Othello" },
      { property: "og:description", content: "Bracket your opponent's discs and flip the board your color." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: OthelloPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const SIZE = 8;
const CELLS = 64;

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  board: number[]; // 0 empty, 1 host (black), 2 guest (white)
  turn: number;
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

function OthelloPage() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`othello_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "othello_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <section className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </section>
    );
  }

  if (!user) {
    return (
      <section className="paper p-8 text-center">
        <Disc className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play Othello</h2>
        <p className="mt-1 text-muted-foreground">You need an account to challenge a friend.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </section>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("othello_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("othello_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return (
      <section>
        <Link to="/games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          ← All games
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Disc className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-4xl">Othello</h1>
            <p className="text-muted-foreground">Standard 8×8 board. Bracket a line, flip it your color.</p>
          </div>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          <div className="paper p-6">
            <h3 className="text-xl">Create a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
            <button
              disabled={busy}
              onClick={createGame}
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              New room
            </button>
          </div>
          <div className="paper p-6">
            <h3 className="text-xl">Join a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
            <div className="mt-5 flex gap-2">
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                maxLength={5}
                placeholder="ABCDE"
                className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
              />
              <button
                disabled={busy || joinCode.length < 4}
                onClick={joinGame}
                className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
              >
                <LogIn className="h-4 w-4" />
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="paper mt-6 p-5 text-sm text-muted-foreground">
          <strong className="text-foreground">How to play:</strong> Place a disc so it brackets one or more of your
          opponent's discs in a straight line — those discs flip to your color. If you have no legal move you pass
          automatically. Most discs on the board when neither side can move wins.
        </div>

      <div className="mt-4">
        <SpectateEntry table="othello_games" label="an Othello" onJoin={(g) => {} } />
      </div>

      <div className="mt-4">
        <MatchmakingButton gameType="othello" gameLabel="Othello" onMatchFound={() => {}} />
      </div>
    </section>
    );
  }


  return <Board game={game} setGame={setGame} userId={user.id} />;
}

function Board({ game, setGame, userId }: { game: Game; setGame: (g: Game | null) => void; userId: string }) {
  const isHost = game.host_id === userId;
  const me = isHost ? 1 : 2;
  const [placing, setPlacing] = useState<number | null>(null);

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const myTurn = game.status === "playing" && game.turn === me;
  const youWon = game.status === "finished" && game.winner_id === userId;
  const draw = game.status === "finished" && !game.winner_id;

  const counts = useMemo(() => {
    let host = 0, guest = 0;
    for (const c of game.board) {
      if (c === 1) host++;
      else if (c === 2) guest++;
    }
    return { host, guest };
  }, [game.board]);

  const place = async (cell: number) => {
    if (!myTurn || placing !== null || game.board[cell] !== 0) return;
    setPlacing(cell);
    const { data, error } = await db.rpc("othello_place", { _game_id: game.id, _cell: cell });
    setPlacing(null);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  const leave = async () => {
    if (isHost) await db.rpc("othello_leave_game", { _game_id: game.id });
    setGame(null);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
          <Disc className="h-5 w-5" /> {game.code} <Copy className="h-4 w-4 opacity-60" />
        </button>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent && (
        <div className="paper mt-5 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
        </div>
      )}

      {!waitingForOpponent && (
        <>
          <div className="mt-6 flex items-center justify-between paper p-4">
            <PlayerTag label="Host (black)" active={game.turn === 1 && game.status === "playing"} you={isHost} count={counts.host} dark />
            <div className="text-sm font-semibold text-muted-foreground">
              {game.last_message ?? (myTurn ? "Your move" : "Opponent's move")}
            </div>
            <PlayerTag label="Guest (white)" active={game.turn === 2 && game.status === "playing"} you={!isHost} count={counts.guest} dark={false} />
          </div>

          <div className="mt-4 rounded-3xl border-2 border-ink bg-mint p-2 shadow-soft sm:p-3">
            <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)` }}>
              {Array.from({ length: CELLS }).map((_, i) => {
                const v = game.board[i];
                return (
                  <button
                    key={i}
                    onClick={() => place(i)}
                    disabled={!myTurn || v !== 0 || game.status !== "playing"}
                    className="group grid aspect-square place-items-center border border-ink/20 disabled:cursor-not-allowed"
                  >
                    {v !== 0 && (
                      <span
                        className={`h-[78%] w-[78%] rounded-full border-2 border-black/30 shadow-sm ${
                          v === 1 ? "bg-ink" : "bg-cream"
                        } ${placing === i ? "animate-pulse" : ""}`}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">
            {youWon ? "You won!" : draw ? "It's a tie!" : "You lost — rematch?"}
          </h3>
          <button onClick={leave} className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream">
            Back to lobby
          </button>
        </div>
      )}
    </section>
  );
}

function PlayerTag({ label, active, you, count, dark }: { label: string; active: boolean; you: boolean; count: number; dark: boolean }) {
  return (
    <div className={`flex items-center gap-2 rounded-full border-2 px-3 py-1.5 text-sm font-semibold ${active ? "border-ink" : "border-transparent opacity-60"}`}>
      <span className={`h-3.5 w-3.5 rounded-full border border-black/30 ${dark ? "bg-ink" : "bg-cream"}`} />
      {label} {you && "(You)"} · {count}
    </div>
  );
}
