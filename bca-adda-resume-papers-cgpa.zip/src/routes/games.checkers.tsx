import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, Copy, LogIn, Plus, Loader2, Crown } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { SpectateEntry } from "@/components/SpectateEntry";
import { MatchmakingButton } from "@/components/MatchmakingButton";

export const Route = createFileRoute("/games/checkers")({
  head: () => ({
    meta: [
      { title: "Checkers — Play with a Friend" },
      { name: "description", content: "Real-time multiplayer Checkers — standard rules, mandatory captures, king me." },
      { property: "og:title", content: "Checkers" },
      { property: "og:description", content: "The classic. Capture is mandatory, chains keep going." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CheckersPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const SIZE = 8;
const CELLS = 64;

type Game = {
  id: string;
  code: string;
  host_id: string;
  guest_id: string | null;
  board: number[]; // 0 empty, 1 host man, 2 guest man, 3 host king, 4 guest king
  turn: number;
  must_continue_from: number | null;
  status: string;
  winner_id: string | null;
  last_message: string | null;
};

function CheckersPage() {
  const { user, loading } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!game?.id) return;
    const ch = supabase
      .channel(`checkers_games:${game.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "checkers_games", filter: `id=eq.${game.id}` },
        (payload) => setGame(payload.new as unknown as Game),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [game?.id]);

  if (loading) {
    return (
      <section className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin" />
      </section>
    );
  }

  if (!user) {
    return (
      <section className="paper p-8 text-center">
        <Crown className="mx-auto h-10 w-10" />
        <h2 className="mt-3 text-2xl">Sign in to play Checkers</h2>
        <p className="mt-1 text-muted-foreground">You need an account to challenge a friend.</p>
        <Link to="/auth" className="mt-5 inline-flex items-center gap-2 rounded-full bg-coral px-5 py-2.5 font-semibold text-primary-foreground">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </section>
    );
  }

  const createGame = async () => {
    setBusy(true);
    const { data, error } = await db.rpc("checkers_create_game");
    setBusy(false);
    if (error) return toast.error(error.message);
    const g = data as Game;
    setGame(g);
    toast.success(`Room created: ${g.code}`);
  };

  const joinGame = async () => {
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setBusy(true);
    const { data, error } = await db.rpc("checkers_join_game", { _code: code });
    setBusy(false);
    if (error) return toast.error(error.message);
    setGame(data as Game);
  };

  if (!game) {
    return (
      <section>
        <Link to="/games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          ← All games
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-xl bg-ink text-cream">
            <Crown className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-4xl">Checkers</h1>
            <p className="text-muted-foreground">Standard rules — captures are mandatory.</p>
          </div>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          <div className="paper p-6">
            <h3 className="text-xl">Create a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Share the code with a friend.</p>
            <button
              disabled={busy}
              onClick={createGame}
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral px-5 py-3 font-semibold text-primary-foreground shadow-[var(--shadow-pop)] disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              New room
            </button>
          </div>
          <div className="paper p-6">
            <h3 className="text-xl">Join a room</h3>
            <p className="mt-1 text-sm text-muted-foreground">Enter the 5-letter code.</p>
            <div className="mt-5 flex gap-2">
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                maxLength={5}
                placeholder="ABCDE"
                className="w-full rounded-xl border-2 border-input bg-cream px-3.5 py-2.5 font-mono text-lg tracking-widest outline-none focus:border-ink"
              />
              <button
                disabled={busy || joinCode.length < 4}
                onClick={joinGame}
                className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-ink px-4 font-semibold text-cream disabled:opacity-60"
              >
                <LogIn className="h-4 w-4" />
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="paper mt-6 p-5 text-sm text-muted-foreground">
          <strong className="text-foreground">How to play:</strong> Men move one diagonal step forward; capture by
          jumping an adjacent opponent piece into an empty square beyond it. If a capture is available you must take
          it, and if that same piece can capture again from its new square, you must keep jumping with it. Reach the
          far row to become a king, which can move and capture in all four diagonal directions.
        </div>

      <div className="mt-4">
        <SpectateEntry table="checkers_games" label="a Checkers" onJoin={(g) => {} } />
      </div>

      <div className="mt-4">
        <MatchmakingButton gameType="checkers" gameLabel="Checkers" onMatchFound={() => {}} />
      </div>
    </section>
    );
  }


  return <Board game={game} setGame={setGame} userId={user.id} />;
}

function Board({ game, setGame, userId }: { game: Game; setGame: (g: Game | null) => void; userId: string }) {
  const isHost = game.host_id === userId;
  const me = isHost ? 1 : 2;
  const [selected, setSelected] = useState<number | null>(null);
  const [moving, setMoving] = useState(false);

  const waitingForOpponent = game.status === "waiting" || !game.guest_id;
  const myTurn = game.status === "playing" && game.turn === me;
  const youWon = game.status === "finished" && game.winner_id === userId;

  const copyCode = () => {
    navigator.clipboard.writeText(game.code);
    toast.success("Code copied");
  };

  const leave = async () => {
    if (isHost) await db.rpc("checkers_leave_game", { _game_id: game.id });
    setGame(null);
  };

  const cellClick = async (i: number) => {
    if (!myTurn || moving) return;
    const piece = game.board[i];
    const isMine = piece === me || piece === me + 2;

    if (selected === null) {
      if (isMine) {
        if (game.must_continue_from !== null && game.must_continue_from !== i) {
          toast.error("You must keep capturing with the piece that just jumped");
          return;
        }
        setSelected(i);
      }
      return;
    }

    if (i === selected) {
      setSelected(null);
      return;
    }
    if (isMine) {
      setSelected(i);
      return;
    }

    setMoving(true);
    const { data, error } = await db.rpc("checkers_move", { _game_id: game.id, _from: selected, _to: i });
    setMoving(false);
    setSelected(null);
    if (error) return toast.error(error.message);
    if (data) setGame(data as Game);
  };

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button onClick={copyCode} className="inline-flex items-center gap-1.5 font-display text-2xl font-bold">
          <Crown className="h-5 w-5" /> {game.code} <Copy className="h-4 w-4 opacity-60" />
        </button>
        <button onClick={leave} className="rounded-full border-2 border-ink px-4 py-1.5 text-sm font-semibold">
          Leave
        </button>
      </div>

      {waitingForOpponent ? (
        <div className="paper mt-5 p-5 text-center">
          <Loader2 className="mx-auto h-5 w-5 animate-spin" />
          <p className="mt-2 font-semibold">Share code <span className="font-mono">{game.code}</span> with a friend</p>
        </div>
      ) : (
        <p className="mt-4 text-center font-semibold text-muted-foreground">
          {game.last_message ?? (myTurn ? "Your move" : "Opponent's move")}
        </p>
      )}

      {!waitingForOpponent && (
        <div className="mx-auto mt-4 max-w-md rounded-3xl border-2 border-ink p-2 shadow-soft sm:p-3">
          <div className="grid" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)` }}>
            {Array.from({ length: CELLS }).map((_, i) => {
              const row = Math.floor(i / 8);
              const col = i % 8;
              const dark = (row + col) % 2 === 1;
              const piece = game.board[i];
              const isSelected = selected === i;
              const isMustContinue = game.must_continue_from === i;
              return (
                <button
                  key={i}
                  onClick={() => cellClick(i)}
                  disabled={!myTurn || !dark}
                  className={`grid aspect-square place-items-center border border-black/10 disabled:cursor-default ${
                    dark ? "bg-[#3a2a20]" : "bg-[#e8d9c3]"
                  } ${isSelected ? "ring-4 ring-inset ring-neon" : ""} ${isMustContinue ? "ring-4 ring-inset ring-coral" : ""}`}
                >
                  {piece !== 0 && (
                    <span
                      className={`grid h-[72%] w-[72%] place-items-center rounded-full border-2 shadow-sm ${
                        piece === 1 || piece === 3 ? "border-black/40 bg-coral" : "border-black/40 bg-cream"
                      }`}
                    >
                      {(piece === 3 || piece === 4) && <Crown className="h-1/2 w-1/2" strokeWidth={2.5} />}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {game.status === "finished" && (
        <div className={`paper mt-5 p-6 text-center ${youWon ? "bg-mint" : "bg-cream"}`}>
          {youWon && <Crown className="mx-auto h-8 w-8" />}
          <h3 className="mt-2 text-2xl">{youWon ? "You won!" : "You lost — rematch?"}</h3>
          <button onClick={leave} className="mt-4 rounded-full bg-ink px-5 py-2 font-semibold text-cream">
            Back to lobby
          </button>
        </div>
      )}
    </section>
  );
}
