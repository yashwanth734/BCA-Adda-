import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useRole } from "@/lib/useRole";
import { toast } from "sonner";
import { ArrowLeft, ShieldCheck, Loader2, Trash2, RotateCcw, Check, Search, X } from "lucide-react";
import { TeacherMfaGate } from "@/components/TeacherMfaGate";

export const Route = createFileRoute("/moderation")({
  component: ModerationPage,
  head: () => ({
    meta: [
      { title: "Moderation Inbox · BCA Adda" },
      {
        name: "description",
        content:
          "Teacher moderation inbox to review reported chat messages, see reporters and timestamps, and remove or restore content.",
      },
      { property: "og:title", content: "Moderation Inbox · BCA Adda" },
      {
        property: "og:description",
        content: "Review reported messages and remove or restore them.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type ReportRow = {
  id: string;
  reporter_id: string;
  reported_user_id: string | null;
  message_id: string | null;
  target_type: string;
  reason: string;
  details: string | null;
  message_snapshot: string | null;
  status: string;
  created_at: string;
};

type Filter = "open" | "resolved" | "all";

const REASON_OPTIONS = [
  "abuse",
  "harassment",
  "hate_speech",
  "spam",
  "nsfw",
  "other",
];

function ModerationPage() {
  const { user, loading } = useAuth();
  const { isTeacher, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<Filter>("open");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [reasonFilter, setReasonFilter] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");


  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const reportsQuery = useQuery({
    queryKey: ["reports", filter],
    enabled: !!user && isTeacher,
    queryFn: async (): Promise<ReportRow[]> => {
      let q = supabase.from("reports").select("*").order("created_at", { ascending: false }).limit(200);
      if (filter === "open") q = q.eq("status", "open");
      if (filter === "resolved") q = q.neq("status", "open");
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as ReportRow[];
    },
  });

  const reports = reportsQuery.data ?? [];

  const messageIds = useMemo(
    () => Array.from(new Set(reports.map((r) => r.message_id).filter(Boolean) as string[])),
    [reports],
  );
  const userIds = useMemo(
    () =>
      Array.from(
        new Set(
          reports.flatMap((r) => [r.reporter_id, r.reported_user_id]).filter(Boolean) as string[],
        ),
      ),
    [reports],
  );

  const messagesQuery = useQuery({
    queryKey: ["moderation-messages", messageIds.join(",")],
    enabled: messageIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("id, content, created_at, removed_at, user_id")
        .in("id", messageIds);
      if (error) throw error;
      return data ?? [];
    },
  });

  const profilesQuery = useQuery({
    queryKey: ["moderation-profiles", userIds.join(",")],
    enabled: userIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, full_name")
        .in("id", userIds);
      if (error) throw error;
      return data ?? [];
    },
  });

  const nameOf = (id: string | null) => {
    if (!id) return "Unknown";
    const p = profilesQuery.data?.find((x) => x.id === id);
    return p?.full_name || p?.username || `${id.slice(0, 8)}…`;
  };
  const messageOf = (id: string | null) =>
    id ? messagesQuery.data?.find((m) => m.id === id) : undefined;

  const filteredReports = useMemo(() => {
    const q = search.trim().toLowerCase();
    const from = fromDate ? new Date(fromDate + "T00:00:00").getTime() : null;
    const to = toDate ? new Date(toDate + "T23:59:59.999").getTime() : null;
    return reports.filter((r) => {
      if (reasonFilter !== "all" && r.reason !== reasonFilter) return false;
      const t = new Date(r.created_at).getTime();
      if (from !== null && t < from) return false;
      if (to !== null && t > to) return false;
      if (!q) return true;
      const hay = [
        nameOf(r.reporter_id),
        r.reported_user_id ? nameOf(r.reported_user_id) : "",
        r.reason,
        r.details ?? "",
        r.message_snapshot ?? "",
        messageOf(r.message_id)?.content ?? "",
      ]
        .join(" ")
        .toLowerCase();
      return hay.includes(q);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reports, search, reasonFilter, fromDate, toDate, profilesQuery.data, messagesQuery.data]);

  const resetFilters = () => {
    setSearch("");
    setReasonFilter("all");
    setFromDate("");
    setToDate("");
  };
  const hasFilters =
    !!search.trim() || reasonFilter !== "all" || !!fromDate || !!toDate;


  const setRemoved = async (report: ReportRow, remove: boolean) => {
    if (!report.message_id) return;
    setBusyId(report.id);
    try {
      const { error } = await supabase
        .from("messages")
        .update({
          removed_at: remove ? new Date().toISOString() : null,
          removed_by: remove ? user!.id : null,
        })
        .eq("id", report.message_id);
      if (error) throw error;
      await supabase
        .from("reports")
        .update({ status: remove ? "actioned" : "restored" })
        .eq("id", report.id);
      toast.success(remove ? "Message removed from chat" : "Message restored");
      queryClient.invalidateQueries({ queryKey: ["reports"] });
      queryClient.invalidateQueries({ queryKey: ["moderation-messages"] });
      queryClient.invalidateQueries({ queryKey: ["messages"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusyId(null);
    }
  };

  const dismiss = async (report: ReportRow) => {
    setBusyId(report.id);
    try {
      const { error } = await supabase.from("reports").update({ status: "dismissed" }).eq("id", report.id);
      if (error) throw error;
      toast.success("Report dismissed");
      queryClient.invalidateQueries({ queryKey: ["reports"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusyId(null);
    }
  };

  if (loading || roleLoading) {
    return (
      <div className="grid min-h-screen place-items-center grain-bg">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!isTeacher) {
    return (
      <div className="grid min-h-screen place-items-center grain-bg px-5">
        <div className="paper max-w-sm p-7 text-center">
          <ShieldCheck className="mx-auto h-8 w-8" />
          <h1 className="mt-3 text-2xl">Teachers only</h1>
          <p className="mt-1 text-muted-foreground">
            The moderation inbox is available to accounts registered as a teacher.
          </p>
          <Link to="/chat" className="mt-5 inline-block rounded-full bg-ink px-5 py-2.5 font-semibold text-cream">
            Back to chat
          </Link>
        </div>
      </div>
    );
  }

  return (
    <TeacherMfaGate>
    <div className="min-h-screen grain-bg px-5 py-8">
      <div className="mx-auto max-w-3xl">
        <Link to="/chat" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to chat
        </Link>

        <header className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 font-display text-3xl font-bold">
              <ShieldCheck className="h-7 w-7" /> Moderation inbox
            </h1>
            <p className="mt-1 text-muted-foreground">Reported messages, reporters and timestamps.</p>
          </div>
          <div className="flex gap-1.5 rounded-full border-2 border-ink bg-cream p-1">
            {(["open", "resolved", "all"] as Filter[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full px-3.5 py-1.5 text-sm font-semibold capitalize ${
                  filter === f ? "bg-ink text-cream" : "hover:bg-secondary"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </header>

        <div className="paper mt-5 p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="min-w-[200px] flex-1">
              <label className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Search reporter, student or text
              </label>
              <div className="relative mt-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="e.g. Rahul, spam, exam…"
                  className="w-full rounded-xl border-2 border-ink/20 bg-cream py-2 pl-9 pr-3 text-sm outline-none focus:border-ink"
                />
              </div>
            </div>
            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Reason
              </label>
              <select
                value={reasonFilter}
                onChange={(e) => setReasonFilter(e.target.value)}
                className="mt-1 rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
              >
                <option value="all">All reasons</option>
                {REASON_OPTIONS.map((r) => (
                  <option key={r} value={r}>
                    {r.replace("_", " ")}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                From
              </label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="mt-1 block rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                To
              </label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="mt-1 block rounded-xl border-2 border-ink/20 bg-cream px-3 py-2 text-sm outline-none focus:border-ink"
              />
            </div>
            {hasFilters && (
              <button
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-cream px-3.5 py-2 text-sm font-semibold hover:bg-secondary"
              >
                <X className="h-4 w-4" /> Clear
              </button>
            )}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            Showing {filteredReports.length} of {reports.length} reports
          </p>
        </div>

        {reportsQuery.isLoading ? (
          <div className="mt-10 flex justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>
        ) : filteredReports.length === 0 ? (
          <div className="paper mt-6 p-8 text-center text-muted-foreground">
            {reports.length === 0
              ? "Nothing to review here. 🎉"
              : "No reports match these filters."}
          </div>
        ) : (
          <ul className="mt-6 space-y-4">
            {filteredReports.map((r) => {

              const msg = messageOf(r.message_id);
              const removed = !!msg?.removed_at;
              const busy = busyId === r.id;
              return (
                <li key={r.id} className="paper p-5">
                  <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                    <span className="rounded-full bg-accent px-2.5 py-1">{r.reason}</span>
                    <span className="rounded-full border-2 border-ink px-2.5 py-1">{r.target_type}</span>
                    <span
                      className={`rounded-full px-2.5 py-1 ${
                        r.status === "open" ? "bg-coral text-primary-foreground" : "bg-mint"
                      }`}
                    >
                      {r.status}
                    </span>
                    {removed && <span className="rounded-full bg-ink px-2.5 py-1 text-cream">removed</span>}
                  </div>

                  <p className="mt-3 text-sm text-muted-foreground">
                    Reported by <strong className="text-foreground">{nameOf(r.reporter_id)}</strong> on{" "}
                    {new Date(r.created_at).toLocaleString()}
                    {r.reported_user_id && (
                      <>
                        {" · "}against <strong className="text-foreground">{nameOf(r.reported_user_id)}</strong>
                      </>
                    )}
                  </p>

                  <blockquote
                    className={`mt-3 rounded-xl border-2 border-border bg-secondary/60 px-4 py-3 text-sm ${
                      removed ? "line-through opacity-60" : ""
                    }`}
                  >
                    {msg?.content ?? r.message_snapshot ?? "Message no longer available."}
                    {msg?.created_at && (
                      <div className="mt-1.5 text-xs text-muted-foreground line-through-none">
                        Sent {new Date(msg.created_at).toLocaleString()}
                      </div>
                    )}
                  </blockquote>

                  {r.details && (
                    <p className="mt-2 text-sm">
                      <span className="font-semibold">Details:</span> {r.details}
                    </p>
                  )}

                  <div className="mt-4 flex flex-wrap gap-2">
                    {r.message_id && (
                      removed ? (
                        <button
                          disabled={busy}
                          onClick={() => setRemoved(r, false)}
                          className="inline-flex items-center gap-2 rounded-full border-2 border-ink bg-cream px-4 py-2 text-sm font-semibold hover:bg-secondary disabled:opacity-60"
                        >
                          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
                          Restore message
                        </button>
                      ) : (
                        <button
                          disabled={busy}
                          onClick={() => setRemoved(r, true)}
                          className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
                        >
                          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                          Remove message
                        </button>
                      )
                    )}
                    {r.status === "open" && (
                      <button
                        disabled={busy}
                        onClick={() => dismiss(r)}
                        className="inline-flex items-center gap-2 rounded-full border-2 border-ink bg-cream px-4 py-2 text-sm font-semibold hover:bg-secondary disabled:opacity-60"
                      >
                        <Check className="h-4 w-4" /> Dismiss
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
    </TeacherMfaGate>
  );
}
