import { createFileRoute, Link } from "@tanstack/react-router";
import { Brain, Hand, Hash, Landmark, Swords, Zap, Dice5, Circle, Grid3x3, Rows3, Ship, Disc, Square, Crown } from "lucide-react";

export const Route = createFileRoute("/games/")({
  head: () => ({
    meta: [
      { title: "The Arcade — Quick Games for Everyone" },
      {
        name: "description",
        content:
          "Play Trade City, Connect Four, War, Battleship, Othello, Checkers, Dots and Boxes, Bankroll Dice, Tic Tac Toe, Rock Paper Scissors, Memory Match, Reaction Test, Snake and 2048 — no sign-up hoops, just quick games anyone can jump into.",
      },
      { property: "og:title", content: "The Arcade" },
      { property: "og:description", content: "Fourteen quick games to play whenever you need a break." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GamesHub,
});

const games = [
  {
    to: "/board",
    title: "Trade City",
    tag: "Multiplayer",
    desc: "Property-trading board game with bots, auctions and trades.",
    icon: Landmark,
    emoji: "🏙️",
    tint: "from-violet/85 to-coral/70",
    fg: "text-cream",
  },
  {
    to: "/games/war",
    title: "War",
    tag: "Multiplayer",
    desc: "Challenge a friend card-for-card in real time.",
    icon: Swords,
    emoji: "🃏",
    tint: "from-ink to-violet/80",
    fg: "text-cream",
  },
  {
    to: "/games/connect-four",
    title: "Connect Four",
    tag: "Multiplayer",
    desc: "Drop discs, get four in a row, real-time head-to-head.",
    icon: Circle,
    emoji: "🔴",
    tint: "from-gold/90 to-violet/60",
    fg: "text-ink",
  },
  {
    to: "/games/battleship",
    title: "Battleship",
    tag: "Multiplayer",
    desc: "Hide your fleet, hunt theirs down. The tougher one.",
    icon: Ship,
    emoji: "🚢",
    tint: "from-ink to-[#1a3fa8]",
    fg: "text-cream",
  },
  {
    to: "/games/othello",
    title: "Othello",
    tag: "Multiplayer",
    desc: "Standard 8×8 board. Bracket a line, flip it your color.",
    icon: Disc,
    emoji: "⚫",
    tint: "from-mint to-ink",
    fg: "text-cream",
  },
  {
    to: "/games/dots-and-boxes",
    title: "Dots and Boxes",
    tag: "Multiplayer",
    desc: "Draw a line, claim a box, chase the extra turn.",
    icon: Square,
    emoji: "🔲",
    tint: "from-gold/80 to-coral/80",
    fg: "text-ink",
  },
  {
    to: "/games/checkers",
    title: "Checkers",
    tag: "Multiplayer",
    desc: "Standard rules — captures are mandatory, king me.",
    icon: Crown,
    emoji: "🔴",
    tint: "from-[#3a2a20] to-[#e8d9c3]",
    fg: "text-cream",
  },
  {
    to: "/games/bankroll",
    title: "Bankroll Dice",
    tag: "Solo",
    desc: "Bet virtual coins on the dice sum and grow the stack.",
    icon: Dice5,
    emoji: "🎲",
    tint: "from-gold/90 to-coral/70",
    fg: "text-ink",
  },
  {
    to: "/games/tic-tac-toe",
    title: "Tic Tac Toe",
    tag: "Multiplayer",
    desc: "Practice vs bot, or three-in-a-row head-to-head with a friend.",
    icon: Hash,
    emoji: "❌",
    tint: "from-coral/90 to-gold/70",
    fg: "text-ink",
  },
  {
    to: "/games/rps",
    title: "Rock Paper Scissors",
    tag: "Multiplayer",
    desc: "Best-of-five standoff — vs bot or a friend in real time.",
    icon: Hand,
    emoji: "✊",
    tint: "from-neon/90 to-violet/60",
    fg: "text-ink",
  },
  {
    to: "/games/memory",
    title: "Memory Match",
    tag: "Solo",
    desc: "Flip cards, find pairs, beat your own move count.",
    icon: Brain,
    emoji: "🧠",
    tint: "from-mint to-neon/70",
    fg: "text-ink",
  },
  {
    to: "/games/reaction",
    title: "Reaction Test",
    tag: "Solo",
    desc: "Tap the exact second the screen turns green.",
    icon: Zap,
    emoji: "⚡",
    tint: "from-gold/90 to-neon/70",
    fg: "text-ink",
  },
  {
    to: "/games/snake",
    title: "Snake",
    tag: "Solo",
    desc: "Eat, grow, don't hit yourself. A true classic.",
    icon: Rows3,
    emoji: "🐍",
    tint: "from-mint to-gold/70",
    fg: "text-ink",
  },
  {
    to: "/games/2048",
    title: "2048",
    tag: "Solo",
    desc: "Slide tiles, merge numbers, chase the big one.",
    icon: Grid3x3,
    emoji: "🔢",
    tint: "from-violet/90 to-coral/60",
    fg: "text-cream",
  },
] as const;

function GamesHub() {
  return (
    <section>
      <div className="relative overflow-hidden rounded-3xl border-2 border-ink arcade-grid p-6 shadow-soft sm:p-9">
        <span className="chip">⚡ Take a 5-minute break</span>
        <h1 className="mt-3 text-4xl sm:text-6xl">
          The <span className="text-coral">Arcade</span>
        </h1>
        <p className="mt-2 max-w-xl text-muted-foreground">
          Fourteen quick games — solo, vs bot, or head-to-head with anyone.
        </p>
        <Link
          to="/leaderboard"
          className="mt-4 inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-cream px-4 py-1.5 text-sm font-bold shadow-pop hover:-translate-y-0.5 transition-transform"
        >
          🏆 Leaderboard
        </Link>
        <div className="pointer-events-none absolute -right-6 -top-4 animate-float-slow text-7xl opacity-70 sm:text-8xl">
          🎮
        </div>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {games.map((g) => (
          <Link key={g.to} to={g.to} className="game-card sheen group block p-5">
            <div className="flex items-start gap-4">
              <div
                className={`grid h-14 w-14 shrink-0 place-items-center rounded-2xl border-2 border-ink bg-gradient-to-br ${g.tint} ${g.fg} shadow-pop transition-transform group-hover:rotate-6`}
              >
                <g.icon className="h-7 w-7" strokeWidth={2.25} />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl">{g.title}</h2>
                  <span className="rounded-full border border-ink/20 bg-background/70 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                    {g.tag}
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{g.desc}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-bold text-coral">
                  <g.icon className="h-4 w-4" /> Play
                  <span className="transition-transform group-hover:translate-x-1">→</span>
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
