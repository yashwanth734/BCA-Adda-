import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { ArrowLeft, Gamepad2 } from "lucide-react";
import { GraphicsProvider, GraphicsToggle } from "@/lib/graphics";
import { ThemeToggle } from "@/components/ThemeToggle";

export const Route = createFileRoute("/games")({
  head: () => ({
    meta: [
      { title: "Arcade — Quick Games for Everyone" },
      { name: "description", content: "Quick games anyone can jump into whenever you need a break." },
    ],
  }),
  component: GamesLayout,
});

function GamesLayout() {
  return (
    <GraphicsProvider>
      <div className="min-h-screen arcade-bg">
        <header className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-5 py-4">
          <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
          <Link to="/games" className="flex items-center gap-2 font-display text-lg font-bold">
            <Gamepad2 className="h-5 w-5" /> Arcade
          </Link>
          <div className="flex items-center gap-3">
            <GraphicsToggle />
            <ThemeToggle />
            <Link to="/chat" className="text-sm font-semibold hover:underline">
              Chat
            </Link>
          </div>
        </header>
        <main className="mx-auto max-w-5xl px-5 pb-16">
          <Outlet />
        </main>
      </div>
    </GraphicsProvider>
  );
}

