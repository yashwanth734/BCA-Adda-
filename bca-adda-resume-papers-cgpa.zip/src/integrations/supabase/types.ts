export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      attendance_records: {
        Row: {
          created_at: string
          date: string
          id: string
          marked_by: string | null
          status: string
          subject_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          date?: string
          id?: string
          marked_by?: string | null
          status: string
          subject_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          marked_by?: string | null
          status?: string
          subject_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_records_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      bg_room_members: {
        Row: {
          color: string
          created_at: string
          display_name: string | null
          id: string
          is_bot: boolean
          is_ready: boolean
          last_seen: string
          room_id: string
          seat: number
          user_id: string
        }
        Insert: {
          color?: string
          created_at?: string
          display_name?: string | null
          id?: string
          is_bot?: boolean
          is_ready?: boolean
          last_seen?: string
          room_id: string
          seat: number
          user_id: string
        }
        Update: {
          color?: string
          created_at?: string
          display_name?: string | null
          id?: string
          is_bot?: boolean
          is_ready?: boolean
          last_seen?: string
          room_id?: string
          seat?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bg_room_members_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "bg_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      bg_rooms: {
        Row: {
          code: string
          created_at: string
          host_id: string
          id: string
          is_private: boolean
          max_players: number
          name: string
          state: Json
          status: string
          updated_at: string
          version: number
          winner_id: string | null
        }
        Insert: {
          code: string
          created_at?: string
          host_id: string
          id?: string
          is_private?: boolean
          max_players?: number
          name?: string
          state?: Json
          status?: string
          updated_at?: string
          version?: number
          winner_id?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          host_id?: string
          id?: string
          is_private?: boolean
          max_players?: number
          name?: string
          state?: Json
          status?: string
          updated_at?: string
          version?: number
          winner_id?: string | null
        }
        Relationships: []
      }
      channels: {
        Row: {
          created_at: string
          description: string | null
          emoji: string | null
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          emoji?: string | null
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          emoji?: string | null
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          channel_id: string
          content: string
          created_at: string
          edited_at: string | null
          id: string
          removed_at: string | null
          removed_by: string | null
          user_id: string
        }
        Insert: {
          channel_id: string
          content: string
          created_at?: string
          edited_at?: string | null
          id?: string
          removed_at?: string | null
          removed_by?: string | null
          user_id: string
        }
        Update: {
          channel_id?: string
          content?: string
          created_at?: string
          edited_at?: string | null
          id?: string
          removed_at?: string | null
          removed_by?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          semester: number | null
          username: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          semester?: number | null
          username: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          semester?: number | null
          username?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          details: string | null
          id: string
          message_id: string | null
          message_snapshot: string | null
          reason: string
          reported_user_id: string | null
          reporter_id: string
          status: string
          target_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          details?: string | null
          id?: string
          message_id?: string | null
          message_snapshot?: string | null
          reason: string
          reported_user_id?: string | null
          reporter_id: string
          status?: string
          target_type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          details?: string | null
          id?: string
          message_id?: string | null
          message_snapshot?: string | null
          reason?: string
          reported_user_id?: string | null
          reporter_id?: string
          status?: string
          target_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reports_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      subjects: {
        Row: {
          created_at: string
          id: string
          name: string
          target_percent: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          target_percent?: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          target_percent?: number
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      war_games: {
        Row: {
          code: string
          created_at: string
          guest_deck_count: number
          guest_id: string | null
          guest_played: boolean
          host_deck_count: number
          host_id: string
          host_played: boolean
          id: string
          last_guest_card: number | null
          last_host_card: number | null
          last_message: string | null
          pot_count: number
          status: string
          updated_at: string
          winner_id: string | null
        }
        Insert: {
          code: string
          created_at?: string
          guest_deck_count?: number
          guest_id?: string | null
          guest_played?: boolean
          host_deck_count?: number
          host_id: string
          host_played?: boolean
          id?: string
          last_guest_card?: number | null
          last_host_card?: number | null
          last_message?: string | null
          pot_count?: number
          status?: string
          updated_at?: string
          winner_id?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          guest_deck_count?: number
          guest_id?: string | null
          guest_played?: boolean
          host_deck_count?: number
          host_id?: string
          host_played?: boolean
          id?: string
          last_guest_card?: number | null
          last_host_card?: number | null
          last_message?: string | null
          pot_count?: number
          status?: string
          updated_at?: string
          winner_id?: string | null
        }
        Relationships: []
      }
      war_games_private: {
        Row: {
          game_id: string
          guest_deck: number[]
          guest_pending_card: number | null
          host_deck: number[]
          host_pending_card: number | null
          pot: number[]
        }
        Insert: {
          game_id: string
          guest_deck?: number[]
          guest_pending_card?: number | null
          host_deck?: number[]
          host_pending_card?: number | null
          pot?: number[]
        }
        Update: {
          game_id?: string
          guest_deck?: number[]
          guest_pending_card?: number | null
          host_deck?: number[]
          host_pending_card?: number | null
          pot?: number[]
        }
        Relationships: [
          {
            foreignKeyName: "war_games_private_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: true
            referencedRelation: "war_games"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      bg_is_member: {
        Args: { _room_id: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      war_create_game: {
        Args: never
        Returns: {
          code: string
          created_at: string
          guest_deck_count: number
          guest_id: string | null
          guest_played: boolean
          host_deck_count: number
          host_id: string
          host_played: boolean
          id: string
          last_guest_card: number | null
          last_host_card: number | null
          last_message: string | null
          pot_count: number
          status: string
          updated_at: string
          winner_id: string | null
        }
        SetofOptions: {
          from: "*"
          to: "war_games"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      war_join_game: {
        Args: { _code: string }
        Returns: {
          code: string
          created_at: string
          guest_deck_count: number
          guest_id: string | null
          guest_played: boolean
          host_deck_count: number
          host_id: string
          host_played: boolean
          id: string
          last_guest_card: number | null
          last_host_card: number | null
          last_message: string | null
          pot_count: number
          status: string
          updated_at: string
          winner_id: string | null
        }
        SetofOptions: {
          from: "*"
          to: "war_games"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      war_leave_game: { Args: { _game_id: string }; Returns: undefined }
      war_my_state: {
        Args: { _game_id: string }
        Returns: {
          deck_size: number
          pending_card: number
        }[]
      }
      war_play_card: {
        Args: { _game_id: string }
        Returns: {
          code: string
          created_at: string
          guest_deck_count: number
          guest_id: string | null
          guest_played: boolean
          host_deck_count: number
          host_id: string
          host_played: boolean
          id: string
          last_guest_card: number | null
          last_host_card: number | null
          last_message: string | null
          pot_count: number
          status: string
          updated_at: string
          winner_id: string | null
        }
        SetofOptions: {
          from: "*"
          to: "war_games"
          isOneToOne: true
          isSetofReturn: false
        }
      }
    }
    Enums: {
      app_role: "student" | "teacher"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["student", "teacher"],
    },
  },
} as const
